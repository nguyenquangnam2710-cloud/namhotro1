package com.assistive.filter;

public final class Ellipse {
    public final float cx;
    public final float cy;
    public final float ax;
    public final float ay;

    public Ellipse(float cx, float cy, float ax, float ay) {
        this.cx = cx;
        this.cy = cy;
        this.ax = ax;
        this.ay = ay;
    }
}
