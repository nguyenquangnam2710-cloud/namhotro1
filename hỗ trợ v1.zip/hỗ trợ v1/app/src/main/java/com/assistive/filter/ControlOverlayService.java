package com.assistive.filter;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.view.Gravity;
import android.view.WindowManager;

public final class ControlOverlayService extends Service {

    public static final String ACTION_START = "com.assistive.filter.CTRL_START";
    public static final String ACTION_STOP = "com.assistive.filter.CTRL_STOP";

    private static final int NOTIF_ID = 5102;
    private static final String CHANNEL_ID = "assistive_control";

    private WindowManager wm;
    private WindowManager.LayoutParams params;
    private TargetOverlayView view;

    private HandlerThread workerThread;
    private Handler worker;

    private VisionService.VisionBinder fallback;

    private final Kalman2D kf = new Kalman2D();
    private long lastT;

    private final ServiceConnection conn = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            fallback = (VisionService.VisionBinder) service;
            worker.post(loop);
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            fallback = null;
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();

        startForegroundSafe();

        wm = (WindowManager) getSystemService(WINDOW_SERVICE);

        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
			? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
			: WindowManager.LayoutParams.TYPE_PHONE;

        params = new WindowManager.LayoutParams(
			WindowManager.LayoutParams.MATCH_PARENT,
			WindowManager.LayoutParams.MATCH_PARENT,
			type,
			WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
			| WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
			| WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
			PixelFormat.TRANSLUCENT
        );
        params.gravity = Gravity.TOP | Gravity.START;
        params.x = 0;
        params.y = 0;

        view = new TargetOverlayView(this);
        try {
            wm.addView(view, params);
        } catch (Throwable ignore) {}

        workerThread = new HandlerThread("control_overlay");
        workerThread.start();
        worker = new Handler(workerThread.getLooper());

        Intent i = new Intent(this, VisionService.class);
        bindService(i, conn, Context.BIND_AUTO_CREATE);
    }

    private void startForegroundSafe() {
        try {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (nm == null) return;

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                NotificationChannel ch = new NotificationChannel(
					CHANNEL_ID, "Control", NotificationManager.IMPORTANCE_MIN);
                ch.setSound(null, null);
                nm.createNotificationChannel(ch);
            }

            Notification.Builder b = (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
				? new Notification.Builder(this, CHANNEL_ID)
				: new Notification.Builder(this);

            Notification n = b.setOngoing(true)
				.setSmallIcon(android.R.drawable.ic_menu_compass)
				.setContentTitle("Assistive")
				.setContentText("Overlay running")
				.build();

            startForeground(NOTIF_ID, n);
        } catch (Throwable ignore) {}
    }

    private final Runnable loop = new Runnable() {
        @Override
        public void run() {
            long now = System.currentTimeMillis();
            float dt = 0.016f;
            if (lastT != 0L) {
                long d = now - lastT;
                if (d < 1) d = 1;
                if (d > 50) d = 50;
                dt = d / 1000f;
            }
            lastT = now;

            kf.predict(dt);

            TargetSample s = null;
            VisionService.VisionBinder fb = fallback;
            if (fb != null) {
                try { s = fb.readLatest(); } catch (Throwable ignore) {}
            }

            float conf = 0f;
            if (s != null) conf = s.confidence;

            if (s != null && s.confidence >= 0.15f && s.x >= 0f && s.y >= 0f) {
                kf.update(s.x, s.y, s.vx, s.vy, s.confidence);
            }

            TargetSample st = kf.getState(now, conf);
            float lead = 0.02f;
            float px = st.x + st.vx * lead;
            float py = st.y + st.vy * lead;

            if (view != null) view.setTarget(px, py, conf);

            worker.postDelayed(this, 8L);
        }
    };

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent != null ? intent.getAction() : null;
        if (ACTION_STOP.equals(action)) {
            stopSelf();
            return START_NOT_STICKY;
        }
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        try { unbindService(conn); } catch (Throwable ignore) {}
        try {
            if (wm != null && view != null && view.getParent() != null) wm.removeView(view);
        } catch (Throwable ignore) {}
        try { if (workerThread != null) workerThread.quitSafely(); } catch (Throwable ignore) {}
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }
}

