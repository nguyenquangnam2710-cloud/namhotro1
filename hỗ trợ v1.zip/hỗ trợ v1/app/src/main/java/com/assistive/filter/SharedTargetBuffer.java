package com.assistive.filter;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;

public final class SharedTargetBuffer {

    public static final int SIZE = 64;

    private static final int OFF_SEQ = 0;
    private static final int OFF_T = 4;
    private static final int OFF_X = 12;
    private static final int OFF_Y = 16;
    private static final int OFF_VX = 20;
    private static final int OFF_VY = 24;
    private static final int OFF_C = 28;

    private final ByteBuffer buf;

    public SharedTargetBuffer(ByteBuffer buf) {
        this.buf = buf;
        this.buf.order(ByteOrder.LITTLE_ENDIAN);
    }

    public void write(TargetSample s) {
        int seq = buf.getInt(OFF_SEQ);
        if (seq < 0) seq = 0;
        int s1 = seq + 1;
        int s2 = seq + 2;

        buf.putInt(OFF_SEQ, s1 | 1);

        buf.putLong(OFF_T, s.tMillis);
        buf.putFloat(OFF_X, s.x);
        buf.putFloat(OFF_Y, s.y);
        buf.putFloat(OFF_VX, s.vx);
        buf.putFloat(OFF_VY, s.vy);
        buf.putFloat(OFF_C, clamp01(s.confidence));

        buf.putInt(OFF_SEQ, s2 & ~1);
    }

    public TargetSample readLatest() {
        int s0 = buf.getInt(OFF_SEQ);
        if ((s0 & 1) != 0) return null;

        long t = buf.getLong(OFF_T);
        float x = buf.getFloat(OFF_X);
        float y = buf.getFloat(OFF_Y);
        float vx = buf.getFloat(OFF_VX);
        float vy = buf.getFloat(OFF_VY);
        float c = buf.getFloat(OFF_C);

        int s1 = buf.getInt(OFF_SEQ);
        if (s0 != s1 || (s1 & 1) != 0) return null;
        if (t <= 0L) return null;

        return new TargetSample(t, x, y, vx, vy, clamp01(c));
    }

    private static float clamp01(float v) {
        if (v < 0f) return 0f;
        if (v > 1f) return 1f;
        return v;
    }
}

