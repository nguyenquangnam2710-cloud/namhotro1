// File: MovableAimButtonService.java (không thay đổi, chỉ dùng ACTION_AIM_TRIGGER đã có)
package com.assistive.filter;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Toast;

public class MovableAimButtonService extends Service {

    private static final int NOTIF_ID = 5006;
    private static final String CHANNEL_ID = "movable_aim_button";
    private WindowManager wm;
    private View buttonView;
    private WindowManager.LayoutParams params;
    private boolean isLocked = false;
    private float startX, startY;
    private int initialX, initialY;
    private long lastClickTime = 0;
    private Handler handler = new Handler();

    @Override
    public void onCreate() {
        super.onCreate();
        startForegroundSafe();
        setupButton();
    }

    private void startForegroundSafe() {
        try {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (nm == null) return;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                NotificationChannel ch = new NotificationChannel(CHANNEL_ID, "Movable Aim", NotificationManager.IMPORTANCE_MIN);
                ch.setSound(null, null);
                nm.createNotificationChannel(ch);
            }
            Notification.Builder b = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
				? new Notification.Builder(this, CHANNEL_ID) : new Notification.Builder(this);
            Notification n = b.setOngoing(true)
				.setSmallIcon(android.R.drawable.ic_menu_rotate)
				.setContentTitle("Movable Aim Button")
				.setContentText("Ready")
				.build();
            startForeground(NOTIF_ID, n);
        } catch (Throwable t) {
            stopSelf();
        }
    }

    private void setupButton() {
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        LayoutInflater inflater = LayoutInflater.from(this);
        buttonView = inflater.inflate(R.layout.movable_aim_button, null);
        float density = getResources().getDisplayMetrics().density;
        int size = (int)(60 * density);

        int layoutFlag = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
			? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
			: WindowManager.LayoutParams.TYPE_PHONE;
        params = new WindowManager.LayoutParams(
			size, size,
			layoutFlag,
			WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
			PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.BOTTOM | Gravity.END;
        params.x = 0;
        params.y = 0;

        buttonView.setOnTouchListener(new View.OnTouchListener() {
				private boolean moved = false;
				@Override
				public boolean onTouch(View v, MotionEvent event) {
					switch (event.getActionMasked()) {
						case MotionEvent.ACTION_DOWN:
							startX = event.getRawX();
							startY = event.getRawY();
							initialX = params.x;
							initialY = params.y;
							moved = false;
							handler.removeCallbacksAndMessages(null);
							return true;
						case MotionEvent.ACTION_MOVE:
							float dx = event.getRawX() - startX;
							float dy = event.getRawY() - startY;
							if (Math.hypot(dx, dy) > 10) moved = true;
							if (!isLocked) {
								params.x = initialX + (int) dx;
								params.y = initialY + (int) dy;
								wm.updateViewLayout(buttonView, params);
							}
							return true;
						case MotionEvent.ACTION_UP:
							if (!moved) {
								long now = System.currentTimeMillis();
								if (now - lastClickTime < 300) {
									toggleLock();
									lastClickTime = 0;
								} else {
									lastClickTime = now;
									handler.postDelayed(new Runnable() {
											@Override
											public void run() {
												if (isLocked && lastClickTime != 0) {
													performAim();
												}
												lastClickTime = 0;
											}
										}, 300);
								}
							}
							return true;
					}
					return false;
				}
			});
        wm.addView(buttonView, params);
        updateButtonAppearance();
    }

    private void toggleLock() {
        isLocked = !isLocked;
        updateButtonAppearance();
        String msg = isLocked ? "Locked (aim enabled)" : "Unlocked (drag to move)";
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

    private void updateButtonAppearance() {
        if (buttonView != null) {
            buttonView.setAlpha(isLocked ? 1.0f : 0.6f);
            buttonView.setBackgroundColor(isLocked ? 0xAA00FF00 : 0xAAFF0000);
        }
    }

    private void performAim() {
        Intent intent = new Intent(AssistTouchAccessibilityService.ACTION_AIM_TRIGGER);
        sendBroadcast(intent);
        Toast.makeText(this, "Aim triggered", Toast.LENGTH_SHORT).show();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        if (buttonView != null && wm != null) {
            try { wm.removeView(buttonView); } catch (Throwable ignore) {}
        }
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
