package com.assistive.filter;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.NotificationManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import rikka.shizuku.Shizuku;

public final class MainActivity extends Activity {
    private static final int REQ_SHIZUKU = 10001;
    private static final int REQ_NOTIF = 10;

    private static final int REQ_LENS_CAPTURE = 20002;

    private static final String PREFS = "assistive_prefs";
    private static final String KEY_POINTER_SPEED = "pointer_speed";

    private Button btnPointerSpeed;
    private Button btnApiToggle;
    private Button btnApiKey;

    private int lensResultCode;
    private Intent lensResultData;

    private String pendingCaptureTarget;

    private final Shizuku.OnRequestPermissionResultListener shizukuPermListener =
	new Shizuku.OnRequestPermissionResultListener() {
		@Override
		public void onRequestPermissionResult(int requestCode, int grantResult) {
			if (grantResult == PackageManager.PERMISSION_GRANTED) {
				Toast.makeText(MainActivity.this, "Đã cấp quyền Shizuku", Toast.LENGTH_SHORT).show();
				try { ShizukuPointerSpeedController.connect(MainActivity.this); } catch (Throwable ignore) {}
				try { ShizukuDpiController.connect(MainActivity.this); } catch (Throwable ignore) {}
			} else {
				Toast.makeText(MainActivity.this, "Bạn chưa cấp quyền Shizuku", Toast.LENGTH_SHORT).show();
			}
			updatePointerSpeedText();
		}
	};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        try {
            Shizuku.addRequestPermissionResultListener(shizukuPermListener);
        } catch (Throwable ignore) {}

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIF);
        }

        handleApiIntent(getIntent());

        Button btnOverlay = findViewById(R.id.btnOverlay);
        Button btnStart = findViewById(R.id.btnStart);
        Button btnEdit = findViewById(R.id.btnEdit);
        Button btnStop = findViewById(R.id.btnStop);

        Button btnShizuku = findViewById(R.id.btnShizuku);
        btnPointerSpeed = findViewById(R.id.btnPointerSpeed);

        Button btnScreenSensitivity = findViewById(R.id.btnScreenSensitivity);
        Button btnXSensitivity = findViewById(R.id.btnXSensitivity);

        Button btnHeightPlus20 = findViewById(R.id.btnHeightPlus20);
        Button btnHeightMinus20 = findViewById(R.id.btnHeightMinus20);

        Button btnReduceLag = findViewById(R.id.btnReduceLag);

        Button btnEnhanceLens = findViewById(R.id.btnEnhanceLens);

        Button btnLensEdit = findViewById(R.id.btnLensEdit);

        btnApiToggle = findViewById(R.id.btnApiToggle);
        btnApiKey = findViewById(R.id.btnApiKey);

        Button btnDpi1 = findViewById(R.id.btnDpi1);
        Button btnDpi2 = findViewById(R.id.btnDpi2);
        Button btnDpi3 = findViewById(R.id.btnDpi3);
        Button btnDpi4 = findViewById(R.id.btnDpi4);
        Button btnDpi5 = findViewById(R.id.btnDpi5);
        Button btnDpi6 = findViewById(R.id.btnDpi6);
        Button btnDpi7 = findViewById(R.id.btnDpi7);
        Button btnDpi8 = findViewById(R.id.btnDpi8);
        Button btnDpi9 = findViewById(R.id.btnDpi9);
        Button btnDpi10 = findViewById(R.id.btnDpi10);

        btnOverlay.setOnClickListener(new View.OnClickListener() {
				@Override public void onClick(View v) {
					openOverlaySettings();
				}
			});

        btnStart.setOnClickListener(new View.OnClickListener() {
				@Override public void onClick(View v) {
					if (!ensureAllPermissions()) return;
					startSvc(filteroverlayservice.ACTION_START_LOCKED);
				}
			});

        btnEdit.setOnClickListener(new View.OnClickListener() {
				@Override public void onClick(View v) {
					if (!ensureAllPermissions()) return;
					startSvc(filteroverlayservice.ACTION_START_EDIT);
				}
			});

        btnStop.setOnClickListener(new View.OnClickListener() {
				@Override public void onClick(View v) {
					Intent i = new Intent(MainActivity.this, filteroverlayservice.class);
					i.setAction(filteroverlayservice.ACTION_STOP);
					startService(i);
				}
			});

        btnShizuku.setOnClickListener(new View.OnClickListener() {
				@Override public void onClick(View v) {
					connectShizuku();
				}
			});

        btnPointerSpeed.setOnClickListener(new View.OnClickListener() {
				@Override public void onClick(View v) {
					changePointerSpeed(+1);
				}
			});

        btnPointerSpeed.setOnLongClickListener(new View.OnLongClickListener() {
				@Override public boolean onLongClick(View v) {
					changePointerSpeed(-1);
					return true;
				}
			});

        btnScreenSensitivity.setOnClickListener(new View.OnClickListener() {
				@Override public void onClick(View v) {
					showScreenSensitivityDialog();
				}
			});

        btnXSensitivity.setOnClickListener(new View.OnClickListener() {
				@Override public void onClick(View v) {
					showXSensitivityDialog();
				}
			});

        btnHeightPlus20.setOnClickListener(new View.OnClickListener() {
				@Override public void onClick(View v) {
					applyHeightPlus20();
				}
			});

        btnHeightMinus20.setOnClickListener(new View.OnClickListener() {
				@Override public void onClick(View v) {
					applyHeightMinus20();
				}
			});

        btnReduceLag.setOnClickListener(new View.OnClickListener() {
				@Override public void onClick(View v) {
					applyReduceLag();
				}
			});

        btnEnhanceLens.setOnClickListener(new View.OnClickListener() {
				@Override public void onClick(View v) {
					if (!ensureAllPermissions()) return;
					if (lensResultCode != 0 && lensResultData != null) {
						startEnhanceLens(lensResultCode, lensResultData);
					} else {
						startLensCapture();
					}
				}
			});

        btnEnhanceLens.setOnLongClickListener(new View.OnLongClickListener() {
				@Override public boolean onLongClick(View v) {
					stopEnhanceLens();
					return true;
				}
			});

        btnLensEdit.setOnClickListener(new View.OnClickListener() {
				@Override public void onClick(View v) {
					if (!ensureAllPermissions()) return;
					startLensRing();
				}
			});

        btnLensEdit.setOnLongClickListener(new View.OnLongClickListener() {
				@Override public boolean onLongClick(View v) {
					stopLensRing();
					return true;
				}
			});

        btnApiToggle.setOnClickListener(new View.OnClickListener() {
				@Override public void onClick(View v) {
					boolean on = ApiConfig.isEnabled(MainActivity.this);
					ApiConfig.setEnabled(MainActivity.this, !on);
					updateApiUi();
				}
			});

        btnApiKey.setOnClickListener(new View.OnClickListener() {
				@Override public void onClick(View v) {
					showApiKeyDialog();
				}
			});

        btnDpi1.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { applyDpi(360); }});
        btnDpi2.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { applyDpi(390); }});
        btnDpi3.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { applyDpi(420); }});
        btnDpi4.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { applyDpi(450); }});
        btnDpi5.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { applyDpi(480); }});
        btnDpi6.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { applyDpi(510); }});
        btnDpi7.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { resetDpi(); }});
        btnDpi8.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { applyDpi(720); }});
        btnDpi9.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { applyDpi(920); }});
        btnDpi10.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { applyDpi(620); }});

        updatePointerSpeedText();
        updateApiUi();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleApiIntent(intent);
    }

    private void handleApiIntent(Intent intent) {
        if (intent == null) return;
        String t = intent.getStringExtra(ActionApiReceiver.EXTRA_CAPTURE_TARGET);
        if (t == null || t.length() == 0) return;
        pendingCaptureTarget = t;
        startLensCapture();
    }

    private void updateApiUi() {
        if (btnApiToggle != null) {
            boolean on = ApiConfig.isEnabled(this);
            btnApiToggle.setText(on ? "Public API: ON" : "Public API: OFF");
        }
        if (btnApiKey != null) {
            String k = ApiConfig.getKey(this);
            btnApiKey.setText(k.length() == 0 ? "Đặt API key (đang trống)" : "Đổi API key");
        }
    }

    private void showApiKeyDialog() {
        final EditText et = new EditText(this);
        et.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
        et.setSingleLine(true);

        String cur = ApiConfig.getKey(this);
        et.setText(cur);
        et.setSelection(et.getText() != null ? et.getText().length() : 0);

        final AlertDialog d = new AlertDialog.Builder(this)
            .setTitle("API key")
            .setView(et)
            .setNegativeButton("Hủy", null)
            .setPositiveButton("Lưu", new DialogInterface.OnClickListener() {
                @Override public void onClick(DialogInterface dialog, int which) {
                    String s = et.getText() != null ? et.getText().toString() : "";
                    ApiConfig.setKey(MainActivity.this, s);
                    updateApiUi();
                }
            })
            .create();

        d.setOnShowListener(new DialogInterface.OnShowListener() {
				@Override public void onShow(DialogInterface dialog) {
					InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
					if (imm != null) imm.showSoftInput(et, InputMethodManager.SHOW_IMPLICIT);
				}
			});

        d.show();
    }

    private void startLensRing() {
        try {
            Intent v = new Intent(this, LensOverlayService.class);
            v.setAction(LensOverlayService.ACTION_START);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(v);
            else startService(v);
        } catch (Throwable t) {
            Toast.makeText(this, "startService lỗi: " + t.getClass().getSimpleName(), Toast.LENGTH_SHORT).show();
        }
    }

    private void stopLensRing() {
        try {
            Intent v = new Intent(this, LensOverlayService.class);
            v.setAction(LensOverlayService.ACTION_STOP);
            startService(v);
        } catch (Throwable ignore) {}
    }

    private void startLensCapture() {
        android.media.projection.MediaProjectionManager mpm =
            (android.media.projection.MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        if (mpm == null) {
            Toast.makeText(this, "Không có MediaProjection", Toast.LENGTH_SHORT).show();
            return;
        }
        startActivityForResult(mpm.createScreenCaptureIntent(), REQ_LENS_CAPTURE);
    }

    private void startEnhanceLens(int resultCode, Intent data) {
        Intent v = new Intent(this, enhancelensservice.class);
        v.setAction(enhancelensservice.ACTION_START_LOCKED);
        v.putExtra(enhancelensservice.EXTRA_RESULT_CODE, resultCode);
        v.putExtra(enhancelensservice.EXTRA_RESULT_DATA, data);

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(v);
            } else {
                startService(v);
            }
        } catch (Throwable t) {
            Toast.makeText(this, "startService lỗi: " + t.getClass().getSimpleName(), Toast.LENGTH_SHORT).show();
        }
    }

    private void stopEnhanceLens() {
        try {
            Intent v = new Intent(this, enhancelensservice.class);
            v.setAction(enhancelensservice.ACTION_STOP);
            startService(v);
        } catch (Throwable ignore) {}
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQ_LENS_CAPTURE) {
            if (resultCode != RESULT_OK || data == null) {
                Toast.makeText(this, "Bạn chưa cấp quyền chụp màn hình", Toast.LENGTH_SHORT).show();
                pendingCaptureTarget = null;
                return;
            }

            lensResultCode = resultCode;
            lensResultData = new Intent(data);

            startEnhanceLens(lensResultCode, lensResultData);

            String t = pendingCaptureTarget;
            pendingCaptureTarget = null;

            if (ActionApiReceiver.CAPTURE_TARGET_VISION.equals(t)) {
                Intent v = new Intent(this, VisionService.class);
                v.setAction(VisionService.ACTION_START);
                v.putExtra(VisionService.EXTRA_RESULT_CODE, lensResultCode);
                v.putExtra(VisionService.EXTRA_RESULT_DATA, lensResultData);
                try {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(v);
                    else startService(v);
                } catch (Throwable ignore) {}
            }
        }
    }

    @Override
    protected void onDestroy() {
        try {
            Shizuku.removeRequestPermissionResultListener(shizukuPermListener);
        } catch (Throwable ignore) {}
        super.onDestroy();
    }

    private void connectShizuku() {
        if (!ShizukuPointerSpeedController.isShizukuRunning()) {
            Intent launch = getPackageManager().getLaunchIntentForPackage("moe.shizuku.privileged.api");
            if (launch != null) {
                startActivity(launch);
                Toast.makeText(this, "Mở Shizuku và bấm Bắt đầu", Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(this, "Chưa cài Shizuku", Toast.LENGTH_SHORT).show();
            }
            return;
        }

        if (!ShizukuPointerSpeedController.hasShizukuPermission()) {
            Toast.makeText(this, "Đang xin quyền Shizuku...", Toast.LENGTH_SHORT).show();
            ShizukuPointerSpeedController.requestShizukuPermission(REQ_SHIZUKU);
            return;
        }

        try { ShizukuPointerSpeedController.connect(this); } catch (Throwable ignore) {}
        try { ShizukuDpiController.connect(this); } catch (Throwable ignore) {}

        Toast.makeText(this, "Shizuku đã sẵn sàng", Toast.LENGTH_SHORT).show();
    }

    private void changePointerSpeed(int delta) {
        int cur = getSavedPointerSpeed();
        int next = clamp(cur + delta, -7, 7);

        boolean ok = ShizukuPointerSpeedController.setPointerSpeed(this, next);
        if (!ok) {
            if (!ShizukuPointerSpeedController.isShizukuRunning()) {
                Toast.makeText(this, "Shizuku chưa chạy", Toast.LENGTH_SHORT).show();
            } else if (!ShizukuPointerSpeedController.hasShizukuPermission()) {
                Toast.makeText(this, "Chưa cấp quyền Shizuku", Toast.LENGTH_SHORT).show();
                ShizukuPointerSpeedController.requestShizukuPermission(REQ_SHIZUKU);
            } else {
                Toast.makeText(this, "Không set được tốc độ con trỏ", Toast.LENGTH_SHORT).show();
            }
            return;
        }

        savePointerSpeed(next);
        updatePointerSpeedText();
        Toast.makeText(this, "Tốc độ con trỏ: " + next, Toast.LENGTH_SHORT).show();
    }

    private void applyDpi(int dpi) {
        boolean ok = ShizukuDpiController.setDpi(this, dpi);
        if (ok) {
            Toast.makeText(this, "Đã set DPI " + dpi, Toast.LENGTH_SHORT).show();
            return;
        }

        if (!ShizukuPointerSpeedController.isShizukuRunning()) {
            Toast.makeText(this, "Shizuku chưa chạy", Toast.LENGTH_SHORT).show();
        } else if (!ShizukuPointerSpeedController.hasShizukuPermission()) {
            Toast.makeText(this, "Chưa cấp quyền Shizuku", Toast.LENGTH_SHORT).show();
            ShizukuPointerSpeedController.requestShizukuPermission(REQ_SHIZUKU);
        } else {
            Toast.makeText(this, "Không set được DPI", Toast.LENGTH_SHORT).show();
        }
    }

    private void resetDpi() {
        boolean ok = ShizukuDpiController.resetDpi(this);
        if (ok) {
            Toast.makeText(this, "Đã reset DPI", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!ShizukuPointerSpeedController.isShizukuRunning()) {
            Toast.makeText(this, "Shizuku chưa chạy", Toast.LENGTH_SHORT).show();
        } else if (!ShizukuPointerSpeedController.hasShizukuPermission()) {
            Toast.makeText(this, "Chưa cấp quyền Shizuku", Toast.LENGTH_SHORT).show();
            ShizukuPointerSpeedController.requestShizukuPermission(REQ_SHIZUKU);
        } else {
            Toast.makeText(this, "Không reset được DPI", Toast.LENGTH_SHORT).show();
        }
    }

    private void showScreenSensitivityDialog() {
        final EditText et = new EditText(this);
        et.setInputType(InputType.TYPE_CLASS_NUMBER
						| InputType.TYPE_NUMBER_FLAG_DECIMAL
						| InputType.TYPE_NUMBER_FLAG_SIGNED);
        et.setSingleLine(true);
        et.requestFocus();

        final AlertDialog d = new AlertDialog.Builder(this)
            .setTitle("Độ nhạy màn (nhập -1.56 hoặc 1.56)")
            .setView(et)
            .setNegativeButton("Hủy", null)
            .setPositiveButton("Áp dụng", new DialogInterface.OnClickListener() {
                @Override public void onClick(DialogInterface dialog, int which) {
                    String s = et.getText() != null ? et.getText().toString() : "";
                    applyScreenSensitivity(s);
                }
            })
            .create();

        d.setOnShowListener(new DialogInterface.OnShowListener() {
				@Override public void onShow(DialogInterface dialog) {
					InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
					if (imm != null) imm.showSoftInput(et, InputMethodManager.SHOW_IMPLICIT);
				}
			});

        d.show();
    }

    private void applyScreenSensitivity(String input) {
        String s = input == null ? "" : input.trim().replace(',', '.');

        float d;
        try {
            d = Float.parseFloat(s);
        } catch (Throwable t) {
            Toast.makeText(this, "Nhập số hợp lệ (vd -1.56 hoặc 1.56)", Toast.LENGTH_SHORT).show();
            return;
        }

        if (d == 0f || Math.abs(d) > 10f) {
            Toast.makeText(this, "Giá trị phải khác 0 và |giá trị| <= 10", Toast.LENGTH_SHORT).show();
            return;
        }

        boolean ok = ShizukuDpiController.applySignedScaleBySizeAndDpi(this, d);
        if (ok) {
            Toast.makeText(this, "Đã áp dụng size + dpi: " + d, Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Không áp dụng được (cần Shizuku + quyền)", Toast.LENGTH_SHORT).show();
        }
    }

    private void showXSensitivityDialog() {
        final EditText et = new EditText(this);
        et.setInputType(InputType.TYPE_CLASS_NUMBER
						| InputType.TYPE_NUMBER_FLAG_DECIMAL
						| InputType.TYPE_NUMBER_FLAG_SIGNED);
        et.setSingleLine(true);
        et.requestFocus();

        final AlertDialog d = new AlertDialog.Builder(this)
            .setTitle("Nhập % tăng nhạy X (vd 5 hoặc 2)")
            .setView(et)
            .setNegativeButton("Hủy", null)
            .setPositiveButton("Áp dụng", new DialogInterface.OnClickListener() {
                @Override public void onClick(DialogInterface dialog, int which) {
                    String s = et.getText() != null ? et.getText().toString() : "";
                    applyXSensitivityPercent(s);
                }
            })
            .create();

        d.setOnShowListener(new DialogInterface.OnShowListener() {
				@Override public void onShow(DialogInterface dialog) {
					InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
					if (imm != null) imm.showSoftInput(et, InputMethodManager.SHOW_IMPLICIT);
				}
			});

        d.show();
    }

    private void applyXSensitivityPercent(String input) {
        String s = input == null ? "" : input.trim().replace(',', '.');

        float percent;
        try {
            percent = Float.parseFloat(s);
        } catch (Throwable t) {
            Toast.makeText(this, "Nhập số hợp lệ (vd 5 hoặc 2)", Toast.LENGTH_SHORT).show();
            return;
        }

        if (percent <= 0f || percent > 50f) {
            Toast.makeText(this, "Phải > 0 và <= 50", Toast.LENGTH_SHORT).show();
            return;
        }

        boolean ok = ShizukuDpiController.applyXSensitivityPercent(this, percent);
        if (ok) {
            Toast.makeText(this, "Đã áp dụng nhạy X: +" + percent + "%", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!ShizukuPointerSpeedController.isShizukuRunning()) {
            Toast.makeText(this, "Shizuku chưa chạy", Toast.LENGTH_SHORT).show();
        } else if (!ShizukuPointerSpeedController.hasShizukuPermission()) {
            Toast.makeText(this, "Chưa cấp quyền Shizuku", Toast.LENGTH_SHORT).show();
            ShizukuPointerSpeedController.requestShizukuPermission(REQ_SHIZUKU);
        } else {
            Toast.makeText(this, "Không áp dụng được nhạy X", Toast.LENGTH_SHORT).show();
        }
    }

    private void applyHeightPlus20() {
        boolean ok = ShizukuDpiController.increaseHeightBy20(this);
        if (ok) {
            Toast.makeText(this, "Đã tăng Height +20", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!ShizukuPointerSpeedController.isShizukuRunning()) {
            Toast.makeText(this, "Shizuku chưa chạy", Toast.LENGTH_SHORT).show();
        } else if (!ShizukuPointerSpeedController.hasShizukuPermission()) {
            Toast.makeText(this, "Chưa cấp quyền Shizuku", Toast.LENGTH_SHORT).show();
            ShizukuPointerSpeedController.requestShizukuPermission(REQ_SHIZUKU);
        } else {
            Toast.makeText(this, "Không tăng được Height", Toast.LENGTH_SHORT).show();
        }
    }

    private void applyHeightMinus20() {
        boolean ok = ShizukuDpiController.decreaseHeightBy20(this);
        if (ok) {
            Toast.makeText(this, "Đã giảm Height -20", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!ShizukuPointerSpeedController.isShizukuRunning()) {
            Toast.makeText(this, "Shizuku chưa chạy", Toast.LENGTH_SHORT).show();
        } else if (!ShizukuPointerSpeedController.hasShizukuPermission()) {
            Toast.makeText(this, "Chưa cấp quyền Shizuku", Toast.LENGTH_SHORT).show();
            ShizukuPointerSpeedController.requestShizukuPermission(REQ_SHIZUKU);
        } else {
            Toast.makeText(this, "Không giảm được Height", Toast.LENGTH_SHORT).show();
        }
    }

    private void applyReduceLag() {
        boolean ok = ShizukuDpiController.applyReduceLag(this);
        if (ok) {
            Toast.makeText(this, "Đã chạy Giảm lag (có thể cần khởi động lại máy/app)", Toast.LENGTH_LONG).show();
            return;
        }

        if (!ShizukuPointerSpeedController.isShizukuRunning()) {
            Toast.makeText(this, "Shizuku chưa chạy", Toast.LENGTH_SHORT).show();
        } else if (!ShizukuPointerSpeedController.hasShizukuPermission()) {
            Toast.makeText(this, "Chưa cấp quyền Shizuku", Toast.LENGTH_SHORT).show();
            ShizukuPointerSpeedController.requestShizukuPermission(REQ_SHIZUKU);
        } else {
            Toast.makeText(this, "Không áp dụng được Giảm lag (APN thường bị chặn quyền)", Toast.LENGTH_LONG).show();
        }
    }

    private void updatePointerSpeedText() {
        if (btnPointerSpeed == null) return;
        int v = getSavedPointerSpeed();
        btnPointerSpeed.setText("Tốc độ con trỏ: " + v);
    }

    private int getSavedPointerSpeed() {
        SharedPreferences sp = getSharedPreferences(PREFS, MODE_PRIVATE);
        return sp.getInt(KEY_POINTER_SPEED, 0);
    }

    private void savePointerSpeed(int v) {
        SharedPreferences sp = getSharedPreferences(PREFS, MODE_PRIVATE);
        sp.edit().putInt(KEY_POINTER_SPEED, v).apply();
    }

    private void startSvc(String action) {
        Intent i = new Intent(this, filteroverlayservice.class);
        i.setAction(action);

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i);
            else startService(i);
        } catch (Throwable t) {
            Toast.makeText(this, "startService lỗi: " + t.getClass().getSimpleName(), Toast.LENGTH_SHORT).show();
        }
    }

    private boolean ensureAllPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Chưa cấp quyền Overlay", Toast.LENGTH_SHORT).show();
            openOverlaySettings();
            return false;
        }

        if (!areNotificationsEnabled()) {
            Toast.makeText(this, "Bạn đang tắt thông báo của app", Toast.LENGTH_LONG).show();
            openNotificationSettings();
            return false;
        }

        if (Build.VERSION.SDK_INT >= 33) {
            if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIF);
                Toast.makeText(this, "Hãy cấp quyền thông báo rồi bấm lại", Toast.LENGTH_SHORT).show();
                return false;
            }
        }

        return true;
    }

    private boolean areNotificationsEnabled() {
        try {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            return nm != null && nm.areNotificationsEnabled();
        } catch (Throwable t) {
            return true;
        }
    }

    private void openOverlaySettings() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
								  Uri.parse("package:" + getPackageName()));
            startActivity(i);
        }
    }

    private void openNotificationSettings() {
        try {
            Intent i = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS);
            i.putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName());
            startActivity(i);
        } catch (Throwable t) {
            Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
								  Uri.parse("package:" + getPackageName()));
            startActivity(i);
        }
    }

    private static int clamp(int v, int min, int max) {
        return Math.max(min, Math.min(max, v));
    }
}

