package com.assistive.filter;

public final class AssistiveRecoil {

    private AssistiveRecoil() {}

    public static float vpFromDistanceM(float d) {
        if (d <= 1.0f) return 3.05f;

        if (d < 5.0f) {
            double p = 0.71;
            double s = 3.05 / Math.pow(d, p);
            if (s > 3.05) s = 3.05;
            if (s < 0.97) s = 0.97;
            return (float) s;
        }

        if (d >= 20.0f) return 0.38f;

        float t = (d - 5.0f) / 15.0f;
        float s = 0.97f + t * (0.38f - 0.97f);
        if (s < 0.38f) s = 0.38f;
        if (s > 0.97f) s = 0.97f;
        return s;
    }

    public static float[] velocityMmPerSec(double dMeters, double vp, double tSec) {
        if (dMeters <= 0.0) return null;
        if (vp <= 0.0) return null;
        if (tSec < 0.0) tSec = 0.0;

        double denom = (dMeters + 3.5) * vp;
        if (denom <= 0.0) return null;

        if (tSec <= 0.2) {
            double vx = 409.0 / (0.2 * denom);
            double vy = 35.0;
            return new float[]{(float) vx, (float) vy};
        }

        double a = 0.1 + (0.05 * (tSec - 0.2));
        double w = 753.6;
        double x = w * (tSec - 0.2);

        double vx = 2046.0 / denom + (w * a * Math.cos(x));

        double denomY = dMeters * (dMeters + 3.5) * vp;
        if (denomY <= 0.0) return null;

        double vy = 150.0 / denomY - (w * a * Math.sin(x));

        return new float[]{(float) vx, (float) vy};
    }
}

