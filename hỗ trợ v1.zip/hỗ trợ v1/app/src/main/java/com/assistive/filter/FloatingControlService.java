package com.assistive.filter;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.os.Parcel;
import android.util.Base64;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.Toast;

public class FloatingControlService extends Service {

    private static final int NOTIF_ID = 5005;
    private static final String CHANNEL_ID = "floating_control";
    private WindowManager wm;
    private View floatingView;
    private WindowManager.LayoutParams params;
    private boolean lensVisible = true;
    private boolean lensStarted = false;

    @Override
    public void onCreate() {
        super.onCreate();
        startForegroundSafe();
        setupFloatingButtons();
    }

    private void startForegroundSafe() {
        try {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (nm == null) return;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                NotificationChannel ch = new NotificationChannel(CHANNEL_ID, "Floating Control", NotificationManager.IMPORTANCE_MIN);
                ch.setSound(null, null);
                nm.createNotificationChannel(ch);
            }
            Notification.Builder b = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
				? new Notification.Builder(this, CHANNEL_ID) : new Notification.Builder(this);
            Notification n = b.setOngoing(true)
				.setSmallIcon(android.R.drawable.ic_menu_edit)
				.setContentTitle("Assistive Control")
				.setContentText("Buttons ready")
				.build();
            startForeground(NOTIF_ID, n);
        } catch (Throwable t) {
            stopSelf();
        }
    }

    private void setupFloatingButtons() {
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        LayoutInflater inflater = LayoutInflater.from(this);
        floatingView = inflater.inflate(R.layout.floating_control, null);
        int layoutFlag = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
			? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
			: WindowManager.LayoutParams.TYPE_PHONE;
        params = new WindowManager.LayoutParams(
			WindowManager.LayoutParams.WRAP_CONTENT,
			WindowManager.LayoutParams.WRAP_CONTENT,
			layoutFlag,
			WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
			PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.START;
        params.x = 100;
        params.y = 100;

        floatingView.setOnTouchListener(new View.OnTouchListener() {
				private int initialX, initialY;
				private float initialTouchX, initialTouchY;

				@Override
				public boolean onTouch(View v, MotionEvent event) {
					switch (event.getAction()) {
						case MotionEvent.ACTION_DOWN:
							initialX = params.x;
							initialY = params.y;
							initialTouchX = event.getRawX();
							initialTouchY = event.getRawY();
							return true;
						case MotionEvent.ACTION_MOVE:
							params.x = initialX + (int) (event.getRawX() - initialTouchX);
							params.y = initialY + (int) (event.getRawY() - initialTouchY);
							wm.updateViewLayout(floatingView, params);
							return true;
					}
					return false;
				}
			});

        Button btnStartLens = floatingView.findViewById(R.id.btn_start_lens);
        Button btnToggleVisible = floatingView.findViewById(R.id.btn_toggle_visible);

        btnStartLens.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					if (!lensStarted) {
						startLensService();
					} else {
						Toast.makeText(FloatingControlService.this, "Lens already running", Toast.LENGTH_SHORT).show();
					}
				}
			});

        btnToggleVisible.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					Intent intent = new Intent(FloatingControlService.this, enhancelensservice.class);
					if (lensVisible) {
						intent.setAction(enhancelensservice.ACTION_HIDE_LENS);
						lensVisible = false;
					} else {
						intent.setAction(enhancelensservice.ACTION_SHOW_LENS);
						lensVisible = true;
					}
					startService(intent);
				}
			});

        wm.addView(floatingView, params);
    }

    private void startLensService() {
        SharedPreferences prefs = getSharedPreferences("assistive_prefs", MODE_PRIVATE);
        int resultCode = prefs.getInt("lens_result_code", 0);
        String encoded = prefs.getString("lens_result_data", null);
        if (resultCode == 0 || encoded == null) {
            Toast.makeText(this, "Chưa có quyền chụp màn hình. Hãy bật lens từ MainActivity trước!", Toast.LENGTH_LONG).show();
            return;
        }
        byte[] bytes = Base64.decode(encoded, Base64.DEFAULT);
        Parcel parcel = Parcel.obtain();
        parcel.unmarshall(bytes, 0, bytes.length);
        parcel.setDataPosition(0);
        Intent data = Intent.CREATOR.createFromParcel(parcel);
        parcel.recycle();

        Intent intent = new Intent(this, enhancelensservice.class);
        intent.setAction(enhancelensservice.ACTION_START_LOCKED);
        intent.putExtra(enhancelensservice.EXTRA_RESULT_CODE, resultCode);
        intent.putExtra(enhancelensservice.EXTRA_RESULT_DATA, data);
        startService(intent);
        lensStarted = true;
        Toast.makeText(this, "Đã bật lens", Toast.LENGTH_SHORT).show();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        if (floatingView != null && wm != null) {
            try { wm.removeView(floatingView); } catch (Throwable ignore) {}
        }
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
