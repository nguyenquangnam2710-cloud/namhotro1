package com.assistive.filter;

import android.os.Binder;
import android.os.IBinder;
import android.os.Parcel;
import android.os.RemoteException;

import java.io.InputStream;

public final class DpiUserService extends Binder {

    static final String DESCRIPTOR = "com.assistive.filter.DpiUserService";

    static final int TRANSACTION_GET_PHYSICAL_DPI = IBinder.FIRST_CALL_TRANSACTION;
    static final int TRANSACTION_GET_PHYSICAL_SIZE = IBinder.FIRST_CALL_TRANSACTION + 1;

    static final int TRANSACTION_SET_DPI = IBinder.FIRST_CALL_TRANSACTION + 2;
    static final int TRANSACTION_SET_SIZE = IBinder.FIRST_CALL_TRANSACTION + 3;

    static final int TRANSACTION_RESET_ALL = IBinder.FIRST_CALL_TRANSACTION + 4;

    static final int TRANSACTION_GET_CURRENT_SIZE = IBinder.FIRST_CALL_TRANSACTION + 5;

    static final int TRANSACTION_APPLY_REDUCE_LAG = IBinder.FIRST_CALL_TRANSACTION + 6;

    @Override
    protected boolean onTransact(int code, Parcel data, Parcel reply, int flags) throws RemoteException {
        if (code == INTERFACE_TRANSACTION) {
            reply.writeString(DESCRIPTOR);
            return true;
        }

        if (code == TRANSACTION_GET_PHYSICAL_DPI) {
            data.enforceInterface(DESCRIPTOR);
            int dpi = getPhysicalDpi();
            reply.writeNoException();
            reply.writeInt(dpi);
            return true;
        }

        if (code == TRANSACTION_GET_PHYSICAL_SIZE) {
            data.enforceInterface(DESCRIPTOR);
            int[] wh = getPhysicalSize();
            reply.writeNoException();
            if (wh != null) {
                reply.writeInt(1);
                reply.writeInt(wh[0]);
                reply.writeInt(wh[1]);
            } else {
                reply.writeInt(0);
            }
            return true;
        }

        if (code == TRANSACTION_SET_DPI) {
            data.enforceInterface(DESCRIPTOR);
            int dpi = data.readInt();
            boolean ok = run("wm density " + dpi);
            reply.writeNoException();
            reply.writeInt(ok ? 1 : 0);
            return true;
        }

        if (code == TRANSACTION_SET_SIZE) {
            data.enforceInterface(DESCRIPTOR);
            int w = data.readInt();
            int h = data.readInt();
            boolean ok = run("wm size " + w + "x" + h);
            reply.writeNoException();
            reply.writeInt(ok ? 1 : 0);
            return true;
        }

        if (code == TRANSACTION_RESET_ALL) {
            data.enforceInterface(DESCRIPTOR);
            boolean ok1 = run("wm density reset");
            boolean ok2 = run("wm size reset");
            boolean ok3 = run("settings put system font_scale 1.0");
            reply.writeNoException();
            reply.writeInt((ok1 && ok2 && ok3) ? 1 : 0);
            return true;
        }

        if (code == TRANSACTION_GET_CURRENT_SIZE) {
            data.enforceInterface(DESCRIPTOR);
            int[] wh = getCurrentSize();
            reply.writeNoException();
            if (wh != null) {
                reply.writeInt(1);
                reply.writeInt(wh[0]);
                reply.writeInt(wh[1]);
            } else {
                reply.writeInt(0);
            }
            return true;
        }

        if (code == TRANSACTION_APPLY_REDUCE_LAG) {
            data.enforceInterface(DESCRIPTOR);

            boolean ok1 = run("setprop debug.hwui.renderer skiagl");
            boolean ok2 = run("setprop debug.egl.force_msaa true");
            boolean ok3 = applyApnGameHighSpeed();

            reply.writeNoException();
            reply.writeInt((ok1 && ok2 && ok3) ? 1 : 0);
            return true;
        }

        return super.onTransact(code, data, reply, flags);
    }

    private static boolean applyApnGameHighSpeed() {
        String name = "Game High Speed";
        String apn = "internet";
        String server = "8.8.8.8";
        String mcc = "452";
        String mnc = "02";
        String numeric = "45202";
        String apnType = "default,supl";
        String protocol = "IPV4V6";
        int bearer = 13;
        int authtype = 2;

        String insert = ""
			+ "content insert --uri content://telephony/carriers "
			+ "--bind name:s:'" + escapeSingleQuote(name) + "' "
			+ "--bind apn:s:'" + escapeSingleQuote(apn) + "' "
			+ "--bind server:s:'" + escapeSingleQuote(server) + "' "
			+ "--bind mcc:s:'" + escapeSingleQuote(mcc) + "' "
			+ "--bind mnc:s:'" + escapeSingleQuote(mnc) + "' "
			+ "--bind numeric:s:'" + escapeSingleQuote(numeric) + "' "
			+ "--bind type:s:'" + escapeSingleQuote(apnType) + "' "
			+ "--bind protocol:s:'" + escapeSingleQuote(protocol) + "' "
			+ "--bind roaming_protocol:s:'" + escapeSingleQuote(protocol) + "' "
			+ "--bind bearer:i:" + bearer + " "
			+ "--bind authtype:i:" + authtype + " "
			+ "--bind carrier_enabled:i:1";

        boolean okInsert = run(insert);

        String q = ""
			+ "content query --uri content://telephony/carriers "
			+ "--projection _id "
			+ "--where \"name='" + escapeDoubleQuoteWhere(name)
			+ "' AND apn='" + escapeDoubleQuoteWhere(apn)
			+ "' AND numeric='" + escapeDoubleQuoteWhere(numeric) + "'\"";

        String out = runCapture(q);
        int id = out == null ? 0 : extractFirstInt(out);
        if (id <= 0) return okInsert;

        boolean okPrefer1 = run("content insert --uri content://telephony/carriers/preferapn --bind apn_id:i:" + id);
        boolean okPrefer2 = run("content update --uri content://telephony/carriers/preferapn --bind apn_id:i:" + id);

        return okInsert && (okPrefer1 || okPrefer2);
    }

    private static String escapeSingleQuote(String s) {
        if (s == null) return "";
        return s.replace("'", "'\"'\"'");
    }

    private static String escapeDoubleQuoteWhere(String s) {
        if (s == null) return "";
        return s.replace("\"", "\\\"");
    }

    private static int getPhysicalDpi() {
        String out = runCapture("wm density");
        if (out == null) return 0;

        int dpi = extractAfter(out, "Physical density:");
        if (dpi > 0) return dpi;

        dpi = extractAfter(out, "Override density:");
        if (dpi > 0) return dpi;

        return extractFirstInt(out);
    }

    private static int[] getPhysicalSize() {
        String out = runCapture("wm size");
        if (out == null) return null;

        int[] wh = extractSizeAfter(out, "Physical size:");
        if (wh != null) return wh;

        return extractFirstSize(out);
    }

    private static int[] getCurrentSize() {
        String out = runCapture("wm size");
        if (out == null) return null;

        int[] wh = extractSizeAfter(out, "Override size:");
        if (wh != null) return wh;

        wh = extractSizeAfter(out, "Physical size:");
        if (wh != null) return wh;

        return extractFirstSize(out);
    }

    private static int extractAfter(String s, String marker) {
        int idx = s.indexOf(marker);
        if (idx < 0) return 0;
        String tail = s.substring(idx + marker.length());
        return extractFirstInt(tail);
    }

    private static int extractFirstInt(String s) {
        int i = 0;
        while (i < s.length() && !Character.isDigit(s.charAt(i))) i++;
        int j = i;
        while (j < s.length() && Character.isDigit(s.charAt(j))) j++;
        if (i >= j) return 0;
        try {
            return Integer.parseInt(s.substring(i, j));
        } catch (Throwable t) {
            return 0;
        }
    }

    private static int[] extractSizeAfter(String s, String marker) {
        int idx = s.indexOf(marker);
        if (idx < 0) return null;
        return extractFirstSize(s.substring(idx + marker.length()));
    }

    private static int[] extractFirstSize(String s) {
        int x = s.indexOf('x');
        if (x < 0) return null;

        int leftStart = x - 1;
        while (leftStart >= 0 && Character.isDigit(s.charAt(leftStart))) leftStart--;
        leftStart++;

        int rightEnd = x + 1;
        while (rightEnd < s.length() && Character.isDigit(s.charAt(rightEnd))) rightEnd++;

        if (leftStart >= x) return null;
        if (x + 1 >= rightEnd) return null;

        try {
            int w = Integer.parseInt(s.substring(leftStart, x));
            int h = Integer.parseInt(s.substring(x + 1, rightEnd));
            if (w > 0 && h > 0) return new int[]{w, h};
            return null;
        } catch (Throwable t) {
            return null;
        }
    }

    private static boolean run(String cmd) {
        try {
            Process p = new ProcessBuilder("sh", "-c", cmd).redirectErrorStream(true).start();
            drain(p.getInputStream());
            int code = p.waitFor();
            return code == 0;
        } catch (Throwable t) {
            return false;
        }
    }

    private static String runCapture(String cmd) {
        try {
            Process p = new ProcessBuilder("sh", "-c", cmd).redirectErrorStream(true).start();
            String out = readAll(p.getInputStream());
            p.waitFor();
            return out;
        } catch (Throwable t) {
            return null;
        }
    }

    private static void drain(InputStream is) {
        if (is == null) return;
        byte[] buf = new byte[4096];
        try { while (is.read(buf) != -1) {} } catch (Throwable ignore) {}
        try { is.close(); } catch (Throwable ignore) {}
    }

    private static String readAll(InputStream is) {
        if (is == null) return null;
        StringBuilder sb = new StringBuilder();
        byte[] buf = new byte[4096];
        try {
            int n;
            while ((n = is.read(buf)) != -1) sb.append(new String(buf, 0, n));
        } catch (Throwable ignore) {}
        try { is.close(); } catch (Throwable ignore) {}
        return sb.toString();
    }
}

