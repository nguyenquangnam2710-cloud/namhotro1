package com.assistive.filter;

import android.content.ComponentName;
import android.content.Context;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.os.Parcel;

import rikka.shizuku.Shizuku;

public final class ShizukuPointerSpeedController {

    public static final int MIN = -7;
    public static final int MAX = 7;

    private static final String TAG = "pointer_speed_service";
    private static volatile IBinder sService;

    private static final ServiceConnection CONN = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            sService = service;
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            sService = null;
        }
    };

    private ShizukuPointerSpeedController() {}

    public static boolean isShizukuRunning() {
        try {
            return Shizuku.pingBinder();
        } catch (Throwable t) {
            return false;
        }
    }

    public static boolean hasShizukuPermission() {
        try {
            return Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED;
        } catch (Throwable t) {
            return false;
        }
    }

    public static void requestShizukuPermission(int requestCode) {
        try {
            Shizuku.requestPermission(requestCode);
        } catch (Throwable ignore) {}
    }

    public static boolean connect(Context context) {
        if (context == null) return false;
        if (!isShizukuRunning() || !hasShizukuPermission()) return false;

        try {
            Shizuku.UserServiceArgs args = new Shizuku.UserServiceArgs(
				new ComponentName(context.getPackageName(), PointerSpeedUserService.class.getName()))
				.tag(TAG)
				.version(1)
				.processNameSuffix("ps");

            Shizuku.bindUserService(args, CONN);
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    public static boolean isConnected() {
        IBinder b = sService;
        return b != null && b.isBinderAlive();
    }

    public static boolean setPointerSpeed(int value) {
        int v = clamp(value, MIN, MAX);

        IBinder b = sService;
        if (b == null) return false;

        Parcel data = Parcel.obtain();
        Parcel reply = Parcel.obtain();
        try {
            data.writeInterfaceToken(PointerSpeedUserService.DESCRIPTOR);
            data.writeInt(v);
            b.transact(PointerSpeedUserService.TRANSACTION_SET, data, reply, 0);
            reply.readException();
            return reply.readInt() != 0;
        } catch (Throwable t) {
            return false;
        } finally {
            data.recycle();
            reply.recycle();
        }
    }
	public static boolean setPointerSpeed(Context context, int value) {
		if (!isConnected()) {
			connect(context);
		}
		return setPointerSpeed(value);
	}
	
    private static int clamp(int v, int min, int max) {
        return Math.max(min, Math.min(max, v));
    }
}

