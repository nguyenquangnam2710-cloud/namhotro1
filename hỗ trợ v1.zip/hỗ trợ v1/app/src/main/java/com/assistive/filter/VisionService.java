package com.assistive.filter;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Binder;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.util.DisplayMetrics;

import java.nio.ByteBuffer;
import java.util.concurrent.atomic.AtomicBoolean;

public final class VisionService extends Service {

    public static final String ACTION_START = "com.assistive.filter.VISION_START";
    public static final String ACTION_STOP = "com.assistive.filter.VISION_STOP";

    public static final String EXTRA_RESULT_CODE = "result_code";
    public static final String EXTRA_RESULT_DATA = "result_data";

    private static final int NOTIF_ID = 5101;
    private static final String CHANNEL_ID = "assistive_vision";

    private MediaProjection projection;
    private VirtualDisplay vdisplay;
    private ImageReader reader;

    private HandlerThread workerThread;
    private Handler worker;

    private final AtomicBoolean processing = new AtomicBoolean(false);

    private volatile TargetSample lastSample;

    private static volatile TargetSample sLatest;

    public static TargetSample peekLatest() {
        return sLatest;
    }

    public final class VisionBinder extends Binder {
        public TargetSample readLatest() {
            return lastSample;
        }
    }

    private final VisionBinder binder = new VisionBinder();

    @Override
    public void onCreate() {
        super.onCreate();

        workerThread = new HandlerThread("vision_worker");
        workerThread.start();
        worker = new Handler(workerThread.getLooper());
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent != null ? intent.getAction() : null;

        if (ACTION_STOP.equals(action)) {
            shutdownProjection();
            stopForeground(true);
            stopSelf();
            return START_NOT_STICKY;
        }

        startForegroundSafe();

        if (projection == null) {
            int resultCode = intent != null ? intent.getIntExtra(EXTRA_RESULT_CODE, 0) : 0;
            Intent data = intent != null ? intent.getParcelableExtra(EXTRA_RESULT_DATA) : null;
            if (resultCode != 0 && data != null) {
                setupProjection(resultCode, data);
            }
        }

        return START_STICKY;
    }

    private void startForegroundSafe() {
        try {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (nm == null) return;

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                NotificationChannel ch = new NotificationChannel(
                    CHANNEL_ID, "Vision", NotificationManager.IMPORTANCE_MIN);
                ch.setSound(null, null);
                nm.createNotificationChannel(ch);
            }

            Notification.Builder b = (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);

            Notification n = b.setOngoing(true)
                .setSmallIcon(android.R.drawable.ic_menu_camera)
                .setContentTitle("Assistive")
                .setContentText("Vision running")
                .build();

            startForeground(NOTIF_ID, n);
        } catch (Throwable ignore) {
        }
    }

    private void setupProjection(int resultCode, Intent data) {
        try {
            MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
            if (mpm == null) return;

            projection = mpm.getMediaProjection(resultCode, data);
            if (projection == null) return;

            DisplayMetrics dm = getResources().getDisplayMetrics();
            int w = dm.widthPixels;
            int h = dm.heightPixels;
            int dpi = dm.densityDpi;

            reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2);

            vdisplay = projection.createVirtualDisplay(
                "assistive_vision",
                w,
                h,
                dpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                reader.getSurface(),
                null,
                worker
            );

            reader.setOnImageAvailableListener(new ImageReader.OnImageAvailableListener() {
					@Override
					public void onImageAvailable(ImageReader ir) {
						if (processing.getAndSet(true)) return;
						worker.post(new Runnable() {
								@Override
								public void run() {
									try {
										processFrame();
									} finally {
										processing.set(false);
									}
								}
							});
					}
				}, worker);

        } catch (Throwable ignore) {
        }
    }

    private void processFrame() {
        ImageReader ir = reader;
        if (ir == null) return;

        Image img = null;
        try {
            img = ir.acquireLatestImage();
            if (img == null) return;

            Image.Plane[] planes = img.getPlanes();
            if (planes == null || planes.length < 1) return;

            DisplayMetrics dm = getResources().getDisplayMetrics();
            int sw = dm.widthPixels;

            ByteBuffer buf = planes[0].getBuffer();
            int pixelStride = planes[0].getPixelStride();
            int rowStride = planes[0].getRowStride();

            int down = 3;
            int w = Math.max(1, sw / down);
            int h = Math.max(1, dm.heightPixels / down);

            long sumX = 0;
            long sumY = 0;
            int cnt = 0;

            for (int y = 0; y < h; y++) {
                int sy = y * down;
                int rowOff = sy * rowStride;
                for (int x = 0; x < w; x++) {
                    int sx = x * down;
                    int off = rowOff + sx * pixelStride;

                    int b = buf.get(off) & 255;
                    int g = buf.get(off + 1) & 255;
                    int r = buf.get(off + 2) & 255;

                    if (isSkinYCbCr(r, g, b)) {
                        cnt++;
                        sumX += sx;
                        sumY += sy;
                    }
                }
            }

            float conf = Math.min(1f, cnt / Math.max(1f, (w * h * 0.08f)));
            long now = System.currentTimeMillis();

            if (cnt < 120 || conf < 0.10f) {
                lastSample = new TargetSample(now, -1f, -1f, 0f, 0f, 0f);
                sLatest = lastSample;
                return;
            }

            float cx = (float) (sumX / (double) cnt);
            float cy = (float) (sumY / (double) cnt);

            TargetSample prev = lastSample;
            float dt = 0.016f;
            if (prev != null) {
                long dms = now - prev.tMillis;
                if (dms < 1) dms = 1;
                if (dms > 50) dms = 50;
                dt = dms / 1000f;
            }

            float vx = 0f;
            float vy = 0f;
            if (prev != null && prev.x >= 0f && prev.y >= 0f) {
                vx = (cx - prev.x) / dt;
                vy = (cy - prev.y) / dt;
            }

            vx = clamp(vx, -8000f, 8000f);
            vy = clamp(vy, -8000f, 8000f);

            lastSample = new TargetSample(now, cx, cy, vx, vy, conf);
            sLatest = lastSample;

        } catch (Throwable ignore) {
        } finally {
            try {
                if (img != null) img.close();
            } catch (Throwable ignore2) {
            }
        }
    }

    private float clamp(float v, float lo, float hi) {
        if (v < lo) return lo;
        if (v > hi) return hi;
        return v;
    }

    private boolean isSkinYCbCr(int r, int g, int b) {
        int cb = ((-43 * r - 85 * g + 128 * b) >> 8) + 128;
        int cr = ((128 * r - 107 * g - 21 * b) >> 8) + 128;
        if (r < 55 || g < 30 || b < 15) return false;
        return cb >= 75 && cb <= 130 && cr >= 132 && cr <= 175;
    }

    private void shutdownProjection() {
        try {
            if (reader != null) reader.setOnImageAvailableListener(null, null);
        } catch (Throwable ignore) {
        }
        try {
            if (vdisplay != null) vdisplay.release();
        } catch (Throwable ignore) {
        }
        try {
            if (projection != null) projection.stop();
        } catch (Throwable ignore) {
        }
        reader = null;
        vdisplay = null;
        projection = null;
    }

    @Override
    public void onDestroy() {
        shutdownProjection();
        try {
            if (workerThread != null) workerThread.quitSafely();
        } catch (Throwable ignore) {
        }
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return binder;
    }
}

