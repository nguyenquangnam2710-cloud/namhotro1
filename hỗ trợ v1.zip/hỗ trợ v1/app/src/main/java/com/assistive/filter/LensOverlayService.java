package com.assistive.filter;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.WindowManager;

public final class LensOverlayService extends Service {

    public static final String ACTION_START = "com.assistive.filter.LENS_OVERLAY_START";
    public static final String ACTION_STOP = "com.assistive.filter.LENS_OVERLAY_STOP";

    private static final int NOTIF_ID = 5103;
    private static final String CHANNEL_ID = "assistive_lens_overlay";

    private WindowManager wm;
    private WindowManager.LayoutParams params;
    private LensRingView overlay;

    private int touchSlop;
    private int startX;
    private int startY;
    private float downRawX;
    private float downRawY;

    private ScaleGestureDetector scaleDetector;
    private float scale = 1.0f;
    private int baseSizePx;
    private int screenW;
    private int screenH;

    @Override
    public void onCreate() {
        super.onCreate();

        startForegroundSafe();

        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        touchSlop = ViewConfiguration.get(this).getScaledTouchSlop();

        float d = getResources().getDisplayMetrics().density;
        baseSizePx = (int) (240f * d);
        if (baseSizePx < 160) baseSizePx = 160;

        updateScreenSize();

        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
			? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
			: WindowManager.LayoutParams.TYPE_PHONE;

        params = new WindowManager.LayoutParams(
			baseSizePx,
			baseSizePx,
			type,
			WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
			| WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
			PixelFormat.TRANSLUCENT
        );
        params.gravity = Gravity.TOP | Gravity.START;

        DisplayMetrics dm = getResources().getDisplayMetrics();
        params.x = (dm.widthPixels / 2) - (baseSizePx / 2);
        params.y = (dm.heightPixels / 2) - (baseSizePx / 2);

        overlay = new LensRingView(this);

        scaleDetector = new ScaleGestureDetector(this, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
				@Override
				public boolean onScale(ScaleGestureDetector detector) {
					scale *= detector.getScaleFactor();
					if (scale < 0.25f) scale = 0.25f;
					if (scale > 3.0f) scale = 3.0f;

					applySize((int) (baseSizePx * scale));
					updateLayoutSafe();
					return true;
				}
			});

        overlay.setOnTouchListener(new View.OnTouchListener() {
				private boolean moved;

				@Override
				public boolean onTouch(View v, MotionEvent e) {
					try { scaleDetector.onTouchEvent(e); } catch (Throwable ignore) {}
					if (scaleDetector != null && scaleDetector.isInProgress()) return true;

					switch (e.getActionMasked()) {
						case MotionEvent.ACTION_DOWN:
							moved = false;
							downRawX = e.getRawX();
							downRawY = e.getRawY();
							startX = params.x;
							startY = params.y;
							return true;

						case MotionEvent.ACTION_MOVE: {
								float rawDx = e.getRawX() - downRawX;
								float rawDy = e.getRawY() - downRawY;

								if (!moved && (Math.abs(rawDx) > touchSlop || Math.abs(rawDy) > touchSlop)) {
									moved = true;
								}

								params.x = startX + Math.round(rawDx);
								params.y = startY + Math.round(rawDy);

								clampToScreen();
								updateLayoutSafe();
								return true;
							}

						case MotionEvent.ACTION_UP:
						case MotionEvent.ACTION_CANCEL:
							return true;
					}

					return true;
				}
			});

        addOverlayIfNeeded();
        clampToScreen();
        updateLayoutSafe();
    }

    private void startForegroundSafe() {
        try {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (nm == null) return;

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                NotificationChannel ch = new NotificationChannel(
					CHANNEL_ID, "Lens Overlay", NotificationManager.IMPORTANCE_MIN);
                ch.setSound(null, null);
                nm.createNotificationChannel(ch);
            }

            Notification.Builder b = (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
				? new Notification.Builder(this, CHANNEL_ID)
				: new Notification.Builder(this);

            Notification n = b.setOngoing(true)
				.setSmallIcon(android.R.drawable.ic_menu_view)
				.setContentTitle("Assistive")
				.setContentText("Lens overlay")
				.build();

            startForeground(NOTIF_ID, n);
        } catch (Throwable ignore) {}
    }

    private void updateScreenSize() {
        DisplayMetrics dm = getResources().getDisplayMetrics();
        screenW = dm.widthPixels;
        screenH = dm.heightPixels;
        if (screenW < 1) screenW = 1080;
        if (screenH < 1) screenH = 1920;
    }

    private void clampToScreen() {
        updateScreenSize();

        int maxX = Math.max(0, screenW - params.width);
        int maxY = Math.max(0, screenH - params.height);

        if (params.x < 0) params.x = 0;
        if (params.y < 0) params.y = 0;
        if (params.x > maxX) params.x = maxX;
        if (params.y > maxY) params.y = maxY;
    }

    private void applySize(int newSizePx) {
        updateScreenSize();

        int old = params.width;
        int cx = params.x + (old / 2);
        int cy = params.y + (old / 2);

        int sz = newSizePx;
        if (sz < 120) sz = 120;
        if (sz > screenW) sz = screenW;
        if (sz > screenH) sz = screenH;

        params.width = sz;
        params.height = sz;

        params.x = cx - (sz / 2);
        params.y = cy - (sz / 2);

        clampToScreen();
    }

    private void addOverlayIfNeeded() {
        if (overlay == null || overlay.getParent() != null) return;
        try { wm.addView(overlay, params); } catch (Throwable ignore) {}
    }

    private void updateLayoutSafe() {
        try {
            if (wm != null && overlay != null && overlay.getParent() != null) wm.updateViewLayout(overlay, params);
        } catch (Throwable ignore) {}
    }

    @Override
    public int onStartCommand(android.content.Intent intent, int flags, int startId) {
        String action = intent != null ? intent.getAction() : null;
        if (ACTION_STOP.equals(action)) {
            stopSelf();
            return START_NOT_STICKY;
        }
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        try { if (wm != null && overlay != null && overlay.getParent() != null) wm.removeView(overlay); } catch (Throwable ignore) {}
        super.onDestroy();
    }

    @Override
    public IBinder onBind(android.content.Intent intent) { return null; }
}

