package com.assistive.filter;

import rikka.shizuku.Shizuku;
import java.lang.reflect.Method;

public class ShizukuHelper {
    public static void runCommand(String[] cmd) {
        try {
            Method m = Shizuku.class.getDeclaredMethod("newProcess", String[].class, String[].class, String.class);
            m.setAccessible(true);
            m.invoke(null, (Object) cmd, null, null);
        } catch (Exception e) {
            try {
                Runtime.getRuntime().exec(cmd);
            } catch (Exception ignored) {}
        }
    }
}
