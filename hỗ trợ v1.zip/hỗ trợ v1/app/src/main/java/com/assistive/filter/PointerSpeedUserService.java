package com.assistive.filter;

import android.os.Binder;
import android.os.IBinder;
import android.os.Parcel;
import android.os.RemoteException;

import java.io.InputStream;

public final class PointerSpeedUserService extends Binder {

    static final String DESCRIPTOR = "com.assistive.filter.PointerSpeedUserService";
    static final int TRANSACTION_SET = IBinder.FIRST_CALL_TRANSACTION;

    @Override
    protected boolean onTransact(int code, Parcel data, Parcel reply, int flags) throws RemoteException {
        if (code == INTERFACE_TRANSACTION) {
            reply.writeString(DESCRIPTOR);
            return true;
        }

        if (code == TRANSACTION_SET) {
            data.enforceInterface(DESCRIPTOR);
            int v = data.readInt();
            boolean ok = apply(v);
            reply.writeNoException();
            reply.writeInt(ok ? 1 : 0);
            return true;
        }

        return super.onTransact(code, data, reply, flags);
    }

    private static boolean apply(int v) {
        if (v < -7) v = -7;
        if (v > 7) v = 7;

        try {
            Process p = new ProcessBuilder("sh", "-c", "settings put system pointer_speed " + v)
				.redirectErrorStream(true)
				.start();
            drain(p.getInputStream());
            int code = p.waitFor();
            return code == 0;
        } catch (Throwable t) {
            return false;
        }
    }

    private static void drain(InputStream is) {
        if (is == null) return;
        byte[] buf = new byte[4096];
        try { while (is.read(buf) != -1) {} } catch (Throwable ignore) {}
        try { is.close(); } catch (Throwable ignore) {}
    }
}

