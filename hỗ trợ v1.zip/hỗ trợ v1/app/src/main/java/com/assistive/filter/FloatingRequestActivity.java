package com.assistive.filter;

import android.app.Activity;
import android.content.Intent;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Bundle;
import android.widget.Toast;

public class FloatingRequestActivity extends Activity {

    private static final int REQ_MEDIA_PROJECTION = 1001;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        if (mpm == null) {
            Toast.makeText(this, "Không hỗ trợ MediaProjection", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }
        startActivityForResult(mpm.createScreenCaptureIntent(), REQ_MEDIA_PROJECTION);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_MEDIA_PROJECTION) {
            if (resultCode == RESULT_OK && data != null) {
                Intent serviceIntent = new Intent(this, enhancelensservice.class);
                serviceIntent.setAction(enhancelensservice.ACTION_START_LOCKED);
                serviceIntent.putExtra(enhancelensservice.EXTRA_RESULT_CODE, resultCode);
                serviceIntent.putExtra(enhancelensservice.EXTRA_RESULT_DATA, data);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    startForegroundService(serviceIntent);
                } else {
                    startService(serviceIntent);
                }
                Toast.makeText(this, "Đã bật lens", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Bạn chưa cấp quyền chụp màn hình", Toast.LENGTH_SHORT).show();
            }
        }
        finish();
    }
}
