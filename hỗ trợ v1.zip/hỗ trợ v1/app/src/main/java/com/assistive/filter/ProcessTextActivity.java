package com.assistive.filter;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;

import java.net.URLEncoder;
import java.util.Locale;

public final class ProcessTextActivity extends Activity {

    private TextToSpeech tts;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        final CharSequence cs = getIntent() != null ? getIntent().getCharSequenceExtra(Intent.EXTRA_PROCESS_TEXT) : null;
        final String text = cs != null ? cs.toString() : "";

        if (text.length() == 0) {
            finish();
            return;
        }

        new AlertDialog.Builder(this)
            .setTitle("Assistive")
            .setMessage(text)
            .setNegativeButton("Đóng", new DialogInterface.OnClickListener() {
                @Override public void onClick(DialogInterface dialog, int which) {
                    finish();
                }
            })
            .setNeutralButton("Đọc", new DialogInterface.OnClickListener() {
                @Override public void onClick(DialogInterface dialog, int which) {
                    speak(text);
                }
            })
            .setPositiveButton("Dịch", new DialogInterface.OnClickListener() {
                @Override public void onClick(DialogInterface dialog, int which) {
                    openTranslate(text);
                    finish();
                }
            })
            .setOnCancelListener(new DialogInterface.OnCancelListener() {
                @Override public void onCancel(DialogInterface dialog) {
                    finish();
                }
            })
            .show();
    }

    private void openTranslate(String text) {
        try {
            String enc = URLEncoder.encode(text, "UTF-8");
            Uri u = Uri.parse("https://translate.google.com/?sl=auto&tl=vi&text=" + enc + "&op=translate");
            startActivity(new Intent(Intent.ACTION_VIEW, u));
        } catch (Throwable ignore) {}
    }

    private void speak(final String text) {
        try {
            if (tts != null) {
                tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "assistive_tts");
                finish();
                return;
            }

            tts = new TextToSpeech(this, new TextToSpeech.OnInitListener() {
					@Override
					public void onInit(int status) {
						try {
							tts.setLanguage(new Locale("vi", "VN"));
							tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "assistive_tts");
						} catch (Throwable ignore) {}
						finish();
					}
				});
        } catch (Throwable ignore) {
            finish();
        }
    }

    @Override
    protected void onDestroy() {
        try { if (tts != null) tts.shutdown(); } catch (Throwable ignore) {}
        super.onDestroy();
    }
}

