package com.assistive.filter;

import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.IBinder;

public final class GainBridgeService extends Service {

    public static final String ACTION_SET_GAIN = "com.assistive.filter.GAIN_SET";
    public static final String EXTRA_GAIN = "gain";

    private volatile float gain = 0f;

    public final class GainBinder extends Binder {
        public void setGain(float v) { gain = v; }
        public float getGain() { return gain; }
    }

    private final GainBinder binder = new GainBinder();

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_SET_GAIN.equals(intent.getAction())) {
            float v = intent.getFloatExtra(EXTRA_GAIN, gain);
            if (v < 0f) v = 0f;
            if (v > 1f) v = 1f;
            gain = v;
        }
        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return binder;
    }
}

