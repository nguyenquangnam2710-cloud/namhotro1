package com.assistive.filter;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.View;

public final class filterview extends View {
    private final Paint mask = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
    private float radiusPx = 80f;

    public filterview(Context c) {
        super(c);
        mask.setStyle(Paint.Style.FILL);
        mask.setColor(0xFF000000);
        ring.setStyle(Paint.Style.STROKE);
        ring.setStrokeWidth(dp(4f));
        ring.setColor(0xFFE53935);
    }

    public void setMaskRadiusPx(float r) { radiusPx = r; invalidate(); }
    public void setRingAlpha(int a) { ring.setAlpha(a); invalidate(); }

    @Override
    protected void onDraw(Canvas canvas) {
        float cx = getWidth() * 0.5f;
        float cy = getHeight() * 0.5f;
        float r = Math.min(radiusPx, Math.min(cx, cy));
        canvas.drawCircle(cx, cy, r, mask);
        canvas.drawCircle(cx, cy, r - ring.getStrokeWidth() * 0.5f, ring);
    }
    private float dp(float v) { return v * getResources().getDisplayMetrics().density; }
}
