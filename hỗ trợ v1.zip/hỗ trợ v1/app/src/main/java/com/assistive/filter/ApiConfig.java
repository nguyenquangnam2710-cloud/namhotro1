package com.assistive.filter;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

public final class ApiConfig {

    private static final String PREFS = "assistive_prefs";
    private static final String KEY_API_ENABLED = "api_enabled";
    private static final String KEY_API_KEY = "api_key";

    public static final String EXTRA_API_KEY = "api_key";

    private ApiConfig() {}

    public static boolean isEnabled(Context context) {
        if (context == null) return false;
        SharedPreferences sp = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        return sp.getBoolean(KEY_API_ENABLED, false);
    }

    public static void setEnabled(Context context, boolean enabled) {
        if (context == null) return;
        SharedPreferences sp = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        sp.edit().putBoolean(KEY_API_ENABLED, enabled).apply();
    }

    public static String getKey(Context context) {
        if (context == null) return "";
        SharedPreferences sp = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String k = sp.getString(KEY_API_KEY, "");
        return k == null ? "" : k;
    }

    public static void setKey(Context context, String key) {
        if (context == null) return;
        String k = key == null ? "" : key.trim();
        SharedPreferences sp = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        sp.edit().putString(KEY_API_KEY, k).apply();
    }

    public static boolean validate(Context context, Intent intent) {
        if (context == null || intent == null) return false;
        if (!isEnabled(context)) return false;

        String expected = getKey(context);
        if (expected.length() == 0) return false;

        String provided = intent.getStringExtra(EXTRA_API_KEY);
        if (provided == null) provided = "";

        return expected.equals(provided);
    }
}

