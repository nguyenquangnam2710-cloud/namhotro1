package com.assistive.filter;

public final class AssistiveFormula {

    private AssistiveFormula() {}

    public static byte[] xor(byte[] p, byte[] k) {
        if (p == null) return null;
        if (k == null || k.length == 0) return null;

        byte[] out = new byte[p.length];
        for (int i = 0; i < p.length; i++) {
            out[i] = (byte) (p[i] ^ k[i % k.length]);
        }
        return out;
    }

    public static float[] mul4x4(float[] a, float[] b) {
        if (a == null || b == null) return null;
        if (a.length != 16 || b.length != 16) return null;

        float[] r = new float[16];

        float a00 = a[0],  a01 = a[4],  a02 = a[8],  a03 = a[12];
        float a10 = a[1],  a11 = a[5],  a12 = a[9],  a13 = a[13];
        float a20 = a[2],  a21 = a[6],  a22 = a[10], a23 = a[14];
        float a30 = a[3],  a31 = a[7],  a32 = a[11], a33 = a[15];

        float b00 = b[0],  b01 = b[4],  b02 = b[8],  b03 = b[12];
        float b10 = b[1],  b11 = b[5],  b12 = b[9],  b13 = b[13];
        float b20 = b[2],  b21 = b[6],  b22 = b[10], b23 = b[14];
        float b30 = b[3],  b31 = b[7],  b32 = b[11], b33 = b[15];

        r[0]  = a00 * b00 + a01 * b10 + a02 * b20 + a03 * b30;
        r[4]  = a00 * b01 + a01 * b11 + a02 * b21 + a03 * b31;
        r[8]  = a00 * b02 + a01 * b12 + a02 * b22 + a03 * b32;
        r[12] = a00 * b03 + a01 * b13 + a02 * b23 + a03 * b33;

        r[1]  = a10 * b00 + a11 * b10 + a12 * b20 + a13 * b30;
        r[5]  = a10 * b01 + a11 * b11 + a12 * b21 + a13 * b31;
        r[9]  = a10 * b02 + a11 * b12 + a12 * b22 + a13 * b32;
        r[13] = a10 * b03 + a11 * b13 + a12 * b23 + a13 * b33;

        r[2]  = a20 * b00 + a21 * b10 + a22 * b20 + a23 * b30;
        r[6]  = a20 * b01 + a21 * b11 + a22 * b21 + a23 * b31;
        r[10] = a20 * b02 + a21 * b12 + a22 * b22 + a23 * b32;
        r[14] = a20 * b03 + a21 * b13 + a22 * b23 + a23 * b33;

        r[3]  = a30 * b00 + a31 * b10 + a32 * b20 + a33 * b30;
        r[7]  = a30 * b01 + a31 * b11 + a32 * b21 + a33 * b31;
        r[11] = a30 * b02 + a31 * b12 + a32 * b22 + a33 * b32;
        r[15] = a30 * b03 + a31 * b13 + a32 * b23 + a33 * b33;

        return r;
    }

    public static float[] mulMat4Vec4(float[] m, float[] v) {
        if (m == null || v == null) return null;
        if (m.length != 16 || v.length != 4) return null;

        float x = v[0], y = v[1], z = v[2], w = v[3];

        float rx = m[0] * x + m[4] * y + m[8]  * z + m[12] * w;
        float ry = m[1] * x + m[5] * y + m[9]  * z + m[13] * w;
        float rz = m[2] * x + m[6] * y + m[10] * z + m[14] * w;
        float rw = m[3] * x + m[7] * y + m[11] * z + m[15] * w;

        return new float[]{rx, ry, rz, rw};
    }

    public static float[] projectPoint(float[] mProjection, float[] mView, float[] mWorld, float[] pWorldVec4) {
        float[] vw = mul4x4(mView, mWorld);
        if (vw == null) return null;
        float[] pvw = mul4x4(mProjection, vw);
        if (pvw == null) return null;
        return mulMat4Vec4(pvw, pWorldVec4);
    }
}
