package com.assistive.filter;

public final class AssistiveDragFormula {

    private static final float SPEED_K = 9355f;

    private static final float BASE_D = 10f;
    private static final float BASE_S = 100f;
    private static final float BASE_T = 1f;

    private static final float ASSIST_WINDOW_SEC = 0.2f;

    private AssistiveDragFormula() {}

    public static float computeSwipeSpeedPxPerSec(float dMeters, float lookSensitivity, float pointerFactor) {
        if (dMeters <= 0f) return Float.NaN;
        if (lookSensitivity < 0f) return Float.NaN;
        if (pointerFactor <= 0f) return Float.NaN;

        float denom = dMeters * (0.1822f + 0.00121f * lookSensitivity) * pointerFactor;
        if (denom <= 1e-6f) return Float.NaN;

        return SPEED_K / denom;
    }

    public static float computeSwipeDistancePx(float dMeters, float lookSensitivity, float pointerFactor) {
        float speed = computeSwipeSpeedPxPerSec(dMeters, lookSensitivity, pointerFactor);
        if (Float.isNaN(speed)) return Float.NaN;
        return speed * ASSIST_WINDOW_SEC;
    }

    public static float pointerFactorFromAndroidSpeed(int pointerSpeed) {
        int v = pointerSpeed;
        if (v < -7) v = -7;
        if (v > 7) v = 7;

        float t = 1f + (v / 14f);
        if (t < 0.5f) t = 0.5f;
        if (t > 1.5f) t = 1.5f;
        return t;
    }

    public static float computeAssistScale(float dMeters, float lookSensitivity, float pointerFactor) {
        float baseSpeed = computeSwipeSpeedPxPerSec(BASE_D, BASE_S, BASE_T);
        float curSpeed = computeSwipeSpeedPxPerSec(dMeters, lookSensitivity, pointerFactor);

        if (Float.isNaN(baseSpeed) || Float.isNaN(curSpeed) || baseSpeed <= 1e-6f) return 1f;

        float scale = curSpeed / baseSpeed;

        if (scale < 0.35f) scale = 0.35f;
        if (scale > 3.5f) scale = 3.5f;
        return scale;
    }

    public static float applyVerticalAssist(float rawDy, float dMeters, float lookSensitivity, float pointerFactor) {
        if (rawDy >= 0f) return rawDy;
        float scale = computeAssistScale(dMeters, lookSensitivity, pointerFactor);
        return rawDy * scale;
    }

    public static float wobbleOffsetPx(float tSec) {
        if (tSec < 0f) tSec = 0f;
        if (tSec > ASSIST_WINDOW_SEC) return 0f;

        float amplitude = 1.5f;
        float freqHz = 22f;
        double phase = 2.0 * Math.PI * freqHz * tSec;
        return (float) (amplitude * Math.sin(phase));
    }
}
