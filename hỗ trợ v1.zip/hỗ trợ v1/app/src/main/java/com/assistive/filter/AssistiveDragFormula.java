package com.assistive.filter;

public final class AssistiveDragFormula {

    private static final float SPEED_K = 6237f;

    private static final float BASE_D = 10f;
    private static final float BASE_S = 100f;
    private static final float BASE_T = 1f;

    private AssistiveDragFormula() {}

    public static float computeSwipeSpeedPxPerSec(float dMeters, float lookSensitivity, float pointerFactor) {
        if (dMeters <= 0f) return Float.NaN;
        if (lookSensitivity < 0f) return Float.NaN;
        if (pointerFactor <= 0f) return Float.NaN;

        float denom = dMeters * (0.1822f + 0.00121f * lookSensitivity) * pointerFactor;
        if (denom <= 1e-6f) return Float.NaN;

        return SPEED_K / denom;
    }

    public static float pointerFactorFromAndroidSpeed(int pointerSpeed) {
        int v = pointerSpeed;
        if (v < -7) v = -7;
        if (v > 7) v = 7;

        float t = 1f + (v / 14f);
        if (t < 0.5f) t = 0.5f;
        if (t > 1.5f) t = 1.5f;
        return t;
    }

    public static float computeAssistScale(float dMeters, float lookSensitivity, float pointerFactor) {
        float baseSpeed = computeSwipeSpeedPxPerSec(BASE_D, BASE_S, BASE_T);
        float curSpeed = computeSwipeSpeedPxPerSec(dMeters, lookSensitivity, pointerFactor);

        if (Float.isNaN(baseSpeed) || Float.isNaN(curSpeed) || baseSpeed <= 1e-6f) return 1f;

        float scale = curSpeed / baseSpeed;

        if (scale < 0.35f) scale = 0.35f;
        if (scale > 3.0f) scale = 3.0f;
        return scale;
    }

    public static float applyVerticalAssist(float rawDy, float dMeters, float lookSensitivity, float pointerFactor) {
        if (rawDy >= 0f) return rawDy;
        float scale = computeAssistScale(dMeters, lookSensitivity, pointerFactor);
        return rawDy * scale;
    }
}

