package com.assistive.filter;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.View;

public final class enhancelensview extends View {

    private final Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint bmpPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path clip = new Path();

    private final Paint dot = new Paint(Paint.ANTI_ALIAS_FLAG);

    private volatile Bitmap frame;

    private volatile float tx = -1f;
    private volatile float ty = -1f;
    private volatile float tc = 0f;

    public enhancelensview(Context c) {
        super(c);
        ring.setStyle(Paint.Style.STROKE);
        ring.setStrokeWidth(dp(2f));
        ring.setColor(0xFFFF1744);

        dot.setStyle(Paint.Style.FILL);
        dot.setColor(0xFFFFEB3B);
    }

    public void setFrame(Bitmap b) {
        frame = b;
        postInvalidateOnAnimation();
    }

    public void setTarget(float x, float y, float confidence) {
        tx = x;
        ty = y;
        tc = confidence;
        postInvalidateOnAnimation();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        float w = getWidth();
        float h = getHeight();
        float cx = w * 0.5f;
        float cy = h * 0.5f;
        float r = Math.min(cx, cy);

        clip.reset();
        clip.addCircle(cx, cy, r, Path.Direction.CW);

        int save = canvas.save();
        canvas.clipPath(clip);

        Bitmap b = frame;
        if (b != null && !b.isRecycled()) {
            canvas.drawBitmap(b, null, getClipBounds(), bmpPaint);
        }

        float x = tx;
        float y = ty;
        float conf = tc;

        if (x >= 0f && y >= 0f) {
            int a = (int) (70f + 185f * conf);
            if (a < 30) a = 30;
            if (a > 255) a = 255;
            dot.setAlpha(a);

            float dr = dp(4.5f) + dp(2.5f) * (1f - conf);
            canvas.drawCircle(x, y, dr, dot);
        }

        canvas.restoreToCount(save);

        canvas.drawCircle(cx, cy, r - ring.getStrokeWidth() * 0.5f, ring);
    }

    private float dp(float v) {
        return v * getResources().getDisplayMetrics().density;
    }
}

