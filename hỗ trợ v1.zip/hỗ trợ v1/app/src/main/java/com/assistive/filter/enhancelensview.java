package com.assistive.filter;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.View;

public final class enhancelensview extends View {

    private final Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint bmpPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path clip = new Path();

    private volatile Bitmap frame;

    public enhancelensview(Context c) {
        super(c);
        ring.setStyle(Paint.Style.STROKE);
        ring.setStrokeWidth(dp(2f));
        ring.setColor(0xFFFF1744);
    }

    public void setFrame(Bitmap b) {
        frame = b;
        postInvalidateOnAnimation();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        float w = getWidth();
        float h = getHeight();
        float cx = w * 0.5f;
        float cy = h * 0.5f;
        float r = Math.min(cx, cy);

        clip.reset();
        clip.addCircle(cx, cy, r, Path.Direction.CW);

        int save = canvas.save();
        canvas.clipPath(clip);

        Bitmap b = frame;
        if (b != null && !b.isRecycled()) {
            canvas.drawBitmap(b, null, getClipBounds(), bmpPaint);
        }

        canvas.restoreToCount(save);

        canvas.drawCircle(cx, cy, r - ring.getStrokeWidth() * 0.5f, ring);
    }

    private float dp(float v) {
        return v * getResources().getDisplayMetrics().density;
    }
}

