package com.assistive.filter;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.WindowManager;
import android.widget.Toast;

public final class filteroverlayservice extends Service {

    public static final String ACTION_START_LOCKED = "com.assistive.filter.FILTER_START_LOCKED";
    public static final String ACTION_START_EDIT = "com.assistive.filter.FILTER_START_EDIT";
    public static final String ACTION_STOP = "com.assistive.filter.FILTER_STOP";
    public static final String EXTRA_POINTER_SPEED = "pointer_speed";

    private static final int NOTIF_ID = 5001;
    private static final String CHANNEL_ID = "assistive_filter_overlay";
    private static final int CENTER_X = 724;
    private static final int CENTER_Y = 1762;
    private static final float DRAG_GAIN_X = 1.56f;
    private static final float DRAG_GAIN_Y = 1.56f;

    private WindowManager wm;
    private filterview overlay;
    private WindowManager.LayoutParams params;
    private int touchSlop;
    private int startX, startY;
    private float downRawX, downRawY;
    private float scale = 1.0f;
    private int baseSizePx;
    private boolean editMode = false;
    private ScaleGestureDetector scaleDetector;
    private int screenW, screenH;
    private final Handler main = new Handler(Looper.getMainLooper());

    @Override
    public void onCreate() {
        super.onCreate();
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        touchSlop = ViewConfiguration.get(this).getScaledTouchSlop();
        updateScreenSize();
        float d = getResources().getDisplayMetrics().density;
        baseSizePx = (int) (40f * d);
        if (baseSizePx > screenW) baseSizePx = screenW;
        if (baseSizePx > screenH) baseSizePx = screenH;
        overlay = new filterview(this);
        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
			? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
			: WindowManager.LayoutParams.TYPE_PHONE;
        params = new WindowManager.LayoutParams(baseSizePx, baseSizePx, type, flagsLocked(), PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.START;
        params.x = CENTER_X - (baseSizePx / 2);
        params.y = CENTER_Y - (baseSizePx / 2);
        applySize();
        clampToScreen();
        scaleDetector = new ScaleGestureDetector(this, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
				@Override
				public boolean onScale(ScaleGestureDetector detector) {
					if (!editMode) return false;
					scale *= detector.getScaleFactor();
					if (scale < 0.4f) scale = 0.4f;
					if (scale > 3.0f) scale = 3.0f;
					applySize();
					clampToScreen();
					updateLayoutSafe();
					return true;
				}
			});
        overlay.setOnTouchListener(new View.OnTouchListener() {
				private boolean moved;
				@Override
				public boolean onTouch(View v, MotionEvent e) {
					if (!editMode) return false;
					try { scaleDetector.onTouchEvent(e); } catch (Throwable ignore) {}
					switch (e.getActionMasked()) {
						case MotionEvent.ACTION_DOWN:
							moved = false;
							downRawX = e.getRawX();
							downRawY = e.getRawY();
							startX = params.x;
							startY = params.y;
							return true;
						case MotionEvent.ACTION_MOVE:
							float rawDx = e.getRawX() - downRawX;
							float rawDy = e.getRawY() - downRawY;
							if (!moved && (Math.abs(rawDx) > touchSlop || Math.abs(rawDy) > touchSlop)) moved = true;
							int dx = Math.round(rawDx * DRAG_GAIN_X);
							int dy = Math.round(rawDy * DRAG_GAIN_Y);
							params.x = startX + dx;
							params.y = startY + dy;
							clampToScreen();
							updateLayoutSafe();
							return true;
						case MotionEvent.ACTION_UP:
						case MotionEvent.ACTION_CANCEL:
							return true;
					}
					return true;
				}
			});
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent != null ? intent.getAction() : null;
        if (intent != null && intent.hasExtra(EXTRA_POINTER_SPEED)) {
            int v = intent.getIntExtra(EXTRA_POINTER_SPEED, 0);
            SensitivityController.setPointerSpeed(this, v);
        }
        if (ACTION_STOP.equals(action)) {
            removeOverlay();
            stopForeground(true);
            stopSelf();
            return START_NOT_STICKY;
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            toast("Chưa có quyền Overlay");
            stopSelf();
            return START_NOT_STICKY;
        }
        startForegroundSafe(action);
        if (ACTION_START_EDIT.equals(action)) {
            setEditMode(true);
            toast("CHỈNH: kéo/zoom trên vòng tròn");
        } else {
            setEditMode(false);
            toast("BẬT (khóa)");
        }
        addOverlayIfNeeded();
        if (overlay != null && overlay.getParent() != null) updateLayoutSafe();
        else { applySize(); clampToScreen(); updateLayoutSafe(); }
        return START_STICKY;
    }

    private void updateScreenSize() {
        DisplayMetrics dm = getResources().getDisplayMetrics();
        screenW = dm.widthPixels;
        screenH = dm.heightPixels;
        if (screenW < 1) screenW = 1080;
        if (screenH < 1) screenH = 1920;
    }

    private void setEditMode(boolean on) {
        editMode = on;
        params.flags = on ? flagsEdit() : flagsLocked();
        if (overlay != null) overlay.setRingAlpha(on ? 255 : 220);
    }

    private int flagsLocked() {
        return WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
			| WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
			| WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
    }

    private int flagsEdit() {
        return WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
			| WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL;
    }

    private void startForegroundSafe(String action) {
        try {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (nm == null) throw new RuntimeException("NotificationManager=null");
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                NotificationChannel ch = new NotificationChannel(CHANNEL_ID, "Filter Overlay", NotificationManager.IMPORTANCE_MIN);
                ch.setSound(null, null);
                nm.createNotificationChannel(ch);
            }
            Notification.Builder b = (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
				? new Notification.Builder(this, CHANNEL_ID) : new Notification.Builder(this);
            String t = ACTION_START_EDIT.equals(action) ? "Đang CHỈNH" : "Đang CHẠY";
            Notification n = b.setOngoing(true)
				.setSmallIcon(android.R.drawable.ic_menu_view)
				.setContentTitle("Assistive Filter")
				.setContentText(t)
				.build();
            startForeground(NOTIF_ID, n);
        } catch (Throwable t) {
            toast("startForeground lỗi: " + t.getClass().getSimpleName());
            stopSelf();
        }
    }

    private void addOverlayIfNeeded() {
        if (overlay == null || overlay.getParent() != null) return;
        try { wm.addView(overlay, params); } catch (Throwable t) { toast("addView lỗi: " + t.getClass().getSimpleName()); }
    }

    private void removeOverlay() {
        try { if (wm != null && overlay != null && overlay.getParent() != null) wm.removeView(overlay); } catch (Throwable ignore) {}
    }

    private void applySize() {
        updateScreenSize();
        int sz = (int) (baseSizePx * scale);
        if (sz < 48) sz = 48;
        if (sz > screenW) sz = screenW;
        if (sz > screenH) sz = screenH;
        params.width = sz;
        params.height = sz;
        if (overlay != null) overlay.setMaskRadiusPx(sz * 0.5f);
    }

    private void clampToScreen() {
        updateScreenSize();
        int maxX = Math.max(0, screenW - params.width);
        int maxY = Math.max(0, screenH - params.height);
        params.x = Math.max(0, Math.min(params.x, maxX));
        params.y = Math.max(0, Math.min(params.y, maxY));
    }

    private void updateLayoutSafe() {
        try { if (wm != null && overlay != null && overlay.getParent() != null) wm.updateViewLayout(overlay, params); } catch (Throwable t) { toast("updateViewLayout lỗi: " + t.getClass().getSimpleName()); }
    }

    private void toast(final String s) {
        main.post(new Runnable() { @Override public void run() { Toast.makeText(filteroverlayservice.this, s, Toast.LENGTH_SHORT).show(); } });
    }

    @Override
    public void onDestroy() { removeOverlay(); super.onDestroy(); }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    public static final class SensitivityController {
        public static final int MIN = -7, MAX = 7;
        private static final String KEY_POINTER_SPEED = "pointer_speed";
        private SensitivityController() {}
        public static boolean setPointerSpeed(Context context, int sensitivityValue) {
            if (context == null) return false;
            int v = clamp(sensitivityValue, MIN, MAX);
            try { return Settings.System.putInt(context.getContentResolver(), KEY_POINTER_SPEED, v); } catch (Throwable t) { return false; }
        }
        public static int getPointerSpeed(Context context, int defaultValue) {
            if (context == null) return clamp(defaultValue, MIN, MAX);
            try { int v = Settings.System.getInt(context.getContentResolver(), KEY_POINTER_SPEED, defaultValue); return clamp(v, MIN, MAX); } catch (Throwable t) { return clamp(defaultValue, MIN, MAX); }
        }
        private static int clamp(int v, int min, int max) { return Math.max(min, Math.min(max, v)); }
    }
}
