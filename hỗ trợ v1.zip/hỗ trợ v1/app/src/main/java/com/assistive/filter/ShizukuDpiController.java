package com.assistive.filter;

import android.content.ComponentName;
import android.content.Context;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.os.Parcel;

import rikka.shizuku.Shizuku;

public final class ShizukuDpiController {

    private static final String TAG = "dpi_service";
    private static volatile IBinder sService;

    private static final ServiceConnection CONN = new ServiceConnection() {
        @Override public void onServiceConnected(ComponentName name, IBinder service) { sService = service; }
        @Override public void onServiceDisconnected(ComponentName name) { sService = null; }
    };

    private ShizukuDpiController() {}

    public static boolean connect(Context context) {
        if (context == null) return false;
        try {
            if (!Shizuku.pingBinder()) return false;
            if (Shizuku.checkSelfPermission() != android.content.pm.PackageManager.PERMISSION_GRANTED) return false;

            Shizuku.UserServiceArgs args = new Shizuku.UserServiceArgs(
				new ComponentName(context.getPackageName(), DpiUserService.class.getName()))
				.tag(TAG)
				.version(6)
				.processNameSuffix("dpi");

            Shizuku.bindUserService(args, CONN);
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    public static boolean isConnected() {
        IBinder b = sService;
        return b != null && b.isBinderAlive();
    }

    public static boolean applyReduceLag(Context context) {
        if (!isConnected()) connect(context);
        return transactApplyReduceLag();
    }

    public static boolean setDpi(Context context, int dpi) {
        if (!isConnected()) connect(context);
        return transactSetDpi(dpi);
    }

    public static boolean setSize(Context context, int w, int h) {
        if (!isConnected()) connect(context);
        return transactSetSize(w, h);
    }

    public static boolean resetDpi(Context context) {
        if (!isConnected()) connect(context);

        IBinder b = sService;
        if (b == null) return false;

        Parcel data = Parcel.obtain();
        Parcel reply = Parcel.obtain();
        try {
            data.writeInterfaceToken(DpiUserService.DESCRIPTOR);
            b.transact(DpiUserService.TRANSACTION_RESET_ALL, data, reply, 0);
            reply.readException();
            return reply.readInt() != 0;
        } catch (Throwable t) {
            return false;
        } finally {
            data.recycle();
            reply.recycle();
        }
    }

    public static int getPhysicalDpi(Context context) {
        if (!isConnected()) connect(context);

        IBinder b = sService;
        if (b == null) return 0;

        Parcel data = Parcel.obtain();
        Parcel reply = Parcel.obtain();
        try {
            data.writeInterfaceToken(DpiUserService.DESCRIPTOR);
            b.transact(DpiUserService.TRANSACTION_GET_PHYSICAL_DPI, data, reply, 0);
            reply.readException();
            return reply.readInt();
        } catch (Throwable t) {
            return 0;
        } finally {
            data.recycle();
            reply.recycle();
        }
    }

    public static int[] getPhysicalSize(Context context) {
        if (!isConnected()) connect(context);

        IBinder b = sService;
        if (b == null) return null;

        Parcel data = Parcel.obtain();
        Parcel reply = Parcel.obtain();
        try {
            data.writeInterfaceToken(DpiUserService.DESCRIPTOR);
            b.transact(DpiUserService.TRANSACTION_GET_PHYSICAL_SIZE, data, reply, 0);
            reply.readException();
            int ok = reply.readInt();
            if (ok == 0) return null;
            int w = reply.readInt();
            int h = reply.readInt();
            return new int[]{w, h};
        } catch (Throwable t) {
            return null;
        } finally {
            data.recycle();
            reply.recycle();
        }
    }

    public static int[] getCurrentSize(Context context) {
        if (!isConnected()) connect(context);

        IBinder b = sService;
        if (b == null) return null;

        Parcel data = Parcel.obtain();
        Parcel reply = Parcel.obtain();
        try {
            data.writeInterfaceToken(DpiUserService.DESCRIPTOR);
            b.transact(DpiUserService.TRANSACTION_GET_CURRENT_SIZE, data, reply, 0);
            reply.readException();
            int ok = reply.readInt();
            if (ok == 0) return null;
            int w = reply.readInt();
            int h = reply.readInt();
            return new int[]{w, h};
        } catch (Throwable t) {
            return null;
        } finally {
            data.recycle();
            reply.recycle();
        }
    }

    public static boolean applySignedScaleBySizeAndDpi(Context context, float value) {
        if (context == null) return false;
        if (value == 0f) return false;

        float factor = Math.abs(value);
        if (factor < 0.1f || factor > 10f) return false;

        int[] phys = getPhysicalSize(context);
        if (phys == null) return false;

        int baseDpi = getPhysicalDpi(context);
        if (baseDpi <= 0) baseDpi = context.getResources().getDisplayMetrics().densityDpi;
        if (baseDpi <= 0) return false;

        int newW;
        int newH;

        if (value > 0f) {
            newW = (int) Math.round(phys[0] * factor);
            newH = (int) Math.round(phys[1] * factor);
        } else {
            newW = (int) Math.round(phys[0] / factor);
            newH = (int) Math.round(phys[1] / factor);
        }

        int newDpi = (int) Math.round(baseDpi / factor);

        if (newW < 480) newW = 480;
        if (newH < 800) newH = 800;

        if (newDpi < 200) newDpi = 200;
        if (newDpi > 800) newDpi = 800;

        boolean okSize = setSize(context, newW, newH);
        boolean okDpi = setDpi(context, newDpi);
        return okSize && okDpi;
    }

    public static boolean applyXSensitivityPercent(Context context, float percent) {
        if (context == null) return false;
        if (percent <= 0f) return false;

        float k = 1f + (percent / 100f);
        if (k <= 0f) return false;

        int[] cur = getCurrentSize(context);
        if (cur == null) return false;

        int w0 = cur[0];
        int h0 = cur[1];
        if (w0 <= 0 || h0 <= 0) return false;

        int newW = (int) Math.round(w0 / k);
        if (newW < 1) return false;

        return setSize(context, newW, h0);
    }

    public static boolean increaseHeightBy20(Context context) {
        if (context == null) return false;

        int[] cur = getCurrentSize(context);
        if (cur == null) return false;

        int w = cur[0];
        int h = cur[1];
        if (w <= 0 || h <= 0) return false;

        int newH = h + 20;
        return setSize(context, w, newH);
    }

    public static boolean decreaseHeightBy20(Context context) {
        if (context == null) return false;

        int[] cur = getCurrentSize(context);
        if (cur == null) return false;

        int w = cur[0];
        int h = cur[1];
        if (w <= 0 || h <= 0) return false;

        int newH = h - 20;
        if (newH < 1) newH = 1;

        return setSize(context, w, newH);
    }

    private static boolean transactApplyReduceLag() {
        IBinder b = sService;
        if (b == null) return false;

        Parcel data = Parcel.obtain();
        Parcel reply = Parcel.obtain();
        try {
            data.writeInterfaceToken(DpiUserService.DESCRIPTOR);
            b.transact(DpiUserService.TRANSACTION_APPLY_REDUCE_LAG, data, reply, 0);
            reply.readException();
            return reply.readInt() != 0;
        } catch (Throwable t) {
            return false;
        } finally {
            data.recycle();
            reply.recycle();
        }
    }

    private static boolean transactSetDpi(int dpi) {
        IBinder b = sService;
        if (b == null) return false;

        Parcel data = Parcel.obtain();
        Parcel reply = Parcel.obtain();
        try {
            data.writeInterfaceToken(DpiUserService.DESCRIPTOR);
            data.writeInt(dpi);
            b.transact(DpiUserService.TRANSACTION_SET_DPI, data, reply, 0);
            reply.readException();
            return reply.readInt() != 0;
        } catch (Throwable t) {
            return false;
        } finally {
            data.recycle();
            reply.recycle();
        }
    }

    private static boolean transactSetSize(int w, int h) {
        IBinder b = sService;
        if (b == null) return false;

        Parcel data = Parcel.obtain();
        Parcel reply = Parcel.obtain();
        try {
            data.writeInterfaceToken(DpiUserService.DESCRIPTOR);
            data.writeInt(w);
            data.writeInt(h);
            b.transact(DpiUserService.TRANSACTION_SET_SIZE, data, reply, 0);
            reply.readException();
            return reply.readInt() != 0;
        } catch (Throwable t) {
            return false;
        } finally {
            data.recycle();
            reply.recycle();
        }
    }
}

