package com.assistive.filter;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.Toast;

import rikka.shizuku.Shizuku;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class FullRedModeService extends Service {

    private static final int NOTIF_ID = 5009;
    private static final String CHANNEL_ID = "full_red_mode";
    private WindowManager wm;
    private View floatingView;
    private WindowManager.LayoutParams params;
    private boolean isFullRed = false;

    // Lưu cài đặt gốc
    private int originalPointerSpeed = -1;
    private int originalDpi = -1;
    private float originalAnimDuration = -1f;
    private float originalAnimTransition = -1f;
    private float originalAnimWindow = -1f;
    private int originalOverscroll = -1;
    private String originalTouchPressure = null;
    private String originalApnId = null;
    private int originalRefreshRate = -1;

    // Thông số Full Đỏ (từ hồ sơ thực chiến)
    private static final int FULL_RED_POINTER_SPEED = 7;
    private static final int FULL_RED_DPI = 520;
    private static final float FULL_RED_ANIM_SCALE = 0f;
    private static final int FULL_RED_OVERSCROLL = 0;
    private static final String FULL_RED_TOUCH_PRESSURE = "0.5";
    private static final int FULL_RED_REFRESH_RATE = 120;
    private static final String FULL_RED_APN_NAME = "FullRedTurbo";
    private static final String FULL_RED_APN_SERVER = "1.1.1.1";
    private static final String FULL_RED_APN_MCC = "452";
    private static final String FULL_RED_APN_MNC = "02";

    private Handler mainHandler = new Handler(Looper.getMainLooper());
    private Runnable dpiAdjuster;

    @Override
    public void onCreate() {
        super.onCreate();
        startForegroundSafe();
        saveOriginalSettings();
        createFloatingButton();
    }

    private void startForegroundSafe() {
        try {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (nm == null) return;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                NotificationChannel ch = new NotificationChannel(CHANNEL_ID, "Full Red Mode", NotificationManager.IMPORTANCE_MIN);
                ch.setSound(null, null);
                nm.createNotificationChannel(ch);
            }
            Notification.Builder b = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
				? new Notification.Builder(this, CHANNEL_ID) : new Notification.Builder(this);
            Notification n = b.setOngoing(true)
				.setSmallIcon(android.R.drawable.ic_menu_edit)
				.setContentTitle("Full Red Mode")
				.setContentText("Ready")
				.build();
            startForeground(NOTIF_ID, n);
        } catch (Throwable t) {
            stopSelf();
        }
    }

    private void saveOriginalSettings() {
        try {
            originalPointerSpeed = Settings.System.getInt(getContentResolver(), "pointer_speed", 0);
        } catch (Exception e) {}
        originalDpi = getResources().getDisplayMetrics().densityDpi;
        try {
            originalAnimDuration = Settings.Global.getFloat(getContentResolver(), Settings.Global.ANIMATOR_DURATION_SCALE, 1.0f);
            originalAnimTransition = Settings.Global.getFloat(getContentResolver(), Settings.Global.TRANSITION_ANIMATION_SCALE, 1.0f);
            originalAnimWindow = Settings.Global.getFloat(getContentResolver(), Settings.Global.WINDOW_ANIMATION_SCALE, 1.0f);
        } catch (Exception e) {}
        try {
            originalOverscroll = Settings.System.getInt(getContentResolver(), "overscroll", 1);
        } catch (Exception e) {}
        try {
            originalTouchPressure = Settings.System.getString(getContentResolver(), "touch_pressure");
        } catch (Exception e) {}
        try {
            originalRefreshRate = Settings.System.getInt(getContentResolver(), "peak_refresh_rate", 60);
        } catch (Exception e) {}
        originalApnId = getCurrentApnId();
    }

    private void createFloatingButton() {
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        LayoutInflater inflater = LayoutInflater.from(this);
        floatingView = inflater.inflate(R.layout.full_red_button, null);
        float density = getResources().getDisplayMetrics().density;
        int size = (int)(60 * density);

        int layoutFlag = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
			? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
			: WindowManager.LayoutParams.TYPE_PHONE;
        params = new WindowManager.LayoutParams(
			size, size,
			layoutFlag,
			WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
			PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.END;
        params.x = 0;
        params.y = 200;

        Button btn = floatingView.findViewById(R.id.btn_full_red);
        btn.setText("🔴");
        btn.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					toggleFullRed();
				}
			});

        floatingView.setOnTouchListener(new View.OnTouchListener() {
				private int initialX, initialY;
				private float initialTouchX, initialTouchY;
				@Override
				public boolean onTouch(View v, MotionEvent event) {
					switch (event.getAction()) {
						case MotionEvent.ACTION_DOWN:
							initialX = params.x;
							initialY = params.y;
							initialTouchX = event.getRawX();
							initialTouchY = event.getRawY();
							return true;
						case MotionEvent.ACTION_MOVE:
							params.x = initialX + (int)(event.getRawX() - initialTouchX);
							params.y = initialY + (int)(event.getRawY() - initialTouchY);
							wm.updateViewLayout(floatingView, params);
							return true;
						default:
							return false;
					}
				}
			});

        wm.addView(floatingView, params);
        updateButtonAppearance();
    }

    private void toggleFullRed() {
        if (!Shizuku.pingBinder()) {
            Toast.makeText(this, "Cần Shizuku để thay đổi cài đặt hệ thống", Toast.LENGTH_LONG).show();
            return;
        }
        if (!Shizuku.checkSelfPermission()) {
            Toast.makeText(this, "Chưa cấp quyền Shizuku", Toast.LENGTH_LONG).show();
            return;
        }

        if (!isFullRed) {
            applyFullRed();
            isFullRed = true;
            Toast.makeText(this, "🔥 ĐÃ BẬT CHẾ ĐỘ FULL ĐỎ 🔥", Toast.LENGTH_LONG).show();
        } else {
            restoreOriginal();
            isFullRed = false;
            Toast.makeText(this, "Đã tắt Full Red, khôi phục cài đặt gốc", Toast.LENGTH_LONG).show();
        }
        updateButtonAppearance();
    }

    private void applyFullRed() {
        // I. Ép xung phần cứng
        ShizukuPointerSpeedController.setPointerSpeed(this, FULL_RED_POINTER_SPEED);
        ShizukuDpiController.setDpi(this, FULL_RED_DPI);
        runShell("settings put global animator_duration_scale " + FULL_RED_ANIM_SCALE);
        runShell("settings put global transition_animation_scale " + FULL_RED_ANIM_SCALE);
        runShell("settings put global window_animation_scale " + FULL_RED_ANIM_SCALE);
        runShell("settings put system overscroll " + FULL_RED_OVERSCROLL);
        runShell("settings put system touch_pressure " + FULL_RED_TOUCH_PRESSURE);
        runShell("settings put system peak_refresh_rate " + FULL_RED_REFRESH_RATE);
        runShell("settings put system min_refresh_rate " + FULL_RED_REFRESH_RATE);
        runShell("wm size 720x1600");
        runShell("cmd power set-mode 0");

        // II. Tối ưu CPU/GPU
        runShell("echo performance > /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor 2>/dev/null");
        runShell("echo performance > /sys/devices/system/cpu/cpu4/cpufreq/scaling_governor 2>/dev/null");
        runShell("echo performance > /sys/devices/system/cpu/cpu7/cpufreq/scaling_governor 2>/dev/null");
        runShell("echo 1 > /sys/class/kgsl/kgsl-3d0/bus_control 2>/dev/null");
        runShell("echo 1 > /sys/class/kgsl/kgsl-3d0/max_gpuclk 2>/dev/null");
        runShell("setprop debug.hwui.renderer skiagl");
        runShell("setprop debug.egl.force_msaa true");

        // III. Tiêu diệt tiến trình ngầm
        runShell("pm disable com.miui.powerkeeper");
        runShell("pm disable com.xiaomi.joyose");
        runShell("pm disable com.miui.systemAdSolution");
        runShell("pm disable com.miui.video");
        runShell("pm disable com.android.vending");
        runShell("pm disable com.google.android.gms");
        runShell("setprop persist.vendor.memoryextension 0");

        // IV. Tối ưu mạng & APN
        setupFullRedApn();
        runShell("sysctl -w net.ipv4.tcp_congestion_control=bbr 2>/dev/null");
        runShell("sysctl -w net.core.rmem_max=26214400 2>/dev/null");
        runShell("sysctl -w net.core.wmem_max=26214400 2>/dev/null");
        runShell("settings put global private_dns_mode hostname");
        runShell("settings put global private_dns_specifier 1dot1dot1dot1.cloudflare-dns.com");

        // V. Tối ưu I/O
        runShell("echo noop > /sys/block/mmcblk0/queue/scheduler 2>/dev/null");
        runShell("echo 512 > /proc/sys/vm/min_free_kbytes 2>/dev/null");
        runShell("setprop dalvik.vm.heapsize 512m");
        runShell("setprop dalvik.vm.heapgrowthlimit 256m");

        // VI. Tối ưu cảm ứng
        runShell("setprop persist.sys.touch.size 5");
        runShell("setprop persist.sys.touch.pressure.scale 2.0");
        runShell("setprop persist.sys.force_highendgfx true");
        runShell("settings put system accelerometer_rotation 0");
    }

    private void restoreOriginal() {
        ShizukuPointerSpeedController.setPointerSpeed(this, originalPointerSpeed);
        ShizukuDpiController.setDpi(this, originalDpi);
        runShell("settings put global animator_duration_scale " + originalAnimDuration);
        runShell("settings put global transition_animation_scale " + originalAnimTransition);
        runShell("settings put global window_animation_scale " + originalAnimWindow);
        runShell("settings put system overscroll " + originalOverscroll);
        runShell("settings put system touch_pressure " + (originalTouchPressure != null ? originalTouchPressure : "default"));
        runShell("settings put system peak_refresh_rate " + originalRefreshRate);
        runShell("settings put system min_refresh_rate " + originalRefreshRate);
        runShell("wm size reset");
        runShell("cmd power set-mode 1");
        runShell("echo ondemand > /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor 2>/dev/null");
        runShell("echo ondemand > /sys/devices/system/cpu/cpu4/cpufreq/scaling_governor 2>/dev/null");
        runShell("echo ondemand > /sys/devices/system/cpu/cpu7/cpufreq/scaling_governor 2>/dev/null");
        runShell("setprop debug.hwui.renderer \"\"");
        runShell("setprop debug.egl.force_msaa false");
        runShell("pm enable com.miui.powerkeeper");
        runShell("pm enable com.xiaomi.joyose");
        runShell("pm enable com.miui.systemAdSolution");
        runShell("pm enable com.miui.video");
        runShell("pm enable com.android.vending");
        runShell("pm enable com.google.android.gms");
        runShell("setprop persist.vendor.memoryextension 1");
        runShell("setprop persist.sys.touch.size default");
        runShell("setprop persist.sys.touch.pressure.scale 1.0");
        runShell("settings put global private_dns_mode off");
        runShell("sysctl -w net.ipv4.tcp_congestion_control=cubic 2>/dev/null");
        runShell("echo cfq > /sys/block/mmcblk0/queue/scheduler 2>/dev/null");
        runShell("setprop dalvik.vm.heapsize 256m");
        runShell("setprop dalvik.vm.heapgrowthlimit 128m");
        restoreApn();
    }

    private void setupFullRedApn() {
        try {
            runShell("content delete --uri content://telephony/carriers --where \"name='FullRedTurbo'\"");
            String insert = "content insert --uri content://telephony/carriers " +
				"--bind name:s:'" + FULL_RED_APN_NAME + "' " +
				"--bind apn:s:'internet' " +
				"--bind server:s:'" + FULL_RED_APN_SERVER + "' " +
				"--bind mcc:s:'" + FULL_RED_APN_MCC + "' " +
				"--bind mnc:s:'" + FULL_RED_APN_MNC + "' " +
				"--bind type:s:'default,supl' " +
				"--bind protocol:s:'IPV4V6' " +
				"--bind roaming_protocol:s:'IPV4V6' " +
				"--bind bearer:i:13 " +
				"--bind carrier_enabled:i:1";
            String output = runShellAndGetOutput(insert);
            String id = extractApnId(output);
            if (id != null && !id.isEmpty()) {
                runShell("content insert --uri content://telephony/carriers/preferapn --bind apn_id:i:" + id);
            }
        } catch (Throwable ignore) {}
    }

    private void restoreApn() {
        try {
            runShell("content delete --uri content://telephony/carriers --where \"name='FullRedTurbo'\"");
            if (originalApnId != null && !originalApnId.isEmpty()) {
                runShell("content insert --uri content://telephony/carriers/preferapn --bind apn_id:i:" + originalApnId);
            }
        } catch (Throwable ignore) {}
    }

    private String getCurrentApnId() {
        String output = runShellAndGetOutput("content query --uri content://telephony/carriers/preferapn --projection apn_id");
        return extractApnId(output);
    }

    private String extractApnId(String output) {
        if (output == null) return null;
        int start = output.indexOf("apn_id=");
        if (start == -1) return null;
        start += 7;
        int end = output.indexOf(",", start);
        if (end == -1) end = output.length();
        try {
            return output.substring(start, end).trim();
        } catch (Exception e) {
            return null;
        }
    }

    private void runShell(String cmd) {
        try {
            Process p = Runtime.getRuntime().exec(new String[]{"sh", "-c", cmd});
            p.waitFor();
        } catch (Throwable ignore) {}
    }

    private String runShellAndGetOutput(String cmd) {
        try {
            Process p = Runtime.getRuntime().exec(new String[]{"sh", "-c", cmd});
            BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) sb.append(line);
            p.waitFor();
            return sb.toString();
        } catch (Throwable e) {
            return null;
        }
    }

    private void updateButtonAppearance() {
        if (floatingView != null) {
            floatingView.setBackgroundColor(isFullRed ? 0xAAFF0000 : 0xAAFF0000);
            Button btn = floatingView.findViewById(R.id.btn_full_red);
            if (btn != null) {
                btn.setText(isFullRed ? "🔴" : "⭕");
            }
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        if (isFullRed) restoreOriginal();
        if (floatingView != null && wm != null) wm.removeView(floatingView);
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
