package com.assistive.filter;

public final class AssistiveHeadLockFormula {

    public static final float Y_BELLY = 540f;
    public static final float S_BREAK = 755f;
    public static final float REACTION_TIME_SEC = 0.2f;
    public static final float V_AIM = 3775f;

    private AssistiveHeadLockFormula() {}

    public static float headDistancePx(float yHead) {
        float d = Y_BELLY - yHead;
        return d < 0f ? 0f : d;
    }

    public static float swipeDistancePx(float yHead) {
        return S_BREAK + headDistancePx(yHead);
    }

    public static float swipeSpeedPxPerSec(float yHead) {
        return V_AIM + 5f * headDistancePx(yHead);
    }

    public static long swipeDurationMs(float yHead) {
        float s = swipeDistancePx(yHead);
        float v = swipeSpeedPxPerSec(yHead);
        if (v <= 1e-6f) return 200L;
        long ms = Math.round((s / v) * 1000f);
        if (ms < 120L) ms = 120L;
        if (ms > 280L) ms = 280L;
        return ms;
    }

    public static float finalY(float startY, float yHead) {
        return startY - swipeDistancePx(yHead);
    }
}

