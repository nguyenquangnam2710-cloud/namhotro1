package com.assistive.filter;

public final class AssistiveHeadLockFormula {

    public static final float Y_BODY = 540f;
    public static final float S_BREAK = 755f;
    public static final float T_SEC = 0.2f;

    private AssistiveHeadLockFormula() {}

    public static float headDistancePx(float yHead) {
        float d = Y_BODY - yHead;
        return d < 0f ? 0f : d;
    }

    public static float swipeDistancePx(float yHead) {
        return S_BREAK + headDistancePx(yHead);
    }

    public static float swipeSpeedPxPerSec(float yHead) {
        return (S_BREAK / T_SEC) + (headDistancePx(yHead) / T_SEC);
    }

    public static long swipeDurationMs(float yHead) {
        return 200L;
    }

    public static float finalY(float startY, float yHead) {
        return startY - swipeDistancePx(yHead);
    }
}

