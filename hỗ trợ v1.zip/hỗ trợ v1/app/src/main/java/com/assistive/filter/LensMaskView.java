package com.assistive.filter;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.view.View;

public final class LensMaskView extends View {

    private final Paint maskPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint bmpPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ringPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path clipPath = new Path();

    private final Paint dotPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    private volatile Bitmap frame;
    private volatile float tx = -1f;
    private volatile float ty = -1f;
    private volatile float tc = 0f;

    public LensMaskView(Context c) {
        super(c);
        setLayerType(LAYER_TYPE_HARDWARE, null);

        maskPaint.setColor(0xFF000000);
        maskPaint.setStyle(Paint.Style.FILL);
        maskPaint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.CLEAR));

        bmpPaint.setAntiAlias(true);
        bmpPaint.setFilterBitmap(true);

        ringPaint.setStyle(Paint.Style.STROKE);
        ringPaint.setStrokeWidth(dp(2f));
        ringPaint.setColor(0xFFFF1744);

        dotPaint.setStyle(Paint.Style.FILL);
        dotPaint.setColor(0xFFFFEB3B);
    }

    public void setFrame(Bitmap b) {
        frame = b;
        postInvalidateOnAnimation();
    }

    public void setTarget(float x, float y, float confidence) {
        tx = x;
        ty = y;
        tc = confidence;
        postInvalidateOnAnimation();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        float w = getWidth();
        float h = getHeight();
        float cx = w * 0.5f;
        float cy = h * 0.5f;
        float r = Math.min(cx, cy);

        // === Bước 1: Vẽ nền đen toàn bộ view ===
        canvas.drawColor(0xFF000000);

        // === Bước 2: Vẽ bitmap frame (ảnh từ màn hình) ===
        Bitmap b = frame;
        if (b != null && !b.isRecycled()) {
            Rect dst = new Rect(0, 0, getWidth(), getHeight());
            canvas.drawBitmap(b, null, dst, bmpPaint);
        }

        // === Bước 3: Tạo mặt nạ - khoét lỗ tròn bên trong ===
        clipPath.reset();
        clipPath.addCircle(cx, cy, r, Path.Direction.CW);

        // Lưu layer và vẽ lỗ trong suốt
        int save = canvas.saveLayer(0, 0, w, h, null);
        canvas.drawPath(clipPath, maskPaint); // Vẽ hình tròn với chế độ CLEAR
        canvas.restoreToCount(save);

        // === Bước 4: Vẽ vòng tròn đỏ viền ngoài ===
        canvas.drawCircle(cx, cy, r - ringPaint.getStrokeWidth() * 0.5f, ringPaint);

        // === Bước 5: Vẽ chấm target bên trong vòng tròn ===
        float x = tx;
        float y = ty;
        float conf = tc;

        if (x >= 0f && y >= 0f && b != null && !b.isRecycled() && b.getWidth() > 0 && b.getHeight() > 0) {
            int a = (int) (70f + 185f * conf);
            if (a < 30) a = 30;
            if (a > 255) a = 255;
            dotPaint.setAlpha(a);

            float dr = dp(4.5f) + dp(2.5f) * (1f - conf);

            Rect dst = new Rect(0, 0, getWidth(), getHeight());
            float dx = dst.left + (x * (float) dst.width() / (float) b.getWidth());
            float dy = dst.top + (y * (float) dst.height() / (float) b.getHeight());

            canvas.drawCircle(dx, dy, dr, dotPaint);
        }
    }

    private float dp(float v) {
        return v * getResources().getDisplayMetrics().density;
    }
}
