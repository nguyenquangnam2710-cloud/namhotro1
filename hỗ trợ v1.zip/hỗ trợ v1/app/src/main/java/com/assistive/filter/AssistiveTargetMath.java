package com.assistive.filter;

import android.util.DisplayMetrics;

public final class AssistiveTargetMath {

    private AssistiveTargetMath() {}

    public static double scaleRatio(double baseValue, double currentValue) {
        if (baseValue <= 0.0) return Double.NaN;
        if (currentValue <= 0.0) return Double.NaN;
        return baseValue / currentValue;
    }

    public static float computeYTargetPx(DisplayMetrics dm, double baseValue, double currentValue, double baseYOffsetPx) {
        if (dm == null) return -1f;
        double scale = scaleRatio(baseValue, currentValue);
        if (Double.isNaN(scale)) return -1f;

        double centerY = dm.heightPixels * 0.5;
        return (float) (centerY - (baseYOffsetPx * scale));
    }

    public static float computeXTargetPx(DisplayMetrics dm, double baseValue, double currentValue, int direction, double baseXPredictionPx) {
        if (dm == null) return -1f;
        double scale = scaleRatio(baseValue, currentValue);
        if (Double.isNaN(scale)) return -1f;

        int dir = direction >= 0 ? 1 : -1;
        double centerX = dm.widthPixels * 0.5;
        return (float) (centerX + (baseXPredictionPx * scale * dir));
    }

    public static double distanceMeters(double displayHeightMeters, double fovVerticalDeg) {
        double halfRad = Math.toRadians(fovVerticalDeg * 0.5);
        double t = Math.tan(halfRad);
        if (t == 0.0) return Double.NaN;
        return displayHeightMeters / (2.0 * t);
    }
}
