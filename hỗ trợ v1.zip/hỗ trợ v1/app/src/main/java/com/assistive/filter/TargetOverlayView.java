package com.assistive.filter;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.View;

public final class TargetOverlayView extends View {

    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

    private volatile float x = -1f;
    private volatile float y = -1f;
    private volatile float c = 0f;

    public TargetOverlayView(Context context) {
        super(context);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(dp(2f));
        p.setColor(0xFFFF1744);
    }

    public void setTarget(float x, float y, float confidence) {
        this.x = x;
        this.y = y;
        this.c = confidence;
        postInvalidateOnAnimation();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        float cx = x;
        float cy = y;
        float conf = c;
        if (cx < 0f || cy < 0f) return;

        float r = dp(10f) + dp(18f) * (1f - conf);
        int a = (int) (60f + 195f * conf);
        if (a < 30) a = 30;
        if (a > 255) a = 255;
        p.setAlpha(a);

        if (r < dp(6f)) r = dp(6f);
        canvas.drawCircle(cx, cy, r, p);
    }

    private float dp(float v) {
        return v * getResources().getDisplayMetrics().density;
    }
}

