package com.assistive.filter;

public final class TargetSample {
    public final long tMillis;
    public final float x;
    public final float y;
    public final float vx;
    public final float vy;
    public final float confidence;

    public TargetSample(long tMillis, float x, float y, float vx, float vy, float confidence) {
        this.tMillis = tMillis;
        this.x = x;
        this.y = y;
        this.vx = vx;
        this.vy = vy;
        this.confidence = confidence;
    }
}

