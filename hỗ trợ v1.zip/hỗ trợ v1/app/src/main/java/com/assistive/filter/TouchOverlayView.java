// File: TouchOverlayView.java - Không chặn touch, chỉ phát hiện chạm vùng bắn
package com.assistive.filter;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.MotionEvent;
import android.view.View;

public class TouchOverlayView extends View {

    private AssistTouchAccessibilityService service;
    private float triggerThreshold = 0.6f;
    private Handler handler = new Handler(Looper.getMainLooper());
    private Runnable aimRunnable;

    public TouchOverlayView(Context context, AssistTouchAccessibilityService service) {
        super(context);
        this.service = service;
        setClickable(false);
        setFocusable(false);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (event.getActionMasked() == MotionEvent.ACTION_DOWN) {
            DisplayMetrics dm = getResources().getDisplayMetrics();
            float x = event.getRawX();
            if (x > dm.widthPixels * triggerThreshold) {
                if (aimRunnable != null) handler.removeCallbacks(aimRunnable);
                aimRunnable = new Runnable() {
                    @Override
                    public void run() {
                        if (service != null) {
                            service.triggerAim();
                        }
                    }
                };
                handler.postDelayed(aimRunnable, 10);
            }
        }
        // Không chặn touch
        return false;
    }
}
