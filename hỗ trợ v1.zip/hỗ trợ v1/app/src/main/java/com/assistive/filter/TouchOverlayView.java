package com.assistive.filter;

import android.content.Context;
import android.view.MotionEvent;
import android.view.ViewConfiguration;
import android.widget.FrameLayout;

public final class TouchOverlayView extends FrameLayout {

    public interface Listener {
        void onDown(float x, float y);
        void onMove(float dx, float dy);
        void onUp();
    }

    public Listener listener;

    private final int slop;

    private float downX;
    private float downY;
    private float lastX;
    private float lastY;
    private boolean moved;

    public TouchOverlayView(Context context) {
        super(context);
        slop = ViewConfiguration.get(context).getScaledTouchSlop();
        setClickable(true);
        setFocusable(false);
    }

    @Override
    public boolean onTouchEvent(MotionEvent ev) {
        int a = ev.getActionMasked();

        if (a == MotionEvent.ACTION_DOWN) {
            moved = false;
            downX = ev.getRawX();
            downY = ev.getRawY();
            lastX = downX;
            lastY = downY;
            if (listener != null) listener.onDown(downX, downY);
            return true;
        }

        if (a == MotionEvent.ACTION_MOVE) {
            float x = ev.getRawX();
            float y = ev.getRawY();

            float dx = x - lastX;
            float dy = y - lastY;

            if (!moved) {
                float tdx = x - downX;
                float tdy = y - downY;
                if (Math.abs(tdx) > slop || Math.abs(tdy) > slop) moved = true;
            }

            lastX = x;
            lastY = y;

            if (moved && listener != null) listener.onMove(dx, dy);
            return true;
        }

        if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
            if (listener != null) listener.onUp();
            return true;
        }

        return super.onTouchEvent(ev);
    }
}

