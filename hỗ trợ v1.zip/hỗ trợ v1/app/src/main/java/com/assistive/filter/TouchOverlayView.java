package com.assistive.filter;

import android.content.Context;
import android.view.MotionEvent;
import android.view.ViewConfiguration;
import android.widget.FrameLayout;

public class TouchOverlayView extends FrameLayout {

    public interface Listener {
        void onLongPress(float x, float y);
    }

    public Listener listener;
    private final int longPressTimeout;
    private final float slop;
    private float downX, downY;
    private boolean moved;
    private boolean longPressTriggered;
    private Runnable longPressRunnable;

    public TouchOverlayView(Context context) {
        super(context);
        longPressTimeout = ViewConfiguration.getLongPressTimeout();
        slop = ViewConfiguration.get(context).getScaledTouchSlop();
        setClickable(false);
        setFocusable(false);
        longPressRunnable = new Runnable() {
            @Override
            public void run() {
                if (!moved && !longPressTriggered && listener != null) {
                    longPressTriggered = true;
                    listener.onLongPress(downX, downY);
                }
            }
        };
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                moved = false;
                longPressTriggered = false;
                downX = event.getRawX();
                downY = event.getRawY();
                removeCallbacks(longPressRunnable);
                postDelayed(longPressRunnable, longPressTimeout);
                return false;
            case MotionEvent.ACTION_MOVE:
                float dx = Math.abs(event.getRawX() - downX);
                float dy = Math.abs(event.getRawY() - downY);
                if (dx > slop || dy > slop) {
                    moved = true;
                    removeCallbacks(longPressRunnable);
                }
                return false;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                removeCallbacks(longPressRunnable);
                return false;
        }
        return false;
    }
}
