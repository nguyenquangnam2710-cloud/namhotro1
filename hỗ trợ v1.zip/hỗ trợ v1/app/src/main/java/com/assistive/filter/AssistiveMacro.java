// File: AssistiveMacro.java
package com.assistive.filter;

import android.util.DisplayMetrics;

public final class AssistiveMacro {

    public static final float DURATION_SEC = 0.2f;
    public static final float BASE_Y = 540f;
    public static final float HEAD_OFFSET_STAND = 25f;
    public static final float HEAD_OFFSET_RUN = 24f;
    public static final float V_WALK = 180f;
    public static final float V_RUN = 260f;

    private AssistiveMacro() {}

    public static float[] computeSwipe(DisplayMetrics dm, float targetYHead, float targetVX) {
        if (dm == null || targetYHead <= 0) return null;

        float startX = dm.widthPixels / 2f;
        float startY = BASE_Y;

        float absVX = Math.abs(targetVX);
        float deltaY = (absVX < 50f) ? HEAD_OFFSET_STAND : HEAD_OFFSET_RUN;
        if (deltaY < 0) deltaY = 0;

        float V_Y = deltaY / DURATION_SEC;
        if (V_Y < 200f) V_Y = 200f;
        if (V_Y > 1000f) V_Y = 1000f;

        float V_X;
        if (absVX < 50f) {
            V_X = 0f;
        } else if (absVX < 100f) {
            V_X = V_WALK * (targetVX > 0 ? 1 : -1);
        } else {
            V_X = V_RUN * (targetVX > 0 ? 1 : -1);
        }

        float endX = startX + V_X * DURATION_SEC;
        float endY = startY - V_Y * DURATION_SEC;

        if (endX < 0) endX = 0;
        if (endX > dm.widthPixels) endX = dm.widthPixels;
        if (endY < 0) endY = 0;
        if (endY > targetYHead) endY = targetYHead;

        long durationMs = (long)(DURATION_SEC * 1000);
        return new float[]{startX, startY, endX, endY, durationMs};
    }

    public static void executeSwipe(AssistTouchAccessibilityService service, float targetYHead, float targetVX) {
        if (service == null) return;
        DisplayMetrics dm = service.getResources().getDisplayMetrics();
        float[] swipe = computeSwipe(dm, targetYHead, targetVX);
        if (swipe == null) return;
        service.dispatchLineGesture(swipe[0], swipe[1], swipe[2], swipe[3], (long) swipe[4]);
    }
}
