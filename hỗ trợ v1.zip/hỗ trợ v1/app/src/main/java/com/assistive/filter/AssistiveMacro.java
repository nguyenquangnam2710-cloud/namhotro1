package com.assistive.filter;

import android.accessibilityservice.AccessibilityService;
import android.graphics.Path;

/**
 * Macro vuốt chéo cố định theo công thức thực chiến.
 * V_X = 260 pixel/giây (địch chạy ngang)
 * V_Y = 7790 pixel/giây (bù lực ghì + khoảng cách đầu)
 * Thời gian thực hiện: 0.2 giây
 */
public final class AssistiveMacro {

    // Hằng số thực chiến (mốc 10 mét, địch chạy ngang sang phải)
    public static final float V_X = 260f;   // pixel/giây
    public static final float V_Y = 7790f;  // pixel/giây
    public static final float DURATION_SEC = 0.2f;

    private AssistiveMacro() {
        // Lớp tiện ích, không khởi tạo
    }

    /**
     * Thực hiện một cú vuốt chéo từ vị trí bắt đầu đến vị trí kết thúc
     * dựa trên vận tốc và thời gian cố định.
     *
     * @param service AccessibilityService đang chạy (để dispatch gesture)
     * @param startX  tọa độ X bắt đầu
     * @param startY  tọa độ Y bắt đầu
     * @param vx      vận tốc theo trục X (pixel/giây, dương là sang phải)
     * @param vy      vận tốc theo trục Y (pixel/giây, dương là lên trên)
     * @param durationSec thời gian vuốt (giây)
     */
    public static void executeMacroSwipe(AssistTouchAccessibilityService service,
                                         float startX, float startY,
                                         float vx, float vy, float durationSec) {
        // Tính toán điểm kết thúc
        float dx = vx * durationSec;
        float dy = vy * durationSec;
        float endX = clampX(service, startX + dx);
        float endY = clampY(service, startY - dy); // trừ vì trục Y hướng xuống

        // Đảm bảo không vượt quá đỉnh mục tiêu (nếu có lens)
        float yHead = enhancelensservice.hasLiveTarget() ? 
			enhancelensservice.getLastTargetScreenY() : -1f;
        if (yHead >= 0f) {
            float targetEndY = clampY(service, AssistiveHeadLockFormula.finalY(startY, yHead));
            if (endY < targetEndY) {
                endY = targetEndY;
            }
        }

        long dur = (long)(durationSec * 1000f);
        service.dispatchLineGesture(startX, startY, endX, endY, dur);
    }

    // Phương thức clamp tạm, vì trong service không truy cập được private method
    // Nên ta cần public static helper hoặc truyền DisplayMetrics
    private static float clampX(AssistTouchAccessibilityService service, float x) {
        android.util.DisplayMetrics dm = service.getResources().getDisplayMetrics();
        float max = Math.max(0f, (float) dm.widthPixels - 1f);
        if (x < 0f) return 0f;
        if (x > max) return max;
        return x;
    }

    private static float clampY(AssistTouchAccessibilityService service, float y) {
        android.util.DisplayMetrics dm = service.getResources().getDisplayMetrics();
        float max = Math.max(0f, (float) dm.heightPixels - 1f);
        if (y < 0f) return 0f;
        if (y > max) return max;
        return y;
    }
}
