package com.assistive.filter;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.WindowManager;

import org.opencv.android.OpenCVLoader;
import org.opencv.android.Utils;
import org.opencv.core.Core;
import org.opencv.core.CvType;
import org.opencv.core.Mat;
import org.opencv.core.MatOfPoint;
import org.opencv.core.Size;
import org.opencv.imgproc.Imgproc;
import org.opencv.video.BackgroundSubtractorMOG2;
import org.opencv.video.Video;

import java.io.File;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

public final class enhancelensservice extends Service {

    public static final String ACTION_START_EDIT = "com.assistive.filter.LENS_START_EDIT";
    public static final String ACTION_START_LOCKED = "com.assistive.filter.LENS_START_LOCKED";
    public static final String ACTION_STOP = "com.assistive.filter.LENS_STOP";
    public static final String ACTION_HIDE_LENS = "com.assistive.filter.LENS_HIDE";
    public static final String ACTION_SHOW_LENS = "com.assistive.filter.LENS_SHOW";

    public static final String EXTRA_RESULT_CODE = "result_code";
    public static final String EXTRA_RESULT_DATA = "result_data";

    private static final int NOTIF_ID = 5003;
    private static final String CHANNEL_ID = "assistive_enhance_lens";

    private static final int WORK_SIZE = 120;
    private static final int PROCESS_EVERY_N_FRAMES = 3;

    private WindowManager wm;
    private WindowManager.LayoutParams params;
    private LensMaskView overlay;
    private int touchSlop;
    private int startX, startY;
    private float downRawX, downRawY;
    private int lensSizePx;
    private ScaleGestureDetector scaleDetector;
    private float scale = 1.0f;
    private int baseLensSizePx;
    private int screenW, screenH;
    private MediaProjection projection;
    private VirtualDisplay vdisplay;
    private ImageReader reader;
    private HandlerThread workerThread;
    private Handler worker;
    private Bitmap outBitmap;
    private Bitmap workBitmap;
    private final AtomicBoolean processing = new AtomicBoolean(false);
    private int frameNo;
    private int cachedW, cachedH;
    private Ellipse cachedEllipse;
    private BackgroundSubtractorMOG2 bg;
    private Mat matRgba, matSmall, matFg, matKernel;
    private int processCounter = 0;
    private boolean overlayVisible = true;

    private static final class PriorityTemplate {
        final String name;
        final Bitmap bitmap;
        final Mat gray;
        final float weight;
        PriorityTemplate(String name, Bitmap bitmap, Mat gray, float weight) {
            this.name = name;
            this.bitmap = bitmap;
            this.gray = gray;
            this.weight = weight;
        }
    }

    private final ArrayList<PriorityTemplate> priorityTemplates = new ArrayList<>();
    private long priorityLastLoad;
    private final Kalman2D dotKf = new Kalman2D();
    private long dotLastT, dotLastMeasT;
    private float dotLastMeasX, dotLastMeasY;
    private boolean dotNeedReset = true;
    private long lastFoundMillis;
    private static volatile boolean sHasTarget;
    private static volatile float sLastTargetScreenX = -1f;
    private static volatile float sLastTargetScreenY = -1f;
    private static volatile float sLastTargetConfidence;
    private static volatile float sLastTargetVelocityX;
    private boolean locked = false;
    private View.OnTouchListener touchListener;

    public static boolean hasLiveTarget() { return sHasTarget; }
    public static float getLastTargetScreenX() { return sLastTargetScreenX; }
    public static float getLastTargetScreenY() { return sLastTargetScreenY; }
    public static float getLastTargetConfidence() { return sLastTargetConfidence; }
    public static float getLastTargetVelocityX() { return sLastTargetVelocityX; }

    @Override
    public void onCreate() {
        super.onCreate();
        try {
            if (OpenCVLoader.initDebug()) {
                initOpenCVComponents();
            }
        } catch (Throwable t) { t.printStackTrace(); }

        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        touchSlop = ViewConfiguration.get(this).getScaledTouchSlop();
        float d = getResources().getDisplayMetrics().density;
        lensSizePx = (int) (220f * d);
        if (lensSizePx < 160) lensSizePx = 160;
        baseLensSizePx = lensSizePx;
        updateScreenSize();
        overlay = new LensMaskView(this);
        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
            ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            : WindowManager.LayoutParams.TYPE_PHONE;
        params = new WindowManager.LayoutParams(lensSizePx, lensSizePx, type, flagsInteractive(), PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.START;
        // initially center
        int centerX = screenW / 2;
        int centerY = screenH / 2;
        params.x = centerX - (lensSizePx / 2);
        params.y = centerY - (lensSizePx / 2);

        touchListener = new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent e) {
                if (locked) return false;
                try { scaleDetector.onTouchEvent(e); } catch (Throwable ignore) {}
                if (scaleDetector != null && scaleDetector.isInProgress()) return true;
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        downRawX = e.getRawX();
                        downRawY = e.getRawY();
                        startX = params.x;
                        startY = params.y;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        if (!locked) {
                            params.x = startX + Math.round(e.getRawX() - downRawX);
                            params.y = startY + Math.round(e.getRawY() - downRawY);
                            clampToScreen();
                            updateLayoutSafe();
                        }
                        return true;
                    default: return true;
                }
            }
        };
        overlay.setOnTouchListener(touchListener);
        scaleDetector = new ScaleGestureDetector(this, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
				@Override
				public boolean onScale(ScaleGestureDetector detector) {
					scale *= detector.getScaleFactor();
					if (scale < 0.25f) scale = 0.25f;
					if (scale > 3.0f) scale = 3.0f;
					applyLensSize((int)(baseLensSizePx * scale));
					updateLayoutSafe();
					return true;
				}
			});
        workerThread = new HandlerThread("lens_worker");
        workerThread.start();
        worker = new Handler(workerThread.getLooper());
    }

    private void initOpenCVComponents() {
        try {
            bg = Video.createBackgroundSubtractorMOG2(60, 16, false);
            matKernel = Imgproc.getStructuringElement(Imgproc.MORPH_ELLIPSE, new Size(5, 5));
            loadPriorityTemplatesIfNeeded();
        } catch (Throwable t) { t.printStackTrace(); }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent != null ? intent.getAction() : null;
        if (ACTION_STOP.equals(action)) {
            shutdownProjection();
            removeOverlay();
            stopForeground(true);
            stopSelf();
            return START_NOT_STICKY;
        }

        if (ACTION_HIDE_LENS.equals(action)) {
            overlayVisible = false;
            removeOverlay();
            return START_STICKY;
        }
        if (ACTION_SHOW_LENS.equals(action)) {
            overlayVisible = true;
            if (locked) addOverlayIfNeeded();
            return START_STICKY;
        }

        startForegroundSafe();
        updateScreenSize();

        if (ACTION_START_LOCKED.equals(action)) {
            locked = true;
            params.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
            // force center
            int centerX = screenW / 2;
            int centerY = screenH / 2;
            params.x = centerX - (lensSizePx / 2);
            params.y = centerY - (lensSizePx / 2);
            if (overlayVisible) addOverlayIfNeeded();
            else removeOverlay();
            overlay.setOnTouchListener(null);
        } else if (ACTION_START_EDIT.equals(action)) {
            locked = false;
            params.flags = flagsInteractive();
            if (overlayVisible) addOverlayIfNeeded();
            overlay.setOnTouchListener(touchListener);
        }

        clampToScreen();
        updateLayoutSafe();

        if (projection == null && intent != null) {
            int resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0);
            Intent data = intent.getParcelableExtra(EXTRA_RESULT_DATA);
            if (resultCode != 0 && data != null) setupProjection(resultCode, data);
        }
        return START_STICKY;
    }

    private int flagsInteractive() {
        return WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL;
    }

    private void startForegroundSafe() {
        try {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (nm == null) return;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                NotificationChannel ch = new NotificationChannel(CHANNEL_ID, "Enhance Lens", NotificationManager.IMPORTANCE_MIN);
                ch.setSound(null, null);
                nm.createNotificationChannel(ch);
            }
            Notification.Builder b = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(this, CHANNEL_ID) : new Notification.Builder(this);
            Notification n = b.setOngoing(true)
                .setSmallIcon(android.R.drawable.ic_menu_camera)
                .setContentTitle("Assistive Filter")
                .setContentText("Lens running")
                .build();
            startForeground(NOTIF_ID, n);
        } catch (Throwable t) { stopSelf(); }
    }

    private void addOverlayIfNeeded() {
        if (overlay == null) return;
        if (overlay.getParent() != null) return;
        try { wm.addView(overlay, params); } catch (Throwable ignore) {}
    }

    private void removeOverlay() {
        try { if (wm != null && overlay != null && overlay.getParent() != null) wm.removeView(overlay); } catch (Throwable ignore) {}
    }

    private void updateLayoutSafe() {
        try { if (wm != null && overlay != null && overlay.getParent() != null) wm.updateViewLayout(overlay, params); } catch (Throwable ignore) {}
    }

    private void updateScreenSize() {
        DisplayMetrics dm = getResources().getDisplayMetrics();
        screenW = dm.widthPixels;
        screenH = dm.heightPixels;
        if (screenW < 1) screenW = 1080;
        if (screenH < 1) screenH = 1920;
    }

    private void clampToScreen() {
        updateScreenSize();
        if (locked) {
            // Force center
            int centerX = screenW / 2;
            int centerY = screenH / 2;
            params.x = centerX - (lensSizePx / 2);
            params.y = centerY - (lensSizePx / 2);
        } else {
            int maxX = Math.max(0, screenW - params.width);
            int maxY = Math.max(0, screenH - params.height);
            params.x = Math.max(0, Math.min(params.x, maxX));
            params.y = Math.max(0, Math.min(params.y, maxY));
        }
    }

    private void applyLensSize(int newSizePx) {
        updateScreenSize();
        int old = lensSizePx;
        int cx = params.x + old/2;
        int cy = params.y + old/2;
        int sz = Math.max(120, Math.min(newSizePx, Math.min(screenW, screenH)));
        lensSizePx = sz;
        params.width = sz;
        params.height = sz;
        if (!locked) {
            params.x = cx - sz/2;
            params.y = cy - sz/2;
        } else {
            int centerX = screenW / 2;
            int centerY = screenH / 2;
            params.x = centerX - (sz / 2);
            params.y = centerY - (sz / 2);
        }
        clampToScreen();
        dotNeedReset = true;
        cachedEllipse = null;
        cachedW = cachedH = frameNo = 0;
        try { if (bg != null) bg.clear(); } catch (Throwable ignore) {}
        releaseMats();
    }

    private void releaseMats() {
        try { if (matRgba != null) matRgba.release(); } catch (Throwable ignore) {}
        try { if (matSmall != null) matSmall.release(); } catch (Throwable ignore) {}
        try { if (matFg != null) matFg.release(); } catch (Throwable ignore) {}
        matRgba = matSmall = matFg = null;
    }

    private void setupProjection(int resultCode, Intent data) {
        try {
            MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
            if (mpm == null) return;
            projection = mpm.getMediaProjection(resultCode, data);
            if (projection == null) return;
            DisplayMetrics dm = getResources().getDisplayMetrics();
            reader = ImageReader.newInstance(dm.widthPixels, dm.heightPixels, PixelFormat.RGBA_8888, 2);
            vdisplay = projection.createVirtualDisplay("enhance_lens",
													   dm.widthPixels, dm.heightPixels, dm.densityDpi,
													   DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
													   reader.getSurface(), null, worker);
            reader.setOnImageAvailableListener(new ImageReader.OnImageAvailableListener() {
					@Override
					public void onImageAvailable(ImageReader ir) {
						if (processing.getAndSet(true)) return;
						worker.post(new Runnable() {
								@Override
								public void run() {
									try { processFrame(); } finally { processing.set(false); }
								}
							});
					}
				}, worker);
        } catch (Throwable ignore) {}
    }

    private void processFrame() {
        if (reader == null) return;
        Image img = null;
        try {
            img = reader.acquireLatestImage();
            if (img == null) return;
            processCounter++;
            if (processCounter % PROCESS_EVERY_N_FRAMES != 0) return;
            Image.Plane[] planes = img.getPlanes();
            if (planes == null || planes.length < 1) return;
            ByteBuffer buf = planes[0].getBuffer();
            int pixelStride = planes[0].getPixelStride();
            int rowStride = planes[0].getRowStride();
            DisplayMetrics dm = getResources().getDisplayMetrics();
            int sw = dm.widthPixels, sh = dm.heightPixels;
            int rowPadding = rowStride - pixelStride * sw;
            int bmpW = sw + rowPadding / pixelStride;
            Bitmap full = Bitmap.createBitmap(bmpW, sh, Bitmap.Config.ARGB_8888);
            full.copyPixelsFromBuffer(buf);

            // --- FORCE CENTER EVERY FRAME IF LOCKED ---
            updateScreenSize();
            if (locked) {
                int centerX = screenW / 2;
                int centerY = screenH / 2;
                int newX = centerX - (lensSizePx / 2);
                int newY = centerY - (lensSizePx / 2);
                if (params.x != newX || params.y != newY) {
                    params.x = newX;
                    params.y = newY;
                    updateLayoutSafe();
                }
            }

            int cx = params.x + lensSizePx/2;
            int cy = params.y + lensSizePx/2;
            int half = lensSizePx/2;
            int left = Math.max(0, Math.min(cx - half, sw - lensSizePx));
            int top = Math.max(0, Math.min(cy - half, sh - lensSizePx));
            Bitmap crop = Bitmap.createBitmap(full, left, top, lensSizePx, lensSizePx);
            if (workBitmap == null) {
                workBitmap = Bitmap.createBitmap(WORK_SIZE, WORK_SIZE, Bitmap.Config.ARGB_8888);
                cachedEllipse = null;
                dotNeedReset = true;
                releaseMats();
                if (bg != null) try { bg.clear(); } catch (Throwable ignore) {}
            }
            Canvas wc = new Canvas(workBitmap);
            wc.drawBitmap(crop, null, new Rect(0, 0, WORK_SIZE, WORK_SIZE), null);
            Ellipse e = (bg != null && processCounter % (PROCESS_EVERY_N_FRAMES * 2) == 0)
				? getPriorityEllipseWithBg(workBitmap) : getPriorityEllipse(workBitmap);
            long now = System.currentTimeMillis();
            updateTargetOverlay(e, now, workBitmap.getWidth(), workBitmap.getHeight());
            applyLensEffect(workBitmap, e);
            if (outBitmap == null || outBitmap.getWidth() != lensSizePx || outBitmap.getHeight() != lensSizePx) {
                outBitmap = Bitmap.createBitmap(lensSizePx, lensSizePx, Bitmap.Config.ARGB_8888);
            }
            Canvas oc = new Canvas(outBitmap);
            oc.drawBitmap(workBitmap, null, new Rect(0, 0, lensSizePx, lensSizePx), null);
            if (overlay != null && overlay.getParent() != null) overlay.setFrame(outBitmap);
            crop.recycle();
            full.recycle();
        } catch (Throwable ignore) {
        } finally {
            if (img != null) try { img.close(); } catch (Throwable ignore) {}
        }
    }

    private void updateTargetOverlay(Ellipse e, long now, int workW, int workH) {
        if (overlay == null || overlay.getParent() == null) {
            // still update static variables even if overlay is hidden
            if (e != null) {
                float mx = e.cx * ((float) lensSizePx / workW);
                float my = e.cy * ((float) lensSizePx / workH);
                float conf = 0.90f;
                float mvx = 0f, mvy = 0f;
                if (dotLastMeasT != 0L) {
                    long d = Math.min(80L, Math.max(1L, now - dotLastMeasT));
                    float dt = d / 1000f;
                    mvx = (mx - dotLastMeasX) / dt;
                    mvy = (my - dotLastMeasY) / dt;
                }
                dotLastMeasT = now;
                dotLastMeasX = mx;
                dotLastMeasY = my;
                if (dotNeedReset || dotLastT == 0L) {
                    dotKf.reset(new TargetSample(now, mx, my, mvx, mvy, conf));
                    dotNeedReset = false;
                    dotLastT = now;
                } else {
                    long d = Math.min(50L, Math.max(1L, now - dotLastT));
                    float dt = d / 1000f;
                    dotLastT = now;
                    dotKf.predict(dt);
                    dotKf.update(mx, my, mvx, mvy, conf);
                }
                TargetSample st = dotKf.getState(now, conf);
                float px = st.x + st.vx * 0.02f;
                float py = st.y + st.vy * 0.02f;
                sHasTarget = true;
                sLastTargetScreenX = params.x + px;
                sLastTargetScreenY = params.y + py;
                sLastTargetConfidence = conf;
                sLastTargetVelocityX = mvx;
                lastFoundMillis = now;
            } else {
                if (!dotNeedReset && dotLastT != 0L && lastFoundMillis != 0L && (now - lastFoundMillis) <= 900L) {
                    TargetSample st = dotKf.getState(now, 0.40f);
                    float px = st.x + st.vx * 0.02f;
                    float py = st.y + st.vy * 0.02f;
                    sHasTarget = true;
                    sLastTargetScreenX = params.x + px;
                    sLastTargetScreenY = params.y + py;
                    sLastTargetConfidence = 0.40f;
                    sLastTargetVelocityX = 0f;
                } else {
                    dotNeedReset = true;
                    dotLastMeasT = dotLastT = 0L;
                    sHasTarget = false;
                    sLastTargetScreenX = sLastTargetScreenY = -1f;
                    sLastTargetConfidence = sLastTargetVelocityX = 0f;
                }
            }
            return;
        }

        // normal drawing case
        if (e != null) {
            float mx = e.cx * ((float) lensSizePx / workW);
            float my = e.cy * ((float) lensSizePx / workH);
            float conf = 0.90f;
            float mvx = 0f, mvy = 0f;
            if (dotLastMeasT != 0L) {
                long d = Math.min(80L, Math.max(1L, now - dotLastMeasT));
                float dt = d / 1000f;
                mvx = (mx - dotLastMeasX) / dt;
                mvy = (my - dotLastMeasY) / dt;
            }
            dotLastMeasT = now;
            dotLastMeasX = mx;
            dotLastMeasY = my;
            if (dotNeedReset || dotLastT == 0L) {
                dotKf.reset(new TargetSample(now, mx, my, mvx, mvy, conf));
                dotNeedReset = false;
                dotLastT = now;
            } else {
                long d = Math.min(50L, Math.max(1L, now - dotLastT));
                float dt = d / 1000f;
                dotLastT = now;
                dotKf.predict(dt);
                dotKf.update(mx, my, mvx, mvy, conf);
            }
            TargetSample st = dotKf.getState(now, conf);
            float px = st.x + st.vx * 0.02f;
            float py = st.y + st.vy * 0.02f;
            overlay.setTarget(px, py, conf);
            lastFoundMillis = now;
            sHasTarget = true;
            sLastTargetScreenX = params.x + px;
            sLastTargetScreenY = params.y + py;
            sLastTargetConfidence = conf;
            sLastTargetVelocityX = mvx;
        } else {
            if (!dotNeedReset && dotLastT != 0L && lastFoundMillis != 0L && (now - lastFoundMillis) <= 900L) {
                TargetSample st = dotKf.getState(now, 0.40f);
                float px = st.x + st.vx * 0.02f;
                float py = st.y + st.vy * 0.02f;
                overlay.setTarget(px, py, 0.40f);
                sHasTarget = true;
                sLastTargetScreenX = params.x + px;
                sLastTargetScreenY = params.y + py;
                sLastTargetConfidence = 0.40f;
                sLastTargetVelocityX = 0f;
            } else {
                dotNeedReset = true;
                dotLastMeasT = dotLastT = 0L;
                sHasTarget = false;
                sLastTargetScreenX = sLastTargetScreenY = -1f;
                sLastTargetConfidence = sLastTargetVelocityX = 0f;
                overlay.setTarget(-1f, -1f, 0f);
            }
        }
    }

    private Ellipse getPriorityEllipseWithBg(Bitmap b) {
        cachedEllipse = null;
        return getPriorityEllipse(b);
    }

    private void loadPriorityTemplatesIfNeeded() {
        long now = System.currentTimeMillis();
        if (now - priorityLastLoad < 1200L) return;
        priorityLastLoad = now;
        android.content.SharedPreferences sp = getSharedPreferences("assistive_prefs", MODE_PRIVATE);
        java.util.Set<String> set = sp.getStringSet("priority_paths", null);
        for (int i = 0; i < priorityTemplates.size(); i++) {
            try { priorityTemplates.get(i).gray.release(); } catch (Throwable ignore) {}
        }
        priorityTemplates.clear();
        if (set == null || set.isEmpty()) return;
        for (String p : set) {
            if (p == null || p.isEmpty()) continue;
            File f = new File(p);
            if (!f.exists() || f.length() < 16) continue;
            Bitmap bmp = null;
            try { bmp = BitmapFactory.decodeFile(p); } catch (Throwable ignore) {}
            if (bmp == null) continue;
            Mat rgba = new Mat();
            Utils.bitmapToMat(bmp, rgba);
            Mat gray = new Mat();
            Imgproc.cvtColor(rgba, gray, Imgproc.COLOR_RGBA2GRAY);
            rgba.release();
            float w = 1f;
            try { w = sp.getFloat("priority_w_" + f.getName(), 1f); } catch (Throwable ignore) {}
            if (w <= 0f) w = 1f;
            if (w > 10f) w = 10f;
            priorityTemplates.add(new PriorityTemplate(f.getName(), bmp, gray, w));
        }
    }

    private Ellipse detectByPriorityTemplates(Bitmap b) {
        if (priorityTemplates.isEmpty()) return null;
        Mat rgba = new Mat(), rgb = new Mat(), hsv = new Mat(), frameV = new Mat();
        try {
            Utils.bitmapToMat(b, rgba);
            Imgproc.cvtColor(rgba, rgb, Imgproc.COLOR_RGBA2RGB);
            Imgproc.cvtColor(rgb, hsv, Imgproc.COLOR_RGB2HSV);
            Core.extractChannel(hsv, frameV, 2);
            Ellipse best = null;
            double bestWeighted = -1e9;
            float[] scales = {0.8f, 1.0f, 1.2f};
            for (PriorityTemplate pt : priorityTemplates) {
                Mat tplRgba = new Mat(), tplRgb = new Mat(), tplHsv = new Mat(), tplV = new Mat();
                try {
                    Utils.bitmapToMat(pt.bitmap, tplRgba);
                    Imgproc.cvtColor(tplRgba, tplRgb, Imgproc.COLOR_RGBA2RGB);
                    Imgproc.cvtColor(tplRgb, tplHsv, Imgproc.COLOR_RGB2HSV);
                    Core.extractChannel(tplHsv, tplV, 2);
                    for (float scale : scales) {
                        int newW = Math.round(tplV.cols() * scale);
                        int newH = Math.round(tplV.rows() * scale);
                        if (newW < 8 || newH < 8 || frameV.cols() < newW || frameV.rows() < newH) continue;
                        Mat scaled = new Mat();
                        Imgproc.resize(tplV, scaled, new Size(newW, newH));
                        Mat result = new Mat();
                        Imgproc.matchTemplate(frameV, scaled, result, Imgproc.TM_CCOEFF_NORMED);
                        Core.MinMaxLocResult mm = Core.minMaxLoc(result);
                        result.release();
                        scaled.release();
                        if (mm != null && mm.maxVal >= 0.78) {
                            double weighted = mm.maxVal * pt.weight;
                            if (weighted > bestWeighted) {
                                bestWeighted = weighted;
                                float cx = (float)(mm.maxLoc.x + newW * 0.5);
                                float cy = (float)(mm.maxLoc.y + newH * 0.5);
                                float ax = Math.max(14f, newW * 0.55f);
                                float ay = Math.max(14f, newH * 0.55f);
                                best = new Ellipse(cx, cy, ax, ay);
                            }
                        }
                    }
                } finally {
                    try { tplRgba.release(); } catch (Throwable ignore) {}
                    try { tplRgb.release(); } catch (Throwable ignore) {}
                    try { tplHsv.release(); } catch (Throwable ignore) {}
                    try { tplV.release(); } catch (Throwable ignore) {}
                }
            }
            return best;
        } finally {
            try { rgba.release(); } catch (Throwable ignore) {}
            try { rgb.release(); } catch (Throwable ignore) {}
            try { hsv.release(); } catch (Throwable ignore) {}
            try { frameV.release(); } catch (Throwable ignore) {}
        }
    }

    private Ellipse getPriorityEllipse(Bitmap b) {
        int w = b.getWidth(), h = b.getHeight();
        loadPriorityTemplatesIfNeeded();
        Ellipse pe = null;
        try { pe = detectByPriorityTemplates(b); } catch (Throwable ignore) {}
        if (pe != null) return pe;
        frameNo++;
        boolean needDetect = (cachedW != w) || cachedH != h || cachedEllipse == null || (frameNo % 2 == 0);
        if (!needDetect) return cachedEllipse;
        Ellipse e = null;
        if (bg != null) {
            try { e = detectEnemyHeadByForegroundOpenCV(b); } catch (Throwable ignore) {}
        }
        if (e == null) {
            try { e = detectSkinBlobEllipse(b); } catch (Throwable ignore) {}
        }
        cachedEllipse = e;
        cachedW = w;
        cachedH = h;
        return e;
    }

    private Ellipse detectEnemyHeadByForegroundOpenCV(Bitmap b) {
        if (bg == null) return null;
        int w = b.getWidth(), h = b.getHeight();
        if (w < 80 || h < 80) return null;
        try {
            if (matRgba == null) matRgba = new Mat();
            Utils.bitmapToMat(b, matRgba);
            int sw = Math.max(160, w/2);
            int sh = Math.max(160, h/2);
            if (matSmall == null || matSmall.cols() != sw || matSmall.rows() != sh) {
                if (matSmall != null) try { matSmall.release(); } catch (Throwable ignore) {}
                if (matFg != null) try { matFg.release(); } catch (Throwable ignore) {}
                matSmall = new Mat(sh, sw, matRgba.type());
                matFg = new Mat(sh, sw, CvType.CV_8UC1);
            }
            Imgproc.resize(matRgba, matSmall, new Size(sw, sh), 0, 0, Imgproc.INTER_AREA);
            bg.apply(matSmall, matFg, 0.05);
            Imgproc.threshold(matFg, matFg, 200, 255, Imgproc.THRESH_BINARY);
            if (matKernel != null) {
                Imgproc.erode(matFg, matFg, matKernel);
                Imgproc.dilate(matFg, matFg, matKernel);
            }
            List<MatOfPoint> contours = new ArrayList<>();
            Mat hierarchy = new Mat();
            Imgproc.findContours(matFg, contours, hierarchy, Imgproc.RETR_EXTERNAL, Imgproc.CHAIN_APPROX_SIMPLE);
            hierarchy.release();
            float cx0 = sw * 0.5f, cy0 = sh * 0.5f;
            org.opencv.core.Rect best = null;
            float bestScore = -1e30f;
            float imgArea = sw * sh;
            for (MatOfPoint c : contours) {
                if (c == null) continue;
                org.opencv.core.Rect r = Imgproc.boundingRect(c);
                int bw = r.width, bh = r.height;
                if (bw < 16 || bh < 24) continue;
                float area = bw * bh;
                if (area < imgArea * 0.004f || area > imgArea * 0.80f) continue;
                float aspect = (float) bh / Math.max(1, bw);
                if (aspect < 0.85f || aspect > 5.5f) continue;
                float rcx = r.x + bw*0.5f, rcy = r.y + bh*0.5f;
                float dx = rcx - cx0, dy = rcy - cy0;
                float dist2 = dx*dx + dy*dy;
                float upperBias = (rcy < sh * 0.78f) ? 1.0f : 0.85f;
                float score = area * upperBias - dist2 * 0.30f;
                if (score > bestScore) { bestScore = score; best = r; }
            }
            for (MatOfPoint c : contours) try { c.release(); } catch (Throwable ignore) {}
            if (best == null) return null;
            float bx = best.x, by = best.y, bw = best.width, bh = best.height;
            float headX = bx + bw*0.5f;
            float headY = by + bh*0.18f;
            float scaleX = (float) w / sw, scaleY = (float) h / sh;
            float cx = headX * scaleX, cy = headY * scaleY;
            float ax = Math.max(14f, (bw * scaleX) * 0.35f);
            float ay = Math.max(14f, (bh * scaleY) * 0.30f);
            return new Ellipse(cx, cy, ax, ay);
        } catch (Throwable t) { return null; }
    }

    private Ellipse detectSkinBlobEllipse(Bitmap b) { return null; }
    private void applyLensEffect(Bitmap src, Ellipse target) { }

    private void shutdownProjection() {
        try { if (reader != null) reader.setOnImageAvailableListener(null, null); } catch (Throwable ignore) {}
        try { if (vdisplay != null) vdisplay.release(); } catch (Throwable ignore) {}
        try { if (projection != null) projection.stop(); } catch (Throwable ignore) {}
        reader = null; vdisplay = null; projection = null;
    }

    @Override public IBinder onBind(Intent intent) { return null; }
    @Override public void onDestroy() {
        shutdownProjection();
        removeOverlay();
        if (workerThread != null) workerThread.quitSafely();
        releaseMats();
        if (matKernel != null) matKernel.release();
        try { if (bg != null) bg.clear(); } catch (Throwable ignore) {}
        super.onDestroy();
    }
}
