package com.assistive.filter;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.WindowManager;

import org.opencv.android.OpenCVLoader;
import org.opencv.android.Utils;
import org.opencv.core.Core;
import org.opencv.core.CvType;
import org.opencv.core.Mat;
import org.opencv.core.MatOfPoint;
import org.opencv.core.MatOfRect;
import org.opencv.core.Size;
import org.opencv.imgproc.Imgproc;
import org.opencv.objdetect.CascadeClassifier;
import org.opencv.video.BackgroundSubtractorMOG2;
import org.opencv.video.Video;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

public final class enhancelensservice extends Service {

    public static final String ACTION_START_EDIT = "com.assistive.filter.LENS_START_EDIT";
    public static final String ACTION_START_LOCKED = "com.assistive.filter.LENS_START_LOCKED";
    public static final String ACTION_STOP = "com.assistive.filter.LENS_STOP";

    public static final String EXTRA_RESULT_CODE = "result_code";
    public static final String EXTRA_RESULT_DATA = "result_data";

    private static final int NOTIF_ID = 5003;
    private static final String CHANNEL_ID = "assistive_enhance_lens";

    private WindowManager wm;
    private WindowManager.LayoutParams params;
    private enhancelensview overlay;

    private int touchSlop;
    private int startX, startY;
    private float downRawX, downRawY;

    private int lensSizePx;

    private ScaleGestureDetector scaleDetector;
    private float scale = 1.0f;
    private int baseLensSizePx;
    private int screenW;
    private int screenH;

    private MediaProjection projection;
    private VirtualDisplay vdisplay;
    private ImageReader reader;

    private HandlerThread workerThread;
    private Handler worker;

    private Bitmap outBitmap;
    private Bitmap workBitmap;

    private int[] workPx;
    private int[] blurPx;

    private byte[] skinMask;
    private int[] queue;

    private final AtomicBoolean processing = new AtomicBoolean(false);

    private int frameNo;
    private int cachedW;
    private int cachedH;
    private Ellipse cachedEllipse;

    private CascadeClassifier faceCascade;

    private BackgroundSubtractorMOG2 bg;
    private Mat matRgba;
    private Mat matSmall;
    private Mat matFg;
    private Mat matKernel;

    private Mat priorityGray;
    private String priorityPath;

    private final Kalman2D dotKf = new Kalman2D();

    private long dotLastT;
    private long dotLastMeasT;
    private float dotLastMeasX;
    private float dotLastMeasY;

    private boolean dotNeedReset = true;

    private long lastFoundMillis;

    @Override
    public void onCreate() {
        super.onCreate();

        try {
            if (OpenCVLoader.initDebug()) {
                faceCascade = loadCascadeFromRaw(
                    R.raw.haarcascade_frontalface_alt2,
                    "haarcascade_frontalface_alt2.xml"
                );
                bg = Video.createBackgroundSubtractorMOG2(60, 16, false);
                matKernel = Imgproc.getStructuringElement(Imgproc.MORPH_ELLIPSE, new Size(5, 5));
                loadPriorityTemplateIfNeeded();
            }
        } catch (Throwable ignore) {
        }

        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        touchSlop = ViewConfiguration.get(this).getScaledTouchSlop();

        float d = getResources().getDisplayMetrics().density;
        lensSizePx = (int) (220f * d);
        if (lensSizePx < 160) lensSizePx = 160;

        baseLensSizePx = lensSizePx;
        updateScreenSize();

        overlay = new enhancelensview(this);

        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
            ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            : WindowManager.LayoutParams.TYPE_PHONE;

        params = new WindowManager.LayoutParams(
            lensSizePx,
            lensSizePx,
            type,
            flagsInteractive(),
            PixelFormat.TRANSLUCENT
        );

        params.gravity = Gravity.TOP | Gravity.START;
        DisplayMetrics dm = getResources().getDisplayMetrics();
        params.x = (dm.widthPixels / 2) - (lensSizePx / 2);
        params.y = (dm.heightPixels / 2) - (lensSizePx / 2);

        scaleDetector = new ScaleGestureDetector(this, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
				@Override
				public boolean onScale(ScaleGestureDetector detector) {
					scale *= detector.getScaleFactor();
					if (scale < 0.25f) scale = 0.25f;
					if (scale > 3.0f) scale = 3.0f;

					applyLensSize((int) (baseLensSizePx * scale));
					updateLayoutSafe();
					return true;
				}
			});

        overlay.setOnTouchListener(new View.OnTouchListener() {
				@Override
				public boolean onTouch(View v, MotionEvent e) {
					try { scaleDetector.onTouchEvent(e); } catch (Throwable ignore) {}
					if (scaleDetector != null && scaleDetector.isInProgress()) return true;

					switch (e.getActionMasked()) {
						case MotionEvent.ACTION_DOWN:
							downRawX = e.getRawX();
							downRawY = e.getRawY();
							startX = params.x;
							startY = params.y;
							return true;

						case MotionEvent.ACTION_MOVE: {
								float rawDx = e.getRawX() - downRawX;
								float rawDy = e.getRawY() - downRawY;

								params.x = startX + Math.round(rawDx);
								params.y = startY + Math.round(rawDy);

								clampToScreen();
								updateLayoutSafe();
								return true;
							}

						case MotionEvent.ACTION_UP:
						case MotionEvent.ACTION_CANCEL:
							return true;
					}

					return true;
				}
			});

        workerThread = new HandlerThread("lens_worker");
        workerThread.start();
        worker = new Handler(workerThread.getLooper());
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent != null ? intent.getAction() : null;

        if (ACTION_STOP.equals(action)) {
            shutdownProjection();
            removeOverlay();
            stopForeground(true);
            stopSelf();
            return START_NOT_STICKY;
        }

        startForegroundSafe();
        addOverlayIfNeeded();
        clampToScreen();
        updateLayoutSafe();

        if (projection == null) {
            int resultCode = intent != null ? intent.getIntExtra(EXTRA_RESULT_CODE, 0) : 0;
            Intent data = intent != null ? intent.getParcelableExtra(EXTRA_RESULT_DATA) : null;
            if (resultCode != 0 && data != null) {
                setupProjection(resultCode, data);
            }
        }

        return START_STICKY;
    }

    private int flagsInteractive() {
        return WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
            | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL;
    }

    private void startForegroundSafe() {
        try {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (nm == null) throw new RuntimeException("NotificationManager=null");

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                NotificationChannel ch = new NotificationChannel(
                    CHANNEL_ID, "Enhance Lens", NotificationManager.IMPORTANCE_MIN);
                ch.setSound(null, null);
                nm.createNotificationChannel(ch);
            }

            Notification.Builder b = (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);

            Notification n = b.setOngoing(true)
                .setSmallIcon(android.R.drawable.ic_menu_camera)
                .setContentTitle("Assistive Filter")
                .setContentText("Lens running")
                .build();

            startForeground(NOTIF_ID, n);
        } catch (Throwable t) {
            stopSelf();
        }
    }

    private void addOverlayIfNeeded() {
        if (overlay == null || overlay.getParent() != null) return;
        try { wm.addView(overlay, params); } catch (Throwable ignore) {}
    }

    private void removeOverlay() {
        try {
            if (wm != null && overlay != null && overlay.getParent() != null) wm.removeView(overlay);
        } catch (Throwable ignore) {}
    }

    private void updateLayoutSafe() {
        try {
            if (wm != null && overlay != null && overlay.getParent() != null) wm.updateViewLayout(overlay, params);
        } catch (Throwable ignore) {}
    }

    private void updateScreenSize() {
        DisplayMetrics dm = getResources().getDisplayMetrics();
        screenW = dm.widthPixels;
        screenH = dm.heightPixels;
        if (screenW < 1) screenW = 1080;
        if (screenH < 1) screenH = 1920;
    }

    private void clampToScreen() {
        updateScreenSize();

        int maxX = Math.max(0, screenW - params.width);
        int maxY = Math.max(0, screenH - params.height);

        if (params.x < 0) params.x = 0;
        if (params.y < 0) params.y = 0;
        if (params.x > maxX) params.x = maxX;
        if (params.y > maxY) params.y = maxY;
    }

    private void applyLensSize(int newSizePx) {
        updateScreenSize();

        int old = lensSizePx;
        int cx = params.x + (old / 2);
        int cy = params.y + (old / 2);

        int sz = newSizePx;
        if (sz < 120) sz = 120;
        if (sz > screenW) sz = screenW;
        if (sz > screenH) sz = screenH;

        lensSizePx = sz;
        params.width = sz;
        params.height = sz;

        params.x = cx - (sz / 2);
        params.y = cy - (sz / 2);

        clampToScreen();

        dotNeedReset = true;
        dotLastMeasT = 0L;
        dotLastT = 0L;
        lastFoundMillis = 0L;

        cachedEllipse = null;
        cachedW = 0;
        cachedH = 0;
        frameNo = 0;

        try {
            if (bg != null) bg.clear();
        } catch (Throwable ignore) {}

        try { if (matRgba != null) matRgba.release(); } catch (Throwable ignore) {}
        try { if (matSmall != null) matSmall.release(); } catch (Throwable ignore) {}
        try { if (matFg != null) matFg.release(); } catch (Throwable ignore) {}
        matRgba = null;
        matSmall = null;
        matFg = null;
    }

    private void setupProjection(int resultCode, Intent data) {
        try {
            MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
            if (mpm == null) return;

            projection = mpm.getMediaProjection(resultCode, data);
            if (projection == null) return;

            DisplayMetrics dm = getResources().getDisplayMetrics();
            int w = dm.widthPixels;
            int h = dm.heightPixels;
            int dpi = dm.densityDpi;

            reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2);

            vdisplay = projection.createVirtualDisplay(
                "enhance_lens",
                w,
                h,
                dpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                reader.getSurface(),
                null,
                worker
            );

            reader.setOnImageAvailableListener(new ImageReader.OnImageAvailableListener() {
					@Override
					public void onImageAvailable(ImageReader ir) {
						if (processing.getAndSet(true)) return;
						worker.post(new Runnable() {
								@Override
								public void run() {
									try {
										processFrame();
									} finally {
										processing.set(false);
									}
								}
							});
					}
				}, worker);

        } catch (Throwable ignore) {
        }
    }

    private void processFrame() {
        if (reader == null) return;

        Image img = null;
        try {
            img = reader.acquireLatestImage();
            if (img == null) return;

            Image.Plane[] planes = img.getPlanes();
            if (planes == null || planes.length < 1) return;

            ByteBuffer buf = planes[0].getBuffer();
            int pixelStride = planes[0].getPixelStride();
            int rowStride = planes[0].getRowStride();

            DisplayMetrics dm = getResources().getDisplayMetrics();
            int sw = dm.widthPixels;
            int sh = dm.heightPixels;

            int rowPadding = rowStride - pixelStride * sw;
            int bmpW = sw + rowPadding / pixelStride;

            Bitmap full = Bitmap.createBitmap(bmpW, sh, Bitmap.Config.ARGB_8888);
            full.copyPixelsFromBuffer(buf);

            int cx = params.x + (lensSizePx / 2);
            int cy = params.y + (lensSizePx / 2);

            int half = lensSizePx / 2;
            int left = cx - half;
            int top = cy - half;

            if (left < 0) left = 0;
            if (top < 0) top = 0;
            if (left + lensSizePx > sw) left = Math.max(0, sw - lensSizePx);
            if (top + lensSizePx > sh) top = Math.max(0, sh - lensSizePx);

            Bitmap crop = Bitmap.createBitmap(full, left, top, lensSizePx, lensSizePx);

            int workW = Math.max(160, lensSizePx / 2);
            int workH = workW;

            if (workBitmap == null || workBitmap.getWidth() != workW || workBitmap.getHeight() != workH) {
                workBitmap = Bitmap.createBitmap(workW, workH, Bitmap.Config.ARGB_8888);
                cachedEllipse = null;
                cachedW = 0;
                cachedH = 0;

                dotNeedReset = true;
                dotLastMeasT = 0L;
                dotLastT = 0L;
                lastFoundMillis = 0L;

                try {
                    if (bg != null) bg.clear();
                } catch (Throwable ignore) {}

                try { if (matRgba != null) matRgba.release(); } catch (Throwable ignore) {}
                try { if (matSmall != null) matSmall.release(); } catch (Throwable ignore) {}
                try { if (matFg != null) matFg.release(); } catch (Throwable ignore) {}
                matRgba = null;
                matSmall = null;
                matFg = null;
            }

            Canvas wc = new Canvas(workBitmap);
            wc.drawBitmap(crop, null, new Rect(0, 0, workW, workH), null);

            Ellipse e = getPriorityEllipse(workBitmap);

            long now = System.currentTimeMillis();

            if (overlay != null) {
                if (e != null) {
                    float mx = e.cx * ((float) lensSizePx / (float) workBitmap.getWidth());
                    float my = e.cy * ((float) lensSizePx / (float) workBitmap.getHeight());

                    float conf = 0.90f;

                    float mvx = 0f;
                    float mvy = 0f;

                    if (dotLastMeasT != 0L) {
                        long d = now - dotLastMeasT;
                        if (d < 1L) d = 1L;
                        if (d > 80L) d = 80L;
                        float dt = d / 1000f;

                        mvx = (mx - dotLastMeasX) / dt;
                        mvy = (my - dotLastMeasY) / dt;
                    }

                    dotLastMeasT = now;
                    dotLastMeasX = mx;
                    dotLastMeasY = my;

                    if (dotNeedReset || dotLastT == 0L) {
                        dotKf.reset(new TargetSample(now, mx, my, mvx, mvy, conf));
                        dotNeedReset = false;
                        dotLastT = now;
                    } else {
                        long d = now - dotLastT;
                        if (d < 1L) d = 1L;
                        if (d > 50L) d = 50L;
                        float dt = d / 1000f;

                        dotLastT = now;

                        dotKf.predict(dt);
                        dotKf.update(mx, my, mvx, mvy, conf);
                    }

                    TargetSample st = dotKf.getState(now, conf);
                    float lead = 0.02f;

                    float px = st.x + st.vx * lead;
                    float py = st.y + st.vy * lead;

                    overlay.setTarget(px, py, conf);
                    lastFoundMillis = now;
                } else {
                    if (!dotNeedReset && dotLastT != 0L && lastFoundMillis != 0L && (now - lastFoundMillis) <= 900L) {
                        TargetSample st = dotKf.getState(now, 0.40f);
                        float lead = 0.02f;

                        float px = st.x + st.vx * lead;
                        float py = st.y + st.vy * lead;

                        overlay.setTarget(px, py, 0.40f);
                    } else {
                        dotNeedReset = true;
                        dotLastMeasT = 0L;
                        dotLastT = 0L;
                        overlay.setTarget(-1f, -1f, 0f);
                    }
                }
            }

            applyLensEffect(workBitmap, e);

            if (outBitmap == null || outBitmap.getWidth() != lensSizePx || outBitmap.getHeight() != lensSizePx) {
                outBitmap = Bitmap.createBitmap(lensSizePx, lensSizePx, Bitmap.Config.ARGB_8888);
            }

            Canvas oc = new Canvas(outBitmap);
            oc.drawBitmap(workBitmap, null, new Rect(0, 0, lensSizePx, lensSizePx), null);

            if (overlay != null) overlay.setFrame(outBitmap);

            crop.recycle();
            full.recycle();

        } catch (Throwable ignore) {
        } finally {
            try { if (img != null) img.close(); } catch (Throwable ignore2) {}
        }
    }

    private void loadPriorityTemplateIfNeeded() {
        try {
            android.content.SharedPreferences sp = getSharedPreferences("assistive_prefs", MODE_PRIVATE);
            String p = sp.getString("priority_path", null);
            if (p == null || p.length() == 0) return;
            if (p.equals(priorityPath) && priorityGray != null) return;

            File f = new File(p);
            if (!f.exists() || f.length() < 16) return;

            Bitmap bmp = BitmapFactory.decodeFile(p);
            if (bmp == null) return;

            Mat rgba = new Mat();
            Utils.bitmapToMat(bmp, rgba);

            Mat gray = new Mat();
            Imgproc.cvtColor(rgba, gray, Imgproc.COLOR_RGBA2GRAY);
            rgba.release();

            if (priorityGray != null) priorityGray.release();
            priorityGray = gray;
            priorityPath = p;
        } catch (Throwable ignore) {}
    }

    private Ellipse detectByPriorityTemplate(Bitmap b) {
        Mat tpl = priorityGray;
        if (tpl == null) return null;

        Mat rgba = new Mat();
        Utils.bitmapToMat(b, rgba);

        Mat gray = new Mat();
        Imgproc.cvtColor(rgba, gray, Imgproc.COLOR_RGBA2GRAY);
        rgba.release();

        int tw = tpl.cols();
        int th = tpl.rows();
        if (tw < 8 || th < 8 || gray.cols() < tw || gray.rows() < th) {
            gray.release();
            return null;
        }

        Mat result = new Mat();
        Imgproc.matchTemplate(gray, tpl, result, Imgproc.TM_CCOEFF_NORMED);
        Core.MinMaxLocResult mm = Core.minMaxLoc(result);

        result.release();
        gray.release();

        if (mm == null) return null;
        if (mm.maxVal < 0.72) return null;

        float cx = (float) (mm.maxLoc.x + tw * 0.5);
        float cy = (float) (mm.maxLoc.y + th * 0.5);

        float ax = Math.max(14f, tw * 0.55f);
        float ay = Math.max(14f, th * 0.55f);

        return new Ellipse(cx, cy, ax, ay);
    }

    private Ellipse getPriorityEllipse(Bitmap b) {
        int w = b.getWidth();
        int h = b.getHeight();

        loadPriorityTemplateIfNeeded();
        Ellipse pe = null;
        try { pe = detectByPriorityTemplate(b); } catch (Throwable ignore) {}
        if (pe != null) return pe;

        frameNo++;
        boolean needDetect = (cachedW != w) || cachedH != h || cachedEllipse == null || (frameNo % 2 == 0);
        if (!needDetect) return cachedEllipse;

        Ellipse e = null;

        try { e = detectHeadEllipseOpenCV(b); } catch (Throwable ignore) {}
        if (e == null) {
            try { e = detectEnemyHeadByForegroundOpenCV(b); } catch (Throwable ignore) {}
        }
        if (e == null) {
            try { e = detectSkinBlobEllipse(b); } catch (Throwable ignore) {}
        }

        cachedEllipse = e;
        cachedW = w;
        cachedH = h;
        return e;
    }

    private Ellipse detectEnemyHeadByForegroundOpenCV(Bitmap b) {
        if (bg == null) return null;

        int w = b.getWidth();
        int h = b.getHeight();
        if (w < 80 || h < 80) return null;

        if (matRgba == null) matRgba = new Mat();
        Utils.bitmapToMat(b, matRgba);

        int sw = Math.max(160, w / 2);
        int sh = Math.max(160, h / 2);

        if (matSmall == null || matSmall.cols() != sw || matSmall.rows() != sh) {
            try { if (matSmall != null) matSmall.release(); } catch (Throwable ignore) {}
            try { if (matFg != null) matFg.release(); } catch (Throwable ignore) {}
            matSmall = new Mat(sh, sw, matRgba.type());
            matFg = new Mat(sh, sw, CvType.CV_8UC1);
        }

        Imgproc.resize(matRgba, matSmall, new Size(sw, sh), 0, 0, Imgproc.INTER_AREA);

        bg.apply(matSmall, matFg, 0.05);

        Imgproc.threshold(matFg, matFg, 200, 255, Imgproc.THRESH_BINARY);

        if (matKernel != null) {
            Imgproc.erode(matFg, matFg, matKernel);
            Imgproc.dilate(matFg, matFg, matKernel);
        }

        List<MatOfPoint> contours = new ArrayList<>();
        Mat hierarchy = new Mat();
        Imgproc.findContours(matFg, contours, hierarchy, Imgproc.RETR_EXTERNAL, Imgproc.CHAIN_APPROX_SIMPLE);
        hierarchy.release();

        float cx0 = sw * 0.5f;
        float cy0 = sh * 0.5f;

        org.opencv.core.Rect best = null;
        float bestScore = -1e30f;

        float imgArea = (float) (sw * sh);

        for (int i = 0; i < contours.size(); i++) {
            MatOfPoint c = contours.get(i);
            if (c == null) continue;

            org.opencv.core.Rect r = Imgproc.boundingRect(c);

            int bw = r.width;
            int bh = r.height;
            if (bw < 16 || bh < 24) continue;

            float area = (float) (bw * bh);
            if (area < imgArea * 0.004f) continue;
            if (area > imgArea * 0.80f) continue;

            float aspect = (float) bh / (float) Math.max(1, bw);
            if (aspect < 0.85f) continue;
            if (aspect > 5.5f) continue;

            float rcx = r.x + bw * 0.5f;
            float rcy = r.y + bh * 0.5f;

            float dx = rcx - cx0;
            float dy = rcy - cy0;
            float dist2 = dx * dx + dy * dy;

            float upperBias = (rcy < sh * 0.78f) ? 1.0f : 0.85f;

            float score = area * upperBias - dist2 * 0.30f;
            if (score > bestScore) {
                bestScore = score;
                best = r;
            }
        }

        for (int i = 0; i < contours.size(); i++) {
            try { contours.get(i).release(); } catch (Throwable ignore) {}
        }

        if (best == null) return null;

        float bx = best.x;
        float by = best.y;
        float bw = best.width;
        float bh = best.height;

        float headX = bx + bw * 0.5f;
        float headY = by + bh * 0.18f;

        float scaleX = (float) w / (float) sw;
        float scaleY = (float) h / (float) sh;

        float cx = headX * scaleX;
        float cy = headY * scaleY;

        float ax = Math.max(14f, (bw * scaleX) * 0.35f);
        float ay = Math.max(14f, (bh * scaleY) * 0.30f);

        return new Ellipse(cx, cy, ax, ay);
    }

    private Ellipse detectHeadEllipseOpenCV(Bitmap b) {
        CascadeClassifier cc = faceCascade;
        if (cc == null) return null;

        Mat rgba = new Mat();
        Utils.bitmapToMat(b, rgba);

        Mat gray = new Mat();
        Imgproc.cvtColor(rgba, gray, Imgproc.COLOR_RGBA2GRAY);
        Imgproc.equalizeHist(gray, gray);

        MatOfRect faces = new MatOfRect();
        cc.detectMultiScale(gray, faces, 1.1, 3, 0, new Size(40, 40), new Size());

        org.opencv.core.Rect[] arr = faces.toArray();

        rgba.release();
        gray.release();
        faces.release();

        if (arr == null || arr.length == 0) return null;

        org.opencv.core.Rect best = arr[0];
        for (int i = 1; i < arr.length; i++) if (arr[i].area() > best.area()) best = arr[i];

        float cx = (float) (best.x + best.width * 0.5);
        float cy = (float) (best.y + best.height * 0.55);
        float ax = (float) (best.width * 0.65);
        float ay = (float) (best.height * 0.85);

        float maxAx = b.getWidth() * 0.48f;
        float maxAy = b.getHeight() * 0.48f;
        if (ax > maxAx) ax = maxAx;
        if (ay > maxAy) ay = maxAy;

        return new Ellipse(cx, cy, Math.max(14f, ax), Math.max(14f, ay));
    }

    private Ellipse detectSkinBlobEllipse(Bitmap b) {
        int w = b.getWidth();
        int h = b.getHeight();
        int n = w * h;

        if (workPx == null || workPx.length != n) workPx = new int[n];
        if (skinMask == null || skinMask.length != n) skinMask = new byte[n];
        if (queue == null || queue.length != n) queue = new int[n];

        b.getPixels(workPx, 0, w, 0, 0, w, h);

        for (int i = 0; i < n; i++) {
            int c = workPx[i];
            int r = (c >>> 16) & 255;
            int g = (c >>> 8) & 255;
            int bl = c & 255;
            skinMask[i] = (byte) (isSkinYCbCr(r, g, bl) ? 1 : 0);
        }

        int cx = w / 2;
        int cy = h / 2;
        int bestScore = 0;
        int bestMinX = 0, bestMinY = 0, bestMaxX = 0, bestMaxY = 0;
        int bestCx = cx, bestCy = cy;

        for (int y = 0; y < h; y++) {
            int row = y * w;
            for (int x = 0; x < w; x++) {
                int idx = row + x;
                if (skinMask[idx] != 1) continue;

                int qh = 0;
                int qt = 0;
                queue[qt++] = idx;
                skinMask[idx] = 2;

                int area = 0;
                int minX = x, maxX = x, minY = y, maxY = y;
                long sumX = 0;
                long sumY = 0;

                while (qh < qt) {
                    int p = queue[qh++];
                    int px = p % w;
                    int py = p / w;

                    area++;
                    sumX += px;
                    sumY += py;

                    if (px < minX) minX = px;
                    if (px > maxX) maxX = px;
                    if (py < minY) minY = py;
                    if (py > maxY) maxY = py;

                    int up = p - w;
                    int dn = p + w;
                    int lt = p - 1;
                    int rt = p + 1;

                    if (py > 0 && skinMask[up] == 1) { skinMask[up] = 2; queue[qt++] = up; }
                    if (py + 1 < h && skinMask[dn] == 1) { skinMask[dn] = 2; queue[qt++] = dn; }
                    if (px > 0 && skinMask[lt] == 1) { skinMask[lt] = 2; queue[qt++] = lt; }
                    if (px + 1 < w && skinMask[rt] == 1) { skinMask[rt] = 2; queue[qt++] = rt; }
                }

                if (area < 35) continue;

                int blobCx = (int) (sumX / area);
                int blobCy = (int) (sumY / area);
                int dx = blobCx - cx;
                int dy = blobCy - cy;
                int dist2 = dx * dx + dy * dy;

                int score = area - (dist2 / 3);
                if (score > bestScore) {
                    bestScore = score;
                    bestMinX = minX;
                    bestMaxX = maxX;
                    bestMinY = minY;
                    bestMaxY = maxY;
                    bestCx = blobCx;
                    bestCy = blobCy;
                }
            }
        }

        if (bestScore <= 0) return null;

        float ax = Math.max(14f, (bestMaxX - bestMinX + 1) * 0.62f);
        float ay = Math.max(14f, (bestMaxY - bestMinY + 1) * 0.78f);

        float maxAx = w * 0.48f;
        float maxAy = h * 0.48f;
        if (ax > maxAx) ax = maxAx;
        if (ay > maxAy) ay = maxAy;

        return new Ellipse(bestCx, bestCy, ax, ay);
    }

    private void applyLensEffect(Bitmap b, Ellipse target) {
        int w = b.getWidth();
        int h = b.getHeight();
        int n = w * h;

        if (workPx == null || workPx.length != n) workPx = new int[n];
        if (blurPx == null || blurPx.length != n) blurPx = new int[n];

        b.getPixels(workPx, 0, w, 0, 0, w, h);

        for (int y = 0; y < h; y++) {
            int yw = y * w;
            int upRow = (y > 0) ? (y - 1) * w : yw;
            int dnRow = (y + 1 < h) ? (y + 1) * w : yw;

            for (int x = 0; x < w; x++) {
                int i = yw + x;

                int iUp = upRow + x;
                int iDn = dnRow + x;
                int iLt = yw + (x > 0 ? x - 1 : x);
                int iRt = yw + (x + 1 < w ? x + 1 : x);

                int c = workPx[i];
                int up = workPx[iUp];
                int dn = workPx[iDn];
                int lt = workPx[iLt];
                int rt = workPx[iRt];

                int a = (c >>> 24) & 255;

                int r = ((c >>> 16) & 255) + ((up >>> 16) & 255) + ((dn >>> 16) & 255) + ((lt >>> 16) & 255) + ((rt >>> 16) & 255);
                int g = ((c >>> 8) & 255) + ((up >>> 8) & 255) + ((dn >>> 8) & 255) + ((lt >>> 8) & 255) + ((rt >>> 8) & 255);
                int bl = (c & 255) + (up & 255) + (dn & 255) + (lt & 255) + (rt & 255);

                r /= 5;
                g /= 5;
                bl /= 5;

                blurPx[i] = (a << 24) | (r << 16) | (g << 8) | bl;
            }
        }

        float ecx = 0f, ecy = 0f, invAx2 = 0f, invAy2 = 0f;
        boolean hasTarget = target != null;
        if (hasTarget) {
            ecx = target.cx;
            ecy = target.cy;
            invAx2 = 1.0f / (target.ax * target.ax);
            invAy2 = 1.0f / (target.ay * target.ay);
        }

        for (int y = 0; y < h; y++) {
            int yw = y * w;

            float dy2 = 0f;
            if (hasTarget) {
                float dy = y - ecy;
                dy2 = dy * dy * invAy2;
            }

            for (int x = 0; x < w; x++) {
                int i = yw + x;

                int c = workPx[i];
                int a = (c >>> 24) & 255;
                int r = (c >>> 16) & 255;
                int g = (c >>> 8) & 255;
                int bl = c & 255;

                boolean inTarget = false;
                if (hasTarget) {
                    float dx = x - ecx;
                    float k = (dx * dx) * invAx2 + dy2;
                    if (k <= 1.0f) inTarget = true;
                }

                if (inTarget) {
                    int up = (y > 0) ? workPx[i - w] : c;
                    int dn = (y + 1 < h) ? workPx[i + w] : c;
                    int lt = (x > 0) ? workPx[i - 1] : c;
                    int rt = (x + 1 < w) ? workPx[i + 1] : c;

                    int ur = (up >>> 16) & 255, ug = (up >>> 8) & 255, ub = up & 255;
                    int dr = (dn >>> 16) & 255, dg = (dn >>> 8) & 255, db = dn & 255;
                    int lr = (lt >>> 16) & 255, lg = (lt >>> 8) & 255, lb = lt & 255;
                    int rr = (rt >>> 16) & 255, rg = (rt >>> 8) & 255, rb = rt & 255;

                    int nr = (5 * r) - ur - dr - lr - rr;
                    int ng = (5 * g) - ug - dg - lg - rg;
                    int nb = (5 * bl) - ub - db - lb - rb;

                    nr = clamp8(nr);
                    ng = clamp8(ng);
                    nb = clamp8(nb);

                    int avg = (nr + ng + nb) / 3;
                    float sat = 1.60f;
                    nr = clamp8((int) (avg + (nr - avg) * sat));
                    ng = clamp8((int) (avg + (ng - avg) * sat));
                    nb = clamp8((int) (avg + (nb - avg) * sat));

                    float contrast = 1.20f;
                    nr = clamp8((int) ((nr - 128) * contrast + 128 + 10));
                    ng = clamp8((int) ((ng - 128) * contrast + 128 + 10));
                    nb = clamp8((int) ((nb - 128) * contrast + 128 + 6));

                    workPx[i] = (a << 24) | (nr << 16) | (ng << 8) | nb;
                } else {
                    int bc = blurPx[i];
                    int br = (bc >>> 16) & 255;
                    int bg = (bc >>> 8) & 255;
                    int bb = bc & 255;

                    int nr = (br * 9 + r) / 10;
                    int ng = (bg * 9 + g) / 10;
                    int nb = (bb * 9 + bl) / 10;

                    int grey = (nr + ng + nb) / 3;
                    float keep = 0.06f;
                    nr = clamp8((int) (grey + (nr - grey) * keep));
                    ng = clamp8((int) (grey + (ng - grey) * keep));
                    nb = clamp8((int) (grey + (nb - grey) * keep));

                    nr = (nr * 78) / 100;
                    ng = (ng * 78) / 100;
                    nb = (nb * 78) / 100;

                    workPx[i] = (a << 24) | (nr << 16) | (ng << 8) | nb;
                }
            }
        }

        b.setPixels(workPx, 0, w, 0, 0, w, h);
    }

    private static boolean isSkinYCbCr(int r, int g, int b) {
        int cb = ((-43 * r - 85 * g + 128 * b) >> 8) + 128;
        int cr = ((128 * r - 107 * g - 21 * b) >> 8) + 128;
        if (r < 35 || g < 18 || b < 8) return false;
        return cb >= 60 && cb <= 145 && cr >= 125 && cr <= 185;
    }

    private static int clamp8(int v) {
        if (v < 0) return 0;
        if (v > 255) return 255;
        return v;
    }

    private CascadeClassifier loadCascadeFromRaw(int rawId, String fileName) {
        try {
            File dir = new File(getFilesDir(), "cascades");
            if (!dir.exists()) dir.mkdirs();
            File f = new File(dir, fileName);

            if (!f.exists() || f.length() < 1024) {
                InputStream is = getResources().openRawResource(rawId);
                FileOutputStream os = new FileOutputStream(f);
                byte[] buf = new byte[4096];
                int r;
                while ((r = is.read(buf)) > 0) os.write(buf, 0, r);
                os.close();
                is.close();
            }

            CascadeClassifier c = new CascadeClassifier(f.getAbsolutePath());
            if (c.empty()) return null;
            return c;
        } catch (Throwable t) {
            return null;
        }
    }

    private void shutdownProjection() {
        try { if (reader != null) reader.setOnImageAvailableListener(null, null); } catch (Throwable ignore) {}
        try { if (vdisplay != null) vdisplay.release(); } catch (Throwable ignore) {}
        try { if (projection != null) projection.stop(); } catch (Throwable ignore) {}
        reader = null;
        vdisplay = null;
        projection = null;
    }

    @Override
    public void onDestroy() {
        shutdownProjection();
        removeOverlay();

        try { if (matRgba != null) matRgba.release(); } catch (Throwable ignore) {}
        try { if (matSmall != null) matSmall.release(); } catch (Throwable ignore) {}
        try { if (matFg != null) matFg.release(); } catch (Throwable ignore) {}
        try { if (matKernel != null) matKernel.release(); } catch (Throwable ignore) {}
        matRgba = null;
        matSmall = null;
        matFg = null;
        matKernel = null;
        bg = null;

        try { if (priorityGray != null) priorityGray.release(); } catch (Throwable ignore) {}
        priorityGray = null;

        try { if (workerThread != null) workerThread.quitSafely(); } catch (Throwable ignore) {}
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private static final class Ellipse {
        final float cx;
        final float cy;
        final float ax;
        final float ay;

        Ellipse(float cx, float cy, float ax, float ay) {
            this.cx = cx;
            this.cy = cy;
            this.ax = ax;
            this.ay = ay;
        }
    }
}

