package com.assistive.filter;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.WindowManager;

import org.opencv.android.OpenCVLoader;
import org.opencv.android.Utils;
import org.opencv.core.Core;
import org.opencv.core.CvType;
import org.opencv.core.Mat;
import org.opencv.core.MatOfPoint;
import org.opencv.core.MatOfRect;
import org.opencv.core.Size;
import org.opencv.imgproc.Imgproc;
import org.opencv.objdetect.CascadeClassifier;
import org.opencv.video.BackgroundSubtractorMOG2;
import org.opencv.video.Video;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

public final class enhancelensservice extends Service {

    public static final String ACTION_START_EDIT = "com.assistive.filter.LENS_START_EDIT";
    public static final String ACTION_START_LOCKED = "com.assistive.filter.LENS_START_LOCKED";
    public static final String ACTION_STOP = "com.assistive.filter.LENS_STOP";

    public static final String EXTRA_RESULT_CODE = "result_code";
    public static final String EXTRA_RESULT_DATA = "result_data";

    private static final int NOTIF_ID = 5003;
    private static final String CHANNEL_ID = "assistive_enhance_lens";

    // --- TỐI ƯU CHỐNG LAG ---
    private static final int WORK_SIZE = 120;            // Xử lý ảnh ở kích thước cố định 120x120
    private static final int PROCESS_EVERY_N_FRAMES = 3; // Chỉ xử lý 1 trong mỗi 3 khung hình
    // -------------------------

    private WindowManager wm;
    private WindowManager.LayoutParams params;
    private enhancelensview overlay;

    private int touchSlop;
    private int startX, startY;
    private float downRawX, downRawY;

    private int lensSizePx;

    private ScaleGestureDetector scaleDetector;
    private float scale = 1.0f;
    private int baseLensSizePx;
    private int screenW;
    private int screenH;

    private MediaProjection projection;
    private VirtualDisplay vdisplay;
    private ImageReader reader;

    private HandlerThread workerThread;
    private Handler worker;

    private Bitmap outBitmap;
    private Bitmap workBitmap;

    private int[] workPx;
    private int[] blurPx;

    private byte[] skinMask;
    private int[] queue;

    private final AtomicBoolean processing = new AtomicBoolean(false);

    private int frameNo;
    private int cachedW;
    private int cachedH;
    private Ellipse cachedEllipse;

    private CascadeClassifier faceCascade;

    private BackgroundSubtractorMOG2 bg;
    private Mat matRgba;
    private Mat matSmall;
    private Mat matFg;
    private Mat matKernel;

    private int processCounter = 0;

    // *** PHẦN 3: PriorityTemplate mới ***
    private static final class PriorityTemplate {
        final String name;
        final Bitmap bitmap;      // ảnh gốc để xử lý màu
        final Mat gray;           // giữ lại nếu cần
        final float weight;

        PriorityTemplate(String name, Bitmap bitmap, Mat gray, float weight) {
            this.name = name;
            this.bitmap = bitmap;
            this.gray = gray;
            this.weight = weight;
        }
    }

    private final ArrayList<PriorityTemplate> priorityTemplates = new ArrayList<>();
    private long priorityLastLoad;

    private final Kalman2D dotKf = new Kalman2D();

    private long dotLastT;
    private long dotLastMeasT;
    private float dotLastMeasX;
    private float dotLastMeasY;

    private boolean dotNeedReset = true;

    private long lastFoundMillis;

    private static volatile boolean sHasTarget;
    private static volatile float sLastTargetScreenX = -1f;
    private static volatile float sLastTargetScreenY = -1f;
    private static volatile float sLastTargetConfidence;

    public static boolean hasLiveTarget() {
        return sHasTarget;
    }

    public static float getLastTargetScreenX() {
        return sLastTargetScreenX;
    }

    public static float getLastTargetScreenY() {
        return sLastTargetScreenY;
    }

    public static float getLastTargetConfidence() {
        return sLastTargetConfidence;
    }

    @Override
    public void onCreate() {
        super.onCreate();

        try {
            if (OpenCVLoader.initDebug()) {
                faceCascade = loadCascadeFromRaw(
                    R.raw.haarcascade_frontalface_alt2,
                    "haarcascade_frontalface_alt2.xml"
                );
                bg = Video.createBackgroundSubtractorMOG2(60, 16, false);
                matKernel = Imgproc.getStructuringElement(Imgproc.MORPH_ELLIPSE, new Size(5, 5));
                loadPriorityTemplatesIfNeeded();
            }
        } catch (Throwable ignore) {
        }

        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        touchSlop = ViewConfiguration.get(this).getScaledTouchSlop();

        float d = getResources().getDisplayMetrics().density;
        lensSizePx = (int) (220f * d);
        if (lensSizePx < 160) lensSizePx = 160;

        baseLensSizePx = lensSizePx;
        updateScreenSize();

        overlay = new enhancelensview(this);

        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
            ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            : WindowManager.LayoutParams.TYPE_PHONE;

        params = new WindowManager.LayoutParams(
            lensSizePx,
            lensSizePx,
            type,
            flagsInteractive(),
            PixelFormat.TRANSLUCENT
        );

        params.gravity = Gravity.TOP | Gravity.START;
        DisplayMetrics dm = getResources().getDisplayMetrics();
        params.x = (dm.widthPixels / 2) - (lensSizePx / 2);
        params.y = (dm.heightPixels / 2) - (lensSizePx / 2);

        scaleDetector = new ScaleGestureDetector(this, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
				@Override
				public boolean onScale(ScaleGestureDetector detector) {
					scale *= detector.getScaleFactor();
					if (scale < 0.25f) scale = 0.25f;
					if (scale > 3.0f) scale = 3.0f;

					applyLensSize((int) (baseLensSizePx * scale));
					updateLayoutSafe();
					return true;
				}
			});

        overlay.setOnTouchListener(new View.OnTouchListener() {
				@Override
				public boolean onTouch(View v, MotionEvent e) {
					try { scaleDetector.onTouchEvent(e); } catch (Throwable ignore) {}
					if (scaleDetector != null && scaleDetector.isInProgress()) return true;

					switch (e.getActionMasked()) {
						case MotionEvent.ACTION_DOWN:
							downRawX = e.getRawX();
							downRawY = e.getRawY();
							startX = params.x;
							startY = params.y;
							return true;

						case MotionEvent.ACTION_MOVE: {
								float rawDx = e.getRawX() - downRawX;
								float rawDy = e.getRawY() - downRawY;

								params.x = startX + Math.round(rawDx);
								params.y = startY + Math.round(rawDy);

								clampToScreen();
								updateLayoutSafe();
								return true;
							}

						case MotionEvent.ACTION_UP:
						case MotionEvent.ACTION_CANCEL:
							return true;
					}

					return true;
				}
			});

        workerThread = new HandlerThread("lens_worker");
        workerThread.start();
        worker = new Handler(workerThread.getLooper());
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent != null ? intent.getAction() : null;

        if (ACTION_STOP.equals(action)) {
            shutdownProjection();
            removeOverlay();
            stopForeground(true);
            stopSelf();
            return START_NOT_STICKY;
        }

        startForegroundSafe();
        addOverlayIfNeeded();
        clampToScreen();
        updateLayoutSafe();

        if (projection == null) {
            int resultCode = intent != null ? intent.getIntExtra(EXTRA_RESULT_CODE, 0) : 0;
            Intent data = intent != null ? intent.getParcelableExtra(EXTRA_RESULT_DATA) : null;
            if (resultCode != 0 && data != null) {
                setupProjection(resultCode, data);
            }
        }

        return START_STICKY;
    }

    private int flagsInteractive() {
        return WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
            | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL;
    }

    private void startForegroundSafe() {
        try {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (nm == null) throw new RuntimeException("NotificationManager=null");

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                NotificationChannel ch = new NotificationChannel(
                    CHANNEL_ID, "Enhance Lens", NotificationManager.IMPORTANCE_MIN);
                ch.setSound(null, null);
                nm.createNotificationChannel(ch);
            }

            Notification.Builder b = (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);

            Notification n = b.setOngoing(true)
                .setSmallIcon(android.R.drawable.ic_menu_camera)
                .setContentTitle("Assistive Filter")
                .setContentText("Lens running")
                .build();

            startForeground(NOTIF_ID, n);
        } catch (Throwable t) {
            stopSelf();
        }
    }

    private void addOverlayIfNeeded() {
        if (overlay == null || overlay.getParent() != null) return;
        try { wm.addView(overlay, params); } catch (Throwable ignore) {}
    }

    private void removeOverlay() {
        try {
            if (wm != null && overlay != null && overlay.getParent() != null) wm.removeView(overlay);
        } catch (Throwable ignore) {}
    }

    private void updateLayoutSafe() {
        try {
            if (wm != null && overlay != null && overlay.getParent() != null) wm.updateViewLayout(overlay, params);
        } catch (Throwable ignore) {}
    }

    private void updateScreenSize() {
        DisplayMetrics dm = getResources().getDisplayMetrics();
        screenW = dm.widthPixels;
        screenH = dm.heightPixels;
        if (screenW < 1) screenW = 1080;
        if (screenH < 1) screenH = 1920;
    }

    private void clampToScreen() {
        updateScreenSize();

        int maxX = Math.max(0, screenW - params.width);
        int maxY = Math.max(0, screenH - params.height);

        if (params.x < 0) params.x = 0;
        if (params.y < 0) params.y = 0;
        if (params.x > maxX) params.x = maxX;
        if (params.y > maxY) params.y = maxY;
    }

    private void applyLensSize(int newSizePx) {
        updateScreenSize();

        int old = lensSizePx;
        int cx = params.x + (old / 2);
        int cy = params.y + (old / 2);

        int sz = newSizePx;
        if (sz < 120) sz = 120;
        if (sz > screenW) sz = screenW;
        if (sz > screenH) sz = screenH;

        lensSizePx = sz;
        params.width = sz;
        params.height = sz;

        params.x = cx - (sz / 2);
        params.y = cy - (sz / 2);

        clampToScreen();

        dotNeedReset = true;
        dotLastMeasT = 0L;
        dotLastT = 0L;
        lastFoundMillis = 0L;

        cachedEllipse = null;
        cachedW = 0;
        cachedH = 0;
        frameNo = 0;

        try {
            if (bg != null) bg.clear();
        } catch (Throwable ignore) {}

        try { if (matRgba != null) matRgba.release(); } catch (Throwable ignore) {}
        try { if (matSmall != null) matSmall.release(); } catch (Throwable ignore) {}
        try { if (matFg != null) matFg.release(); } catch (Throwable ignore) {}
        matRgba = null;
        matSmall = null;
        matFg = null;
    }

    private void setupProjection(int resultCode, Intent data) {
        try {
            MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
            if (mpm == null) return;

            projection = mpm.getMediaProjection(resultCode, data);
            if (projection == null) return;

            DisplayMetrics dm = getResources().getDisplayMetrics();
            int w = dm.widthPixels;
            int h = dm.heightPixels;
            int dpi = dm.densityDpi;

            reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2);

            vdisplay = projection.createVirtualDisplay(
                "enhance_lens",
                w,
                h,
                dpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                reader.getSurface(),
                null,
                worker
            );

            reader.setOnImageAvailableListener(new ImageReader.OnImageAvailableListener() {
					@Override
					public void onImageAvailable(ImageReader ir) {
						if (processing.getAndSet(true)) return;
						worker.post(new Runnable() {
								@Override
								public void run() {
									try {
										processFrame();
									} finally {
										processing.set(false);
									}
								}
							});
					}
				}, worker);

        } catch (Throwable ignore) {
        }
    }

    private void processFrame() {
        if (reader == null) return;

        Image img = null;
        try {
            img = reader.acquireLatestImage();
            if (img == null) return;

            // --- TỐI ƯU: Chỉ xử lý mỗi PROCESS_EVERY_N_FRAMES khung hình ---
            processCounter++;
            if (processCounter % PROCESS_EVERY_N_FRAMES != 0) {
                return;
            }
            // -------------------------------------------------------------

            Image.Plane[] planes = img.getPlanes();
            if (planes == null || planes.length < 1) return;

            ByteBuffer buf = planes[0].getBuffer();
            int pixelStride = planes[0].getPixelStride();
            int rowStride = planes[0].getRowStride();

            DisplayMetrics dm = getResources().getDisplayMetrics();
            int sw = dm.widthPixels;
            int sh = dm.heightPixels;

            int rowPadding = rowStride - pixelStride * sw;
            int bmpW = sw + rowPadding / pixelStride;

            Bitmap full = Bitmap.createBitmap(bmpW, sh, Bitmap.Config.ARGB_8888);
            full.copyPixelsFromBuffer(buf);

            int cx = params.x + (lensSizePx / 2);
            int cy = params.y + (lensSizePx / 2);

            int half = lensSizePx / 2;
            int left = cx - half;
            int top = cy - half;

            if (left < 0) left = 0;
            if (top < 0) top = 0;
            if (left + lensSizePx > sw) left = Math.max(0, sw - lensSizePx);
            if (top + lensSizePx > sh) top = Math.max(0, sh - lensSizePx);

            Bitmap crop = Bitmap.createBitmap(full, left, top, lensSizePx, lensSizePx);

            int workW = WORK_SIZE;
            int workH = WORK_SIZE;

            if (workBitmap == null || workBitmap.getWidth() != workW || workBitmap.getHeight() != workH) {
                workBitmap = Bitmap.createBitmap(workW, workH, Bitmap.Config.ARGB_8888);
                cachedEllipse = null;
                cachedW = 0;
                cachedH = 0;

                dotNeedReset = true;
                dotLastMeasT = 0L;
                dotLastT = 0L;
                lastFoundMillis = 0L;

                try {
                    if (bg != null) bg.clear();
                } catch (Throwable ignore) {}

                try { if (matRgba != null) matRgba.release(); } catch (Throwable ignore) {}
                try { if (matSmall != null) matSmall.release(); } catch (Throwable ignore) {}
                try { if (matFg != null) matFg.release(); } catch (Throwable ignore) {}
                matRgba = null;
                matSmall = null;
                matFg = null;
            }

            Canvas wc = new Canvas(workBitmap);
            wc.drawBitmap(crop, null, new Rect(0, 0, workW, workH), null);

            // --- Gọi priority ellipse (đã được nâng cấp) ---
            Ellipse e = getPriorityEllipse(workBitmap);

            long now = System.currentTimeMillis();

            if (overlay != null) {
                if (e != null) {
                    float mx = e.cx * ((float) lensSizePx / (float) workBitmap.getWidth());
                    float my = e.cy * ((float) lensSizePx / (float) workBitmap.getHeight());

                    float conf = 0.90f;

                    float mvx = 0f;
                    float mvy = 0f;

                    if (dotLastMeasT != 0L) {
                        long d = now - dotLastMeasT;
                        if (d < 1L) d = 1L;
                        if (d > 80L) d = 80L;
                        float dt = d / 1000f;

                        mvx = (mx - dotLastMeasX) / dt;
                        mvy = (my - dotLastMeasY) / dt;
                    }

                    dotLastMeasT = now;
                    dotLastMeasX = mx;
                    dotLastMeasY = my;

                    if (dotNeedReset || dotLastT == 0L) {
                        dotKf.reset(new TargetSample(now, mx, my, mvx, mvy, conf));
                        dotNeedReset = false;
                        dotLastT = now;
                    } else {
                        long d = now - dotLastT;
                        if (d < 1L) d = 1L;
                        if (d > 50L) d = 50L;
                        float dt = d / 1000f;

                        dotLastT = now;

                        dotKf.predict(dt);
                        dotKf.update(mx, my, mvx, mvy, conf);
                    }

                    TargetSample st = dotKf.getState(now, conf);
                    float lead = 0.02f;

                    float px = st.x + st.vx * lead;
                    float py = st.y + st.vy * lead;

                    overlay.setTarget(px, py, conf);
                    lastFoundMillis = now;

                    sHasTarget = true;
                    sLastTargetScreenX = params.x + px;
                    sLastTargetScreenY = params.y + py;
                    sLastTargetConfidence = conf;
                } else {
                    if (!dotNeedReset && dotLastT != 0L && lastFoundMillis != 0L && (now - lastFoundMillis) <= 900L) {
                        TargetSample st = dotKf.getState(now, 0.40f);
                        float lead = 0.02f;

                        float px = st.x + st.vx * lead;
                        float py = st.y + st.vy * lead;

                        overlay.setTarget(px, py, 0.40f);

                        sHasTarget = true;
                        sLastTargetScreenX = params.x + px;
                        sLastTargetScreenY = params.y + py;
                        sLastTargetConfidence = 0.40f;
                    } else {
                        dotNeedReset = true;
                        dotLastMeasT = 0L;
                        dotLastT = 0L;

                        sHasTarget = false;
                        sLastTargetScreenX = -1f;
                        sLastTargetScreenY = -1f;
                        sLastTargetConfidence = 0f;

                        overlay.setTarget(-1f, -1f, 0f);
                    }
                }
            }

            applyLensEffect(workBitmap, e);

            if (outBitmap == null || outBitmap.getWidth() != lensSizePx || outBitmap.getHeight() != lensSizePx) {
                outBitmap = Bitmap.createBitmap(lensSizePx, lensSizePx, Bitmap.Config.ARGB_8888);
            }

            Canvas oc = new Canvas(outBitmap);
            oc.drawBitmap(workBitmap, null, new Rect(0, 0, lensSizePx, lensSizePx), null);

            if (overlay != null) overlay.setFrame(outBitmap);

            crop.recycle();
            full.recycle();

        } catch (Throwable ignore) {
        } finally {
            try { if (img != null) img.close(); } catch (Throwable ignore2) {}
        }
    }

    // --- Load template: bây giờ lưu cả bitmap gốc ---
    private void loadPriorityTemplatesIfNeeded() {
        long now = System.currentTimeMillis();
        if (now - priorityLastLoad < 1200L) return;
        priorityLastLoad = now;

        android.content.SharedPreferences sp = getSharedPreferences("assistive_prefs", MODE_PRIVATE);
        java.util.Set<String> set = sp.getStringSet("priority_paths", null);

        for (int i = 0; i < priorityTemplates.size(); i++) {
            try { priorityTemplates.get(i).gray.release(); } catch (Throwable ignore) {}
            // không cần recycle bitmap vì có thể còn dùng
        }
        priorityTemplates.clear();

        if (set == null || set.isEmpty()) return;

        for (String p : set) {
            if (p == null || p.length() == 0) continue;

            File f = new File(p);
            if (!f.exists() || f.length() < 16) continue;

            Bitmap bmp = null;
            try { bmp = BitmapFactory.decodeFile(p); } catch (Throwable ignore) {}
            if (bmp == null) continue;

            Mat rgba = new Mat();
            Utils.bitmapToMat(bmp, rgba);
            Mat gray = new Mat();
            Imgproc.cvtColor(rgba, gray, Imgproc.COLOR_RGBA2GRAY);
            rgba.release();

            float w = 1f;
            try { w = sp.getFloat("priority_w_" + f.getName(), 1f); } catch (Throwable ignore) {}
            if (w <= 0f) w = 1f;
            if (w > 10f) w = 10f;

            priorityTemplates.add(new PriorityTemplate(f.getName(), bmp, gray, w));
        }
    }

    // *** PHẦN 3: detectByPriorityTemplates nâng cấp (HSV + multi‑scale) ***
    private Ellipse detectByPriorityTemplates(Bitmap b) {
        if (priorityTemplates.isEmpty()) return null;

        // Chuyển ảnh khung hình sang HSV và lấy kênh V
        Mat rgba = new Mat();
        Utils.bitmapToMat(b, rgba);
        Mat hsv = new Mat();
        Imgproc.cvtColor(rgba, hsv, Imgproc.COLOR_RGBA2HSV);
        Mat frameV = new Mat();
        Core.extractChannel(hsv, frameV, 2); // kênh V
        rgba.release();
        hsv.release();

        Ellipse bestEllipse = null;
        double bestWeighted = -1e9;

        float[] scales = {0.8f, 1.0f, 1.2f};

        for (PriorityTemplate t : priorityTemplates) {
            // Chuyển template sang HSV và lấy kênh V
            Mat tplRgba = new Mat();
            Utils.bitmapToMat(t.bitmap, tplRgba);
            Mat tplHsv = new Mat();
            Imgproc.cvtColor(tplRgba, tplHsv, Imgproc.COLOR_RGBA2HSV);
            Mat tplV = new Mat();
            Core.extractChannel(tplHsv, tplV, 2);
            tplRgba.release();
            tplHsv.release();

            for (float scale : scales) {
                int newW = Math.round(tplV.cols() * scale);
                int newH = Math.round(tplV.rows() * scale);
                if (newW < 8 || newH < 8 || frameV.cols() < newW || frameV.rows() < newH) continue;

                Mat scaledTpl = new Mat();
                Imgproc.resize(tplV, scaledTpl, new Size(newW, newH));

                Mat result = new Mat();
                Imgproc.matchTemplate(frameV, scaledTpl, result, Imgproc.TM_CCOEFF_NORMED);
                Core.MinMaxLocResult mm = Core.minMaxLoc(result);
                result.release();
                scaledTpl.release();

                if (mm == null) continue;
                double raw = mm.maxVal;
                if (raw < 0.78) continue; // ngưỡng cao hơn

                double weighted = raw * (double) t.weight;
                if (weighted > bestWeighted) {
                    bestWeighted = weighted;
                    float cx = (float) (mm.maxLoc.x + newW * 0.5);
                    float cy = (float) (mm.maxLoc.y + newH * 0.5);
                    float ax = Math.max(14f, newW * 0.55f);
                    float ay = Math.max(14f, newH * 0.55f);
                    bestEllipse = new Ellipse(cx, cy, ax, ay);
                }
            }
            tplV.release();
        }

        frameV.release();
        return bestEllipse;
    }

    // Các hàm detectHeadEllipseOpenCV, detectEnemyHeadByForegroundOpenCV, detectSkinBlobEllipse, applyLensEffect, isSkinYCbCr, ... giữ nguyên
    // (Vì code dài, mình giữ lại toàn bộ phần còn lại như file gốc của bạn, không thay đổi)

    // ... (giữ nguyên toàn bộ các hàm còn lại)
}
