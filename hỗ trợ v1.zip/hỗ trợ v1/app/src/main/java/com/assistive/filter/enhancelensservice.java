package com.assistive.filter;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.WindowManager;

import java.nio.ByteBuffer;
import java.util.concurrent.atomic.AtomicBoolean;

public final class enhancelensservice extends Service {

    public static final String ACTION_START_EDIT = "com.assistive.filter.LENS_START_EDIT";
    public static final String ACTION_START_LOCKED = "com.assistive.filter.LENS_START_LOCKED";
    public static final String ACTION_STOP = "com.assistive.filter.LENS_STOP";

    public static final String EXTRA_RESULT_CODE = "result_code";
    public static final String EXTRA_RESULT_DATA = "result_data";

    private static final int NOTIF_ID = 5003;
    private static final String CHANNEL_ID = "assistive_enhance_lens";

    private WindowManager wm;
    private WindowManager.LayoutParams params;
    private enhancelensview overlay;

    private int touchSlop;
    private int startX, startY;
    private float downRawX, downRawY;

    private int lensSizePx;

    private ScaleGestureDetector scaleDetector;
    private float scale = 1.0f;
    private int baseLensSizePx;
    private int screenW;
    private int screenH;

    private MediaProjection projection;
    private VirtualDisplay vdisplay;
    private ImageReader reader;

    private HandlerThread workerThread;
    private Handler worker;

    private Bitmap outBitmap;
    private final AtomicBoolean processing = new AtomicBoolean(false);

    @Override
    public void onCreate() {
        super.onCreate();

        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        touchSlop = ViewConfiguration.get(this).getScaledTouchSlop();

        float d = getResources().getDisplayMetrics().density;
        lensSizePx = (int) (220f * d);
        if (lensSizePx < 160) lensSizePx = 160;

        baseLensSizePx = lensSizePx;
        updateScreenSize();

        overlay = new enhancelensview(this);

        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
			? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
			: WindowManager.LayoutParams.TYPE_PHONE;

        params = new WindowManager.LayoutParams(
			lensSizePx,
			lensSizePx,
			type,
			flagsInteractive(),
			PixelFormat.TRANSLUCENT
        );

        params.gravity = Gravity.TOP | Gravity.START;
        DisplayMetrics dm = getResources().getDisplayMetrics();
        params.x = (dm.widthPixels / 2) - (lensSizePx / 2);
        params.y = (dm.heightPixels / 2) - (lensSizePx / 2);

        scaleDetector = new ScaleGestureDetector(this, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
				@Override
				public boolean onScale(ScaleGestureDetector detector) {
					scale *= detector.getScaleFactor();
					if (scale < 0.1f) scale = 0.1f;
					if (scale > 3.0f) scale = 3.0f;

					applyLensSize((int) (baseLensSizePx * scale));
					updateLayoutSafe();
					return true;
				}
			});

        overlay.setOnTouchListener(new View.OnTouchListener() {
				private boolean moved;

				@Override
				public boolean onTouch(View v, MotionEvent e) {
					try { scaleDetector.onTouchEvent(e); } catch (Throwable ignore) {}
					if (scaleDetector != null && scaleDetector.isInProgress()) return true;

					switch (e.getActionMasked()) {
						case MotionEvent.ACTION_DOWN:
							moved = false;
							downRawX = e.getRawX();
							downRawY = e.getRawY();
							startX = params.x;
							startY = params.y;
							return true;

						case MotionEvent.ACTION_MOVE: {
								float rawDx = e.getRawX() - downRawX;
								float rawDy = e.getRawY() - downRawY;

								if (!moved && (Math.abs(rawDx) > touchSlop || Math.abs(rawDy) > touchSlop)) {
									moved = true;
								}

								params.x = startX + Math.round(rawDx);
								params.y = startY + Math.round(rawDy);

								clampToScreen();
								updateLayoutSafe();
								return true;
							}

						case MotionEvent.ACTION_UP:
						case MotionEvent.ACTION_CANCEL:
							return true;
					}

					return true;
				}
			});

        workerThread = new HandlerThread("lens_worker");
        workerThread.start();
        worker = new Handler(workerThread.getLooper());
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent != null ? intent.getAction() : null;

        if (ACTION_STOP.equals(action)) {
            shutdownProjection();
            removeOverlay();
            stopForeground(true);
            stopSelf();
            return START_NOT_STICKY;
        }

        startForegroundSafe();
        addOverlayIfNeeded();
        clampToScreen();
        updateLayoutSafe();

        if (projection == null) {
            int resultCode = intent != null ? intent.getIntExtra(EXTRA_RESULT_CODE, 0) : 0;
            Intent data = intent != null ? intent.getParcelableExtra(EXTRA_RESULT_DATA) : null;
            if (resultCode != 0 && data != null) {
                setupProjection(resultCode, data);
            }
        }

        return START_STICKY;
    }

    private int flagsInteractive() {
        return WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
			| WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL;
    }

    private void startForegroundSafe() {
        try {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (nm == null) throw new RuntimeException("NotificationManager=null");

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                NotificationChannel ch = new NotificationChannel(
					CHANNEL_ID, "Enhance Lens", NotificationManager.IMPORTANCE_MIN);
                ch.setSound(null, null);
                nm.createNotificationChannel(ch);
            }

            Notification.Builder b = (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
				? new Notification.Builder(this, CHANNEL_ID)
				: new Notification.Builder(this);

            Notification n = b.setOngoing(true)
				.setSmallIcon(android.R.drawable.ic_menu_camera)
				.setContentTitle("Assistive Filter")
				.setContentText("Lens: kéo + zoom")
				.build();

            startForeground(NOTIF_ID, n);
        } catch (Throwable t) {
            stopSelf();
        }
    }

    private void addOverlayIfNeeded() {
        if (overlay == null || overlay.getParent() != null) return;
        try {
            wm.addView(overlay, params);
        } catch (Throwable ignore) {}
    }

    private void removeOverlay() {
        try {
            if (wm != null && overlay != null && overlay.getParent() != null) wm.removeView(overlay);
        } catch (Throwable ignore) {}
    }

    private void updateLayoutSafe() {
        try {
            if (wm != null && overlay != null && overlay.getParent() != null) wm.updateViewLayout(overlay, params);
        } catch (Throwable ignore) {}
    }

    private void updateScreenSize() {
        DisplayMetrics dm = getResources().getDisplayMetrics();
        screenW = dm.widthPixels;
        screenH = dm.heightPixels;
        if (screenW < 1) screenW = 1080;
        if (screenH < 1) screenH = 1920;
    }

    private void clampToScreen() {
        updateScreenSize();

        int maxX = Math.max(0, screenW - params.width);
        int maxY = Math.max(0, screenH - params.height);

        if (params.x < 0) params.x = 0;
        if (params.y < 0) params.y = 0;
        if (params.x > maxX) params.x = maxX;
        if (params.y > maxY) params.y = maxY;
    }

    private void applyLensSize(int newSizePx) {
        updateScreenSize();

        int old = lensSizePx;
        int cx = params.x + (old / 2);
        int cy = params.y + (old / 2);

        int sz = newSizePx;
        if (sz < 160) sz = 160;
        if (sz > screenW) sz = screenW;
        if (sz > screenH) sz = screenH;

        lensSizePx = sz;
        params.width = sz;
        params.height = sz;

        params.x = cx - (sz / 2);
        params.y = cy - (sz / 2);

        clampToScreen();
    }

    private void setupProjection(int resultCode, Intent data) {
        try {
            MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
            if (mpm == null) return;

            projection = mpm.getMediaProjection(resultCode, data);
            if (projection == null) return;

            DisplayMetrics dm = getResources().getDisplayMetrics();
            int w = dm.widthPixels;
            int h = dm.heightPixels;
            int dpi = dm.densityDpi;

            reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2);

            vdisplay = projection.createVirtualDisplay(
				"enhance_lens",
				w,
				h,
				dpi,
				DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
				reader.getSurface(),
				null,
				worker
            );

            reader.setOnImageAvailableListener(new ImageReader.OnImageAvailableListener() {
					@Override
					public void onImageAvailable(ImageReader ir) {
						if (processing.getAndSet(true)) return;
						worker.post(new Runnable() {
								@Override
								public void run() {
									try {
										processFrame();
									} finally {
										processing.set(false);
									}
								}
							});
					}
				}, worker);

        } catch (Throwable ignore) {}
    }

    private void processFrame() {
        if (reader == null) return;

        Image img = null;
        try {
            img = reader.acquireLatestImage();
            if (img == null) return;

            Image.Plane[] planes = img.getPlanes();
            if (planes == null || planes.length < 1) return;

            ByteBuffer buf = planes[0].getBuffer();
            int pixelStride = planes[0].getPixelStride();
            int rowStride = planes[0].getRowStride();

            DisplayMetrics dm = getResources().getDisplayMetrics();
            int sw = dm.widthPixels;
            int sh = dm.heightPixels;

            int rowPadding = rowStride - pixelStride * sw;
            int bmpW = sw + rowPadding / pixelStride;

            Bitmap full = Bitmap.createBitmap(bmpW, sh, Bitmap.Config.ARGB_8888);
            full.copyPixelsFromBuffer(buf);

            int cx = params.x + (lensSizePx / 2);
            int cy = params.y + (lensSizePx / 2);

            int half = lensSizePx / 2;
            int left = cx - half;
            int top = cy - half;

            if (left < 0) left = 0;
            if (top < 0) top = 0;
            if (left + lensSizePx > sw) left = Math.max(0, sw - lensSizePx);
            if (top + lensSizePx > sh) top = Math.max(0, sh - lensSizePx);

            Bitmap crop = Bitmap.createBitmap(full, left, top, lensSizePx, lensSizePx);

            if (outBitmap == null || outBitmap.getWidth() != lensSizePx || outBitmap.getHeight() != lensSizePx) {
                outBitmap = Bitmap.createBitmap(lensSizePx, lensSizePx, Bitmap.Config.ARGB_8888);
            }

            Canvas c = new Canvas(outBitmap);

            Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            ColorMatrix cm = new ColorMatrix();
            cm.setSaturation(1.35f);

            ColorMatrix contrast = new ColorMatrix(new float[] {
													   1.15f, 0, 0, 0, 0,
													   0, 1.15f, 0, 0, 0,
													   0, 0, 1.15f, 0, 0,
													   0, 0, 0, 1, 0
												   });

            cm.postConcat(contrast);
            p.setColorFilter(new ColorMatrixColorFilter(cm));

            c.drawBitmap(crop, 0, 0, p);

            sharpenInPlace(outBitmap);

            if (overlay != null) overlay.setFrame(outBitmap);

            crop.recycle();
            full.recycle();

        } catch (Throwable ignore) {
        } finally {
            try { if (img != null) img.close(); } catch (Throwable ignore2) {}
        }
    }

    private static void sharpenInPlace(Bitmap b) {
        int w = b.getWidth();
        int h = b.getHeight();
        int[] src = new int[w * h];
        int[] dst = new int[w * h];
        b.getPixels(src, 0, w, 0, 0, w, h);

        for (int y = 1; y < h - 1; y++) {
            int yw = y * w;
            for (int x = 1; x < w - 1; x++) {
                int i = yw + x;

                int c = src[i];
                int up = src[i - w];
                int dn = src[i + w];
                int lt = src[i - 1];
                int rt = src[i + 1];

                int a = (c >>> 24) & 0xFF;

                int cr = (c >>> 16) & 0xFF;
                int cg = (c >>> 8) & 0xFF;
                int cb = c & 0xFF;

                int ur = (up >>> 16) & 0xFF;
                int ug = (up >>> 8) & 0xFF;
                int ub = up & 0xFF;

                int dr = (dn >>> 16) & 0xFF;
                int dg = (dn >>> 8) & 0xFF;
                int db = dn & 0xFF;

                int lr = (lt >>> 16) & 0xFF;
                int lg = (lt >>> 8) & 0xFF;
                int lb = lt & 0xFF;

                int rr = (rt >>> 16) & 0xFF;
                int rg = (rt >>> 8) & 0xFF;
                int rb = rt & 0xFF;

                int nr = (5 * cr) - ur - dr - lr - rr;
                int ng = (5 * cg) - ug - dg - lg - rg;
                int nb = (5 * cb) - ub - db - lb - rb;

                if (nr < 0) nr = 0; else if (nr > 255) nr = 255;
                if (ng < 0) ng = 0; else if (ng > 255) ng = 255;
                if (nb < 0) nb = 0; else if (nb > 255) nb = 255;

                dst[i] = (a << 24) | (nr << 16) | (ng << 8) | nb;
            }
        }

        for (int x = 0; x < w; x++) {
            dst[x] = src[x];
            dst[(h - 1) * w + x] = src[(h - 1) * w + x];
        }
        for (int y = 0; y < h; y++) {
            dst[y * w] = src[y * w];
            dst[y * w + (w - 1)] = src[y * w + (w - 1)];
        }

        b.setPixels(dst, 0, w, 0, 0, w, h);
    }

    private void shutdownProjection() {
        try { if (reader != null) reader.setOnImageAvailableListener(null, null); } catch (Throwable ignore) {}
        try { if (vdisplay != null) vdisplay.release(); } catch (Throwable ignore) {}
        try { if (projection != null) projection.stop(); } catch (Throwable ignore) {}
        reader = null;
        vdisplay = null;
        projection = null;
    }

    @Override
    public void onDestroy() {
        shutdownProjection();
        removeOverlay();
        try {
            if (workerThread != null) workerThread.quitSafely();
        } catch (Throwable ignore) {}
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }
}

