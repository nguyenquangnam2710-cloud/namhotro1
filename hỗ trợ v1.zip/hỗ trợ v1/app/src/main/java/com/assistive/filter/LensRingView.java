package com.assistive.filter;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.View;

public final class LensRingView extends View {

    private final Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);

    public LensRingView(Context c) {
        super(c);
        ring.setStyle(Paint.Style.STROKE);
        ring.setStrokeWidth(dp(2f));
        ring.setColor(0xFFFF1744);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        float w = getWidth();
        float h = getHeight();
        float cx = w * 0.5f;
        float cy = h * 0.5f;
        float r = Math.min(cx, cy);
        canvas.drawCircle(cx, cy, r - ring.getStrokeWidth() * 0.5f, ring);
    }

    private float dp(float v) {
        return v * getResources().getDisplayMetrics().density;
    }
}

