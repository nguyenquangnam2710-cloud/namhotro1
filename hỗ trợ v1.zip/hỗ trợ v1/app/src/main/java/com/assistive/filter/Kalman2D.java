package com.assistive.filter;

public final class Kalman2D {

    private final float qPos;
    private final float qVel;
    private final float rMeas;

    private boolean inited;

    private float x;
    private float y;
    private float vx;
    private float vy;

    private float p00 = 1f;
    private float p01 = 0f;
    private float p10 = 0f;
    private float p11 = 1f;

    private float p00y = 1f;
    private float p01y = 0f;
    private float p10y = 0f;
    private float p11y = 1f;

    public Kalman2D() {
        this(25f, 250f, 64f);
    }

    public Kalman2D(float qPos, float qVel, float rMeas) {
        this.qPos = qPos;
        this.qVel = qVel;
        this.rMeas = rMeas;
    }

    public void reset(TargetSample s) {
        inited = true;
        x = s.x;
        y = s.y;
        vx = s.vx;
        vy = s.vy;

        p00 = 64f; p01 = 0f; p10 = 0f; p11 = 256f;
        p00y = 64f; p01y = 0f; p10y = 0f; p11y = 256f;
    }

    public void predict(float dt) {
        if (!inited) return;

        x += vx * dt;
        y += vy * dt;

        float a00 = 1f;
        float a01 = dt;
        float a10 = 0f;
        float a11 = 1f;

        float q00 = qPos * dt * dt;
        float q11 = qVel * dt * dt;

        {
            float t00 = a00 * p00 + a01 * p10;
            float t01 = a00 * p01 + a01 * p11;
            float t10 = a10 * p00 + a11 * p10;
            float t11 = a10 * p01 + a11 * p11;

            p00 = t00 * a00 + t01 * a01 + q00;
            p01 = t00 * a10 + t01 * a11;
            p10 = t10 * a00 + t11 * a01;
            p11 = t10 * a10 + t11 * a11 + q11;
        }

        {
            float t00 = a00 * p00y + a01 * p10y;
            float t01 = a00 * p01y + a01 * p11y;
            float t10 = a10 * p00y + a11 * p10y;
            float t11 = a10 * p01y + a11 * p11y;

            p00y = t00 * a00 + t01 * a01 + q00;
            p01y = t00 * a10 + t01 * a11;
            p10y = t10 * a00 + t11 * a01;
            p11y = t10 * a10 + t11 * a11 + q11;
        }
    }

    public void update(float zx, float zy, float measuredVx, float measuredVy, float confidence) {
        if (!inited) {
            reset(new TargetSample(0L, zx, zy, measuredVx, measuredVy, confidence));
            return;
        }

        float conf = clamp(confidence, 0.15f, 1f);
        float r = Math.max(16f, rMeas / conf);

        {
            float s = p00 + r;
            float k0 = p00 / s;
            float k1 = p10 / s;

            float yerr = zx - x;
            x += k0 * yerr;
            vx += k1 * yerr;

            float p00n = (1f - k0) * p00;
            float p01n = (1f - k0) * p01;
            float p10n = p10 - k1 * p00;
            float p11n = p11 - k1 * p01;

            p00 = p00n; p01 = p01n; p10 = p10n; p11 = p11n;
        }

        {
            float s = p00y + r;
            float k0 = p00y / s;
            float k1 = p10y / s;

            float yerr = zy - y;
            y += k0 * yerr;
            vy += k1 * yerr;

            float p00n = (1f - k0) * p00y;
            float p01n = (1f - k0) * p01y;
            float p10n = p10y - k1 * p00y;
            float p11n = p11y - k1 * p01y;

            p00y = p00n; p01y = p01n; p10y = p10n; p11y = p11n;
        }

        float velBlend = clamp(confidence * 0.25f, 0.05f, 0.35f);
        vx = vx * (1f - velBlend) + measuredVx * velBlend;
        vy = vy * (1f - velBlend) + measuredVy * velBlend;
    }

    public TargetSample getState(long nowMillis, float confidence) {
        return new TargetSample(nowMillis, x, y, vx, vy, confidence);
    }

    private static float clamp(float v, float lo, float hi) {
        if (v < lo) return lo;
        if (v > hi) return hi;
        return v;
    }
}

