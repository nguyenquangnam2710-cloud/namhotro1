package com.assistive.filter;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.graphics.Path;
import android.os.IBinder;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.util.DisplayMetrics;
import android.view.accessibility.AccessibilityEvent;

public final class AssistTouchAccessibilityService extends AccessibilityService {

    public static final String ACTION_MOVE_BY = "com.assistive.filter.API_POINTER_MOVE_BY";
    public static final String ACTION_TAP = "com.assistive.filter.API_POINTER_TAP";
    public static final String ACTION_MOVE_TO_TARGET = "com.assistive.filter.API_POINTER_MOVE_TO_TARGET";

    public static final String EXTRA_DX = "dx";
    public static final String EXTRA_DY = "dy";
    public static final String EXTRA_X = "x";
    public static final String EXTRA_Y = "y";
    public static final String EXTRA_BASE = "base";
    public static final String EXTRA_CURRENT = "current";
    public static final String EXTRA_DIRECTION = "direction";
    public static final String EXTRA_BASE_Y_OFFSET = "base_y_offset";
    public static final String EXTRA_BASE_X_PREDICTION = "base_x_prediction";
    public static final String EXTRA_DURATION_MS = "duration_ms";

    private static final float Y_AXIS_BOOST = 2.0f;
    private static final float STOP_MARGIN_PX = 5f;
    private static final float AIM_ASSIST_RANGE_PX = 540f;
    private static final float AIM_ASSIST_STRENGTH = 2.0f;

    private static final long LONG_PRESS_NS = 150_000_000L;
    private static final float V_Y_BASE = 7550f;
    private static final float V_X_RUN = 260f;
    private static final float V_X_WALK = 180f;
    private static final float V_X_STILL = 0f;
    private static final float V_X_THRESHOLD_WALK = 50f;
    private static final float V_X_THRESHOLD_RUN = 200f;
    private static final float DURATION_SEC = 0.2f;

    private final Handler main = new Handler(Looper.getMainLooper());

    private volatile GainBridgeService.GainBinder gainBinder;
    private final ServiceConnection conn = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            gainBinder = (GainBridgeService.GainBinder) service;
        }
        @Override
        public void onServiceDisconnected(ComponentName name) {
            gainBinder = null;
        }
    };

    private volatile boolean recoilRunning;
    private volatile double recoilD;
    private volatile int recoilDirX = 1;
    private volatile float recoilVp;
    private long recoilStartNs, recoilLastTickNs;

    private final Runnable recoilTick = new Runnable() {
        @Override
        public void run() {
            if (!recoilRunning) return;
            long now = SystemClock.elapsedRealtimeNanos();
            double dt = 1.0 / 120.0;
            if (recoilLastTickNs != 0L) {
                long dn = now - recoilLastTickNs;
                if (dn < 1L) dn = 1L;
                if (dn > 50000000L) dn = 50000000L;
                dt = dn / 1e9;
            }
            recoilLastTickNs = now;
            double t = (recoilStartNs == 0L) ? 0.0 : (now - recoilStartNs) / 1e9;
            if (recoilD <= 0.0 || recoilVp <= 0f) {
                main.postDelayed(this, 8L);
                return;
            }
            float[] v = AssistiveRecoil.velocityMmPerSec(recoilD, recoilVp, t);
            if (v == null) {
                main.postDelayed(this, 8L);
                return;
            }
            float vx = v[0], vy = v[1];
            float dxMm = (float)(vx * dt);
            float dyMm = (float)(vy * dt);
            float dxPx = mmToPxX(dxMm) * recoilDirX;
            float dyPx = -mmToPxY(dyMm);
            apiMoveByRaw(dxPx, dyPx);
            main.postDelayed(this, 8L);
        }
    };

    private final BroadcastReceiver apiReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (!ApiConfig.validate(AssistTouchAccessibilityService.this, intent)) return;
            if (intent == null) return;
            final String a = intent.getAction();
            if (a == null) return;

            if (ACTION_MOVE_BY.equals(a)) {
                final float dx = intent.getFloatExtra(EXTRA_DX, 0f);
                final float dy = intent.getFloatExtra(EXTRA_DY, 0f);
                main.post(new Runnable() {
						public void run() { apiMoveBy(dx, dy); }
					});
                return;
            }
            if (ACTION_TAP.equals(a)) {
                final float x = intent.getFloatExtra(EXTRA_X, -1f);
                final float y = intent.getFloatExtra(EXTRA_Y, -1f);
                final long dur = clampDur(intent.getLongExtra(EXTRA_DURATION_MS, 60L));
                main.post(new Runnable() {
						public void run() { apiTap(x, y, dur); }
					});
                return;
            }
            if (ACTION_MOVE_TO_TARGET.equals(a)) {
                final double base = intent.getDoubleExtra(EXTRA_BASE, 0.0);
                final double current = intent.getDoubleExtra(EXTRA_CURRENT, 0.0);
                final int direction = intent.getIntExtra(EXTRA_DIRECTION, 1);
                final double baseYOffset = intent.getDoubleExtra(EXTRA_BASE_Y_OFFSET, 187.32);
                final double baseXPred = intent.getDoubleExtra(EXTRA_BASE_X_PREDICTION, 469.31);
                final long dur = clampDur(intent.getLongExtra(EXTRA_DURATION_MS, 18L));
                main.post(new Runnable() {
						public void run() { apiMoveToComputedTarget(base, current, direction, baseYOffset, baseXPred, dur); }
					});
                return;
            }

            if (ActionApiReceiver.ACTION_RECOIL_START.equals(a)) {
                final double d = intent.getDoubleExtra(ActionApiReceiver.EXTRA_D_M, Double.NaN);
                final int dirX0 = intent.getIntExtra(ActionApiReceiver.EXTRA_DIR_X, 1);
                main.post(new Runnable() {
						public void run() {
							if (Double.isNaN(d) || d <= 0.0) return;
							recoilD = d;
							recoilDirX = dirX0 >= 0 ? 1 : -1;
							recoilVp = AssistiveRecoil.vpFromDistanceM((float) d);
							recoilStartNs = SystemClock.elapsedRealtimeNanos();
							recoilLastTickNs = 0L;
							recoilRunning = true;
							main.removeCallbacks(recoilTick);
							main.post(recoilTick);
						}
					});
                return;
            }
            if (ActionApiReceiver.ACTION_RECOIL_UPDATE_DISTANCE.equals(a)) {
                final double d = intent.getDoubleExtra(ActionApiReceiver.EXTRA_D_M, Double.NaN);
                main.post(new Runnable() {
						public void run() {
							if (!recoilRunning) return;
							if (Double.isNaN(d) || d <= 0.0) return;
							recoilD = d;
							recoilVp = AssistiveRecoil.vpFromDistanceM((float) d);
						}
					});
                return;
            }
            if (ActionApiReceiver.ACTION_RECOIL_STOP.equals(a)) {
                main.post(new Runnable() {
						public void run() {
							recoilRunning = false;
							main.removeCallbacks(recoilTick);
						}
					});
                return;
            }
        }
    };

    @Override
    protected void onServiceConnected() {
        Intent i = new Intent(this, GainBridgeService.class);
        try { bindService(i, conn, Context.BIND_AUTO_CREATE); } catch (Throwable ignore) {}
        IntentFilter f = new IntentFilter();
        f.addAction(ACTION_MOVE_BY);
        f.addAction(ACTION_TAP);
        f.addAction(ACTION_MOVE_TO_TARGET);
        f.addAction(ActionApiReceiver.ACTION_RECOIL_START);
        f.addAction(ActionApiReceiver.ACTION_RECOIL_STOP);
        f.addAction(ActionApiReceiver.ACTION_RECOIL_UPDATE_DISTANCE);
        try { registerReceiver(apiReceiver, f); } catch (Throwable ignore) {}
    }

    private void apiMoveBy(float dx, float dy) {
        float g = 0f;
        GainBridgeService.GainBinder b = gainBinder;
        if (b != null) {
            try { g = b.getGain(); } catch (Throwable ignore) {}
        }
        float k = scaleFactorFromGain(g);
        float totalDx = dx * k;
        float totalDy = dy * k * Y_AXIS_BOOST;
        dispatchLineGestureSwipe(totalDx, totalDy);
    }

    private void apiMoveByRaw(float dx, float dy) {
        dispatchLineGestureSwipe(dx, dy * Y_AXIS_BOOST);
    }

    private void apiTap(float x, float y, long durationMs) {
        if (x < 0f || y < 0f) return;
        dispatchTapGesture(x, y, durationMs);
    }

    private void apiMoveToComputedTarget(double base, double current, int direction, double baseYOffset, double baseXPred, long durationMs) {
        DisplayMetrics dm = getResources().getDisplayMetrics();
        float tx = AssistiveTargetMath.computeXTargetPx(dm, base, current, direction, baseXPred);
        float ty = AssistiveTargetMath.computeYTargetPx(dm, base, current, baseYOffset);
        if (tx < 0f || ty < 0f) return;
        float fromX = dm.widthPixels / 2f;
        float fromY = dm.heightPixels / 2f;
        dispatchLineGesture(fromX, fromY, tx, ty, durationMs);
    }

    private void dispatchLineGestureSwipe(float dx, float dy) {
        DisplayMetrics dm = getResources().getDisplayMetrics();
        float fromX = dm.widthPixels / 2f;
        float fromY = dm.heightPixels / 2f;
        float toX = clampX(fromX + dx);
        float toY = clampY(fromY + dy);
        long duration = (long)(Math.hypot(dx, dy) / 4000f * 1000f);
        if (duration < 6L) duration = 6L;
        if (duration > 200L) duration = 200L;
        dispatchLineGesture(fromX, fromY, toX, toY, duration);
    }

    public void dispatchLineGesture(float fx, float fy, float tx, float ty, long durationMs) {
        Path path = new Path();
        path.moveTo(fx, fy);
        path.lineTo(tx, ty);
        GestureDescription.StrokeDescription stroke =
            new GestureDescription.StrokeDescription(path, 0L, clampDur(durationMs));
        GestureDescription gesture = new GestureDescription.Builder()
            .addStroke(stroke)
            .build();
        dispatchGesture(gesture, null, null);
    }

    public void dispatchTapGesture(float x, float y, long durationMs) {
        Path path = new Path();
        path.moveTo(x, y);
        path.lineTo(x, y);
        GestureDescription.StrokeDescription stroke =
            new GestureDescription.StrokeDescription(path, 0L, clampDur(durationMs));
        GestureDescription gesture = new GestureDescription.Builder()
            .addStroke(stroke)
            .build();
        dispatchGesture(gesture, null, null);
    }

    private float scaleFactorFromGain(float gain) {
        float g = gain;
        if (g < 0.38f) g = 0.38f;
        if (g > 3.05f) g = 3.05f;
        return g;
    }

    private float mmToPxX(float mm) {
        DisplayMetrics dm = getResources().getDisplayMetrics();
        float xdpi = dm.xdpi > 0f ? dm.xdpi : dm.densityDpi;
        return mm * xdpi / 25.4f;
    }

    private float mmToPxY(float mm) {
        DisplayMetrics dm = getResources().getDisplayMetrics();
        float ydpi = dm.ydpi > 0f ? dm.ydpi : dm.densityDpi;
        return mm * ydpi / 25.4f;
    }

    private float clampX(float x) {
        DisplayMetrics dm = getResources().getDisplayMetrics();
        float max = Math.max(0f, (float) dm.widthPixels - 1f);
        if (x < 0f) return 0f;
        if (x > max) return max;
        return x;
    }

    private float clampY(float y) {
        DisplayMetrics dm = getResources().getDisplayMetrics();
        float max = Math.max(0f, (float) dm.heightPixels - 1f);
        if (y < 0f) return 0f;
        if (y > max) return max;
        return y;
    }

    private static long clampDur(long v) {
        if (v < 6L) return 6L;
        if (v > 900L) return 900L;
        return v;
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {}
    @Override
    public void onInterrupt() {}
    @Override
    public void onDestroy() {
        recoilRunning = false;
        main.removeCallbacks(recoilTick);
        try { unregisterReceiver(apiReceiver); } catch (Throwable ignore) {}
        try { unbindService(conn); } catch (Throwable ignore) {}
        super.onDestroy();
    }
}
