package com.assistive.filter;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;
import android.util.DisplayMetrics;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;

public final class AssistTouchAccessibilityService extends AccessibilityService {

    public static final String ACTION_MOVE_BY = "com.assistive.filter.API_POINTER_MOVE_BY";
    public static final String ACTION_TAP = "com.assistive.filter.API_POINTER_TAP";
    public static final String ACTION_MOVE_TO_TARGET = "com.assistive.filter.API_POINTER_MOVE_TO_TARGET";

    public static final String EXTRA_DX = "dx";
    public static final String EXTRA_DY = "dy";
    public static final String EXTRA_X = "x";
    public static final String EXTRA_Y = "y";
    public static final String EXTRA_BASE = "base";
    public static final String EXTRA_CURRENT = "current";
    public static final String EXTRA_DIRECTION = "direction";
    public static final String EXTRA_BASE_Y_OFFSET = "base_y_offset";
    public static final String EXTRA_BASE_X_PREDICTION = "base_x_prediction";
    public static final String EXTRA_DURATION_MS = "duration_ms";

    // Lực phá (giữ nguyên)
    private static final float BREAK_FORCE_DISTANCE_PX = 775f;
    private static final float BREAK_FORCE_TIME_SEC = 0.1f;
    private static final float BREAK_FORCE_MULTIPLIER = 1.20f;
    private static final float BREAK_FORCE_SPEED_PX_PER_SEC = BREAK_FORCE_DISTANCE_PX / BREAK_FORCE_TIME_SEC;
    private static final float BREAK_FORCE_BOOSTED_SPEED_PX_PER_SEC = BREAK_FORCE_SPEED_PX_PER_SEC * BREAK_FORCE_MULTIPLIER;

    private static final float Y_AXIS_BOOST = 2.0f;
    private static final float STOP_MARGIN_PX = 1f;

    // Aim assist nhẹ khi di chuyển
    private static final float AIM_ASSIST_RANGE_PX = 540f;
    private static final float AIM_ASSIST_STRENGTH = 2.0f;

    // Nam châm mạnh khi nhấn giữ
    private static final long LONG_PRESS_NS = 150_000_000L; // 0.15 giây

    private final Handler main = new Handler(Looper.getMainLooper());

    private WindowManager wm;
    private WindowManager.LayoutParams params;
    private TouchOverlayView overlay;

    private volatile GainBridgeService.GainBinder gainBinder;

    private boolean hasPointer;
    private float pointerX;
    private float pointerY;

    private boolean dispatching;
    private boolean hasPending;
    private float pendingFromX, pendingFromY, pendingToX, pendingToY;

    // Trạng thái cho nam châm nhấn giữ
    private long downTimeNs;
    private float downStartX;
    private boolean strongAimTriggered = false;
    private boolean longPressEligible = false; // bắt đầu ở nửa phải?

    // ... (các biến recoil, drag, headlock giữ nguyên)
    private volatile boolean recoilRunning;
    private volatile double recoilD;
    private volatile int recoilDirX = 1;
    private volatile float recoilVp;
    private long recoilStartNs, recoilLastTickNs;

    private volatile boolean dragAssistEnabled;
    private volatile float dragAssistDistanceM = 10f;
    private volatile float dragAssistLookSensitivity = 100f;
    private boolean dragAutoSweepTriggered;

    private volatile boolean headLockEnabled;
    private volatile float headLockManualY = Float.NaN;
    private boolean headLockTriggered;

    private long manualMoveLastNs;

    // ... (recoilTick, apiReceiver, ServiceConnection giữ nguyên)

    // ----- onServiceConnected() và listener mới -----
    @Override
    protected void onServiceConnected() {
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        Intent i = new Intent(this, GainBridgeService.class);
        try { bindService(i, conn, Context.BIND_AUTO_CREATE); } catch (Throwable ignore) {}

        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
			? WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
			: WindowManager.LayoutParams.TYPE_PHONE;
        params = new WindowManager.LayoutParams(
			WindowManager.LayoutParams.MATCH_PARENT,
			WindowManager.LayoutParams.MATCH_PARENT,
			type,
			WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
			| WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
			| WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
			PixelFormat.TRANSLUCENT);

        overlay = new TouchOverlayView(this);
        overlay.listener = new TouchOverlayView.Listener() {
            @Override
            public void onDown(float x, float y) {
                pointerX = x;
                pointerY = y;
                hasPointer = true;

                dragAutoSweepTriggered = false;
                headLockTriggered = false;
                resetManualBreakForceClock();

                // Bắt đầu đếm nhấn giữ
                downTimeNs = SystemClock.elapsedRealtimeNanos();
                downStartX = x;
                strongAimTriggered = false;
                // Chỉ kích hoạt nếu bắt đầu ở nửa phải màn hình
                float halfW = getResources().getDisplayMetrics().widthPixels / 2f;
                longPressEligible = x > halfW;
            }

            @Override
            public void onMove(float dx, float dy) {
                if (!hasPointer) return;

                // Nếu chưa kích hoạt headlock/drag thì kiểm tra nam châm mạnh
                if (!headLockEnabled && !dragAssistEnabled) {
                    if (!strongAimTriggered && longPressEligible) {
                        long elapsed = SystemClock.elapsedRealtimeNanos() - downTimeNs;
                        if (elapsed >= LONG_PRESS_NS) {
                            strongAimTriggered = true;
                            // Lấy đỉnh mục tiêu
                            float yHead = resolveHeadY();
                            if (yHead >= 0f) {
                                triggerStrongAimAssist(yHead);
                                return; // không xử lý di chuyển nữa
                            }
                        }
                    }
                }

                // Xử lý headlock (giữ nguyên)
                if (headLockEnabled) {
                    if (headLockTriggered) return;
                    if (dy < 0f) {
                        float yHead = resolveHeadY();
                        if (yHead >= 0f) {
                            headLockTriggered = true;
                            runHeadLockGesture(yHead);
                            return;
                        }
                    }
                }

                if (dragAssistEnabled) {
                    if (dragAutoSweepTriggered) return;
                    if (dy < 0f) {
                        dragAutoSweepTriggered = true;
                        runDipRiseAssistGesture();
                        return;
                    }
                }

                // Di chuyển bình thường + aim assist nhẹ
                float g = 0f;
                GainBridgeService.GainBinder b = gainBinder;
                if (b != null) { try { g = b.getGain(); } catch (Throwable ignore) {} }
                float k = scaleFactorFromGain(g);

                float fromX = pointerX;
                float fromY = pointerY;

                float manualDx = dx * k;
                float manualDy = dy * k * Y_AXIS_BOOST;
                float breakDy = breakHoldCompensationY(dy) * Y_AXIS_BOOST;
                float totalDy = manualDy + breakDy;

                // Aim assist nhẹ (chỉ khi không có các chế độ đặc biệt)
                if (!headLockEnabled && !dragAssistEnabled && enhancelensservice.hasLiveTarget()) {
                    float yHead = enhancelensservice.getLastTargetScreenY();
                    float dyToHead = yHead - pointerY;
                    float dist = Math.abs(dyToHead);
                    if (dist <= AIM_ASSIST_RANGE_PX && dyToHead < 0) {
                        float assistFactor = 1.0f - (dist / AIM_ASSIST_RANGE_PX);
                        totalDy += dyToHead * assistFactor * AIM_ASSIST_STRENGTH;
                    }
                }

                totalDy = clampUpwardToLiveTarget(totalDy);

                pointerX = clampX(pointerX + manualDx);
                pointerY = clampY(pointerY + totalDy);
                enqueueSegment(fromX, fromY, pointerX, pointerY);
            }

            @Override
            public void onUp() {
                hasPointer = false;
                dragAutoSweepTriggered = false;
                headLockTriggered = false;
                strongAimTriggered = false;
                longPressEligible = false;
                resetManualBreakForceClock();
            }
        };

        try { wm.addView(overlay, params); } catch (Throwable ignore) {}

        // Đăng ký receiver như cũ...
        IntentFilter f = new IntentFilter();
        f.addAction(ACTION_MOVE_BY);
        f.addAction(ACTION_TAP);
        f.addAction(ACTION_MOVE_TO_TARGET);
        f.addAction(ActionApiReceiver.ACTION_RECOIL_START);
        f.addAction(ActionApiReceiver.ACTION_RECOIL_STOP);
        f.addAction(ActionApiReceiver.ACTION_RECOIL_UPDATE_DISTANCE);
        f.addAction(ActionApiReceiver.ACTION_DRAG_ASSIST_START);
        f.addAction(ActionApiReceiver.ACTION_DRAG_ASSIST_STOP);
        f.addAction(ActionApiReceiver.ACTION_DRAG_ASSIST_UPDATE_DISTANCE);
        f.addAction(ActionApiReceiver.ACTION_HEADLOCK_ENABLE);
        f.addAction(ActionApiReceiver.ACTION_HEADLOCK_DISABLE);
        f.addAction(ActionApiReceiver.ACTION_HEADLOCK_TRIGGER);
        try { registerReceiver(apiReceiver, f); } catch (Throwable ignore) {}
    }

    // ----- Phương thức nam châm mạnh -----
    private void triggerStrongAimAssist(float yHead) {
        if (!hasPointer) {
            DisplayMetrics dm = getResources().getDisplayMetrics();
            pointerX = dm.widthPixels * 0.5f;
            pointerY = dm.heightPixels * 0.5f;
            hasPointer = true;
        }

        float startX = clampX(pointerX);
        float startY = clampY(pointerY);
        float endY = clampY(AssistiveHeadLockFormula.finalY(startY, yHead));
        if (endY < yHead) endY = yHead; // chặn quá đỉnh

        // Vuốt cực nhanh trong 50 ms
        long dur = 50L;
        pointerX = startX;
        pointerY = endY;

        dispatchLineGesture(startX, startY, startX, endY, dur);
    }

    // ... (các phương thức giữ nguyên: breakHoldCompensationY, clampUpwardToLiveTarget, resolveHeadY, runHeadLockGesture, runDipRiseAssistGesture, apiMoveBy, apiMoveByRaw, ...)

    // (Giữ nguyên toàn bộ phần còn lại của class, tôi chỉ thêm/sửa phần trên)
    // ... (phần còn lại copy y nguyên từ file trước, không thay đổi)
}
