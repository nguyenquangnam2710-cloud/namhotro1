package com.assistive.filter;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;

public final class AssistTouchAccessibilityService extends AccessibilityService {

    public static final String ACTION_MOVE_BY = "com.assistive.filter.API_POINTER_MOVE_BY";
    public static final String ACTION_TAP = "com.assistive.filter.API_POINTER_TAP";
    public static final String ACTION_MOVE_TO_TARGET = "com.assistive.filter.API_POINTER_MOVE_TO_TARGET";

    public static final String EXTRA_DX = "dx";
    public static final String EXTRA_DY = "dy";

    public static final String EXTRA_X = "x";
    public static final String EXTRA_Y = "y";

    public static final String EXTRA_BASE = "base";
    public static final String EXTRA_CURRENT = "current";
    public static final String EXTRA_DIRECTION = "direction";
    public static final String EXTRA_BASE_Y_OFFSET = "base_y_offset";
    public static final String EXTRA_BASE_X_PREDICTION = "base_x_prediction";
    public static final String EXTRA_DURATION_MS = "duration_ms";

    private final Handler main = new Handler(Looper.getMainLooper());

    private WindowManager wm;
    private WindowManager.LayoutParams params;
    private TouchOverlayView overlay;

    private volatile GainBridgeService.GainBinder gainBinder;

    private boolean hasPointer;
    private float pointerX;
    private float pointerY;

    private boolean dispatching;
    private boolean hasPending;
    private float pendingFromX;
    private float pendingFromY;
    private float pendingToX;
    private float pendingToY;

    private final BroadcastReceiver apiReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (!ApiConfig.validate(AssistTouchAccessibilityService.this, intent)) return;
            if (intent == null) return;

            final String a = intent.getAction();
            if (a == null) return;

            if (ACTION_MOVE_BY.equals(a)) {
                final float dx = intent.getFloatExtra(EXTRA_DX, 0f);
                final float dy = intent.getFloatExtra(EXTRA_DY, 0f);
                main.post(new Runnable() {
						@Override
						public void run() {
							apiMoveBy(dx, dy);
						}
					});
                return;
            }

            if (ACTION_TAP.equals(a)) {
                final float x = intent.getFloatExtra(EXTRA_X, -1f);
                final float y = intent.getFloatExtra(EXTRA_Y, -1f);
                final long dur = clampDur(intent.getLongExtra(EXTRA_DURATION_MS, 60L));
                main.post(new Runnable() {
						@Override
						public void run() {
							apiTap(x, y, dur);
						}
					});
                return;
            }

            if (ACTION_MOVE_TO_TARGET.equals(a)) {
                final double base = intent.getDoubleExtra(EXTRA_BASE, 0.0);
                final double current = intent.getDoubleExtra(EXTRA_CURRENT, 0.0);
                final int direction = intent.getIntExtra(EXTRA_DIRECTION, 1);
                final double baseYOffset = intent.getDoubleExtra(EXTRA_BASE_Y_OFFSET, 187.32);
                final double baseXPred = intent.getDoubleExtra(EXTRA_BASE_X_PREDICTION, 469.31);
                final long dur = clampDur(intent.getLongExtra(EXTRA_DURATION_MS, 18L));

                main.post(new Runnable() {
						@Override
						public void run() {
							apiMoveToComputedTarget(base, current, direction, baseYOffset, baseXPred, dur);
						}
					});
            }
        }
    };

    private final ServiceConnection conn = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            gainBinder = (GainBridgeService.GainBinder) service;
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            gainBinder = null;
        }
    };

    @Override
    protected void onServiceConnected() {
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);

        Intent i = new Intent(this, GainBridgeService.class);
        try { bindService(i, conn, Context.BIND_AUTO_CREATE); } catch (Throwable ignore) {}

        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
            ? WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
            : WindowManager.LayoutParams.TYPE_PHONE;

        params = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
			| WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
			| WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        );

        overlay = new TouchOverlayView(this);
        overlay.listener = new TouchOverlayView.Listener() {
            @Override
            public void onDown(float x, float y) {
                pointerX = x;
                pointerY = y;
                hasPointer = true;
            }

            @Override
            public void onMove(float dx, float dy) {
                if (!hasPointer) return;

                float g = 0f;
                GainBridgeService.GainBinder b = gainBinder;
                if (b != null) {
                    try { g = b.getGain(); } catch (Throwable ignore) {}
                }

                float k = scaleFactorFromGain(g);

                float fromX = pointerX;
                float fromY = pointerY;

                pointerX = clampX(pointerX + dx * k);
                pointerY = clampY(pointerY + dy * k);

                enqueueSegment(fromX, fromY, pointerX, pointerY);
            }

            @Override
            public void onUp() {
                hasPointer = false;
            }
        };

        try { wm.addView(overlay, params); } catch (Throwable ignore) {}

        IntentFilter f = new IntentFilter();
        f.addAction(ACTION_MOVE_BY);
        f.addAction(ACTION_TAP);
        f.addAction(ACTION_MOVE_TO_TARGET);
        try { registerReceiver(apiReceiver, f); } catch (Throwable ignore) {}
    }

    private void apiMoveBy(float dx, float dy) {
        if (!hasPointer) {
            DisplayMetrics dm = getResources().getDisplayMetrics();
            pointerX = dm.widthPixels * 0.5f;
            pointerY = dm.heightPixels * 0.5f;
            hasPointer = true;
        }

        float g = 0f;
        GainBridgeService.GainBinder b = gainBinder;
        if (b != null) {
            try { g = b.getGain(); } catch (Throwable ignore) {}
        }

        float k = scaleFactorFromGain(g);

        float fromX = pointerX;
        float fromY = pointerY;

        pointerX = clampX(pointerX + dx * k);
        pointerY = clampY(pointerY + dy * k);

        enqueueSegment(fromX, fromY, pointerX, pointerY);
    }

    private void apiTap(float x, float y, long durationMs) {
        if (x < 0f || y < 0f) return;
        dispatchTapGesture(x, y, durationMs);
    }

    private void apiMoveToComputedTarget(double base, double current, int direction, double baseYOffset, double baseXPred, long durationMs) {
        DisplayMetrics dm = getResources().getDisplayMetrics();
        float tx = AssistiveTargetMath.computeXTargetPx(dm, base, current, direction, baseXPred);
        float ty = AssistiveTargetMath.computeYTargetPx(dm, base, current, baseYOffset);

        if (tx < 0f || ty < 0f) return;

        if (!hasPointer) {
            pointerX = dm.widthPixels * 0.5f;
            pointerY = dm.heightPixels * 0.5f;
            hasPointer = true;
        }

        float fromX = pointerX;
        float fromY = pointerY;

        pointerX = clampX(tx);
        pointerY = clampY(ty);

        dispatchLineGesture(fromX, fromY, pointerX, pointerY, durationMs);
    }

private float scaleFactorFromGain(float gain) {
    float g = gain;
    if (g < 0.38f) g = 0.38f;
    if (g > 3.05f) g = 3.05f;
    return g;
}


    private float clampX(float x) {
        DisplayMetrics dm = getResources().getDisplayMetrics();
        float max = Math.max(0f, (float) dm.widthPixels - 1f);
        if (x < 0f) return 0f;
        if (x > max) return max;
        return x;
    }

    private float clampY(float y) {
        DisplayMetrics dm = getResources().getDisplayMetrics();
        float max = Math.max(0f, (float) dm.heightPixels - 1f);
        if (y < 0f) return 0f;
        if (y > max) return max;
        return y;
    }

    private void enqueueSegment(float fx, float fy, float tx, float ty) {
        pendingFromX = fx;
        pendingFromY = fy;
        pendingToX = tx;
        pendingToY = ty;
        hasPending = true;
        tryDispatchNext();
    }

    private void tryDispatchNext() {
        if (dispatching) return;
        if (!hasPending) return;

        dispatching = true;

        final float fx = pendingFromX;
        final float fy = pendingFromY;
        final float tx = pendingToX;
        final float ty = pendingToY;

        hasPending = false;

        dispatchLineGestureInternal(fx, fy, tx, ty, 12L, true);
    }

    private void dispatchLineGesture(float fx, float fy, float tx, float ty, long durationMs) {
        dispatchLineGestureInternal(fx, fy, tx, ty, durationMs, false);
    }

    private void dispatchLineGestureInternal(float fx, float fy, float tx, float ty, long durationMs, final boolean chain) {
        Path path = new Path();
        path.moveTo(fx, fy);
        path.lineTo(tx, ty);

        GestureDescription.StrokeDescription stroke =
            new GestureDescription.StrokeDescription(path, 0L, clampDur(durationMs));

        GestureDescription gesture = new GestureDescription.Builder()
            .addStroke(stroke)
            .build();

        boolean ok = dispatchGesture(gesture, new GestureResultCallback() {
				@Override
				public void onCompleted(GestureDescription gestureDescription) {
					dispatching = false;
					if (chain) {
						main.post(new Runnable() {
								@Override
								public void run() {
									tryDispatchNext();
								}
							});
					}
				}

				@Override
				public void onCancelled(GestureDescription gestureDescription) {
					dispatching = false;
					if (chain) {
						main.post(new Runnable() {
								@Override
								public void run() {
									tryDispatchNext();
								}
							});
					}
				}
			}, null);

        if (!ok) dispatching = false;
    }

    private void dispatchTapGesture(float x, float y, long durationMs) {
        Path path = new Path();
        path.moveTo(x, y);
        path.lineTo(x, y);

        GestureDescription.StrokeDescription stroke =
            new GestureDescription.StrokeDescription(path, 0L, clampDur(durationMs));

        GestureDescription gesture = new GestureDescription.Builder()
            .addStroke(stroke)
            .build();

        dispatchGesture(gesture, null, null);
    }

    private static long clampDur(long v) {
        if (v < 6L) return 6L;
        if (v > 900L) return 900L;
        return v;
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {}

    @Override
    public void onInterrupt() {}

    @Override
    public void onDestroy() {
        try { unregisterReceiver(apiReceiver); } catch (Throwable ignore) {}
        try {
            if (wm != null && overlay != null && overlay.getParent() != null) wm.removeView(overlay);
        } catch (Throwable ignore) {}
        try { unbindService(conn); } catch (Throwable ignore) {}
        super.onDestroy();
    }

    private interface ServiceConnection extends android.content.ServiceConnection {}
}

