package com.assistive.filter;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.accessibilityservice.GestureDescription;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;

public class AssistTouchAccessibilityService extends AccessibilityService {

    public static final String ACTION_MOVE_BY = "com.assistive.filter.API_POINTER_MOVE_BY";
    public static final String ACTION_TAP = "com.assistive.filter.API_POINTER_TAP";
    public static final String ACTION_MOVE_TO_TARGET = "com.assistive.filter.API_POINTER_MOVE_TO_TARGET";
    public static final String ACTION_AIM_TRIGGER = "com.assistive.filter.AIM_TRIGGER";
    public static final String EXTRA_DX = "dx";
    public static final String EXTRA_DY = "dy";
    public static final String EXTRA_X = "x";
    public static final String EXTRA_Y = "y";
    public static final String EXTRA_BASE = "base";
    public static final String EXTRA_CURRENT = "current";
    public static final String EXTRA_DIRECTION = "direction";
    public static final String EXTRA_BASE_Y_OFFSET = "base_y_offset";
    public static final String EXTRA_BASE_X_PREDICTION = "base_x_prediction";
    public static final String EXTRA_DURATION_MS = "duration_ms";

    private static final float DURATION_SEC = 0.2f;
    private static final float MIN_V_Y = 500f;
    private static final float MAX_V_Y = 2000f;
    private static final float MAX_LEAD_X = 400f;
    private static final float TRACKING_INTERVAL_MS = 33f;
    private static final float TRACKING_DX_THRESHOLD = 5f;
    private static final float MAX_TRACKING_MOVE = 30f;

    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private Runnable trackingRunnable;
    private boolean trackingActive = false;
    private WindowManager wm;
    private TouchOverlayView overlay;
    private GainBridgeService.GainBinder gainBinder;

    private static AssistTouchAccessibilityService instance;

    private final ServiceConnection conn = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            gainBinder = (GainBridgeService.GainBinder) service;
        }
        @Override
        public void onServiceDisconnected(ComponentName name) {
            gainBinder = null;
        }
    };

    private final BroadcastReceiver aimReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (ACTION_AIM_TRIGGER.equals(intent.getAction())) {
                performAimedSwipeAndTrack();
            }
        }
    };

    @Override
    public void onServiceConnected() {
        super.onServiceConnected();
        instance = this;

        AccessibilityServiceInfo info = getServiceInfo();
        info.flags |= AccessibilityServiceInfo.FLAG_REQUEST_TOUCH_EXPLORATION_MODE;
        info.flags |= AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS;
        info.flags |= AccessibilityServiceInfo.FLAG_REQUEST_FILTER_KEY_EVENTS;
        setServiceInfo(info);

        Intent i = new Intent(this, GainBridgeService.class);
        try { bindService(i, conn, Context.BIND_AUTO_CREATE); } catch (Throwable ignore) {}

        IntentFilter filter = new IntentFilter(ACTION_AIM_TRIGGER);
        try { registerReceiver(aimReceiver, filter); } catch (Throwable ignore) {}

        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
			? WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
			: WindowManager.LayoutParams.TYPE_PHONE;
        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
			WindowManager.LayoutParams.MATCH_PARENT,
			WindowManager.LayoutParams.MATCH_PARENT,
			type,
			WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
			| WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
			PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.START;
        overlay = new TouchOverlayView(this);
        overlay.listener = new TouchOverlayView.Listener() {
            @Override
            public void onLongPress(float x, float y) {
                DisplayMetrics dm = getResources().getDisplayMetrics();
                if (x > dm.widthPixels * 0.6) {
                    performAimedSwipeAndTrack();
                }
            }
        };
        wm.addView(overlay, params);

        trackingRunnable = new Runnable() {
            @Override
            public void run() {
                if (!trackingActive) return;
                performTracking();
                mainHandler.postDelayed(this, (long) TRACKING_INTERVAL_MS);
            }
        };
    }

    @Override
    public boolean onGesture(int gestureId) {
        if (gestureId == 0x00000010) {
            performAimedSwipeAndTrack();
            return true;
        }
        return super.onGesture(gestureId);
    }

    @Override
    public boolean onKeyEvent(KeyEvent event) {
        if (event.getAction() == KeyEvent.ACTION_DOWN && event.getKeyCode() == KeyEvent.KEYCODE_VOLUME_UP) {
            performAimedSwipeAndTrack();
            return true;
        }
        return super.onKeyEvent(event);
    }

    public void triggerAim() {
        performAimedSwipeAndTrack();
    }

    private void performAimedSwipeAndTrack() {
        float yHead = enhancelensservice.getLastTargetScreenY();
        if (yHead <= 0) return;

        float targetVX = enhancelensservice.getLastTargetVelocityX();
        DisplayMetrics dm = getResources().getDisplayMetrics();
        float startX = dm.widthPixels / 2f;
        float startY = dm.heightPixels / 2f;

        float deltaY = startY - yHead;
        if (deltaY < 0) deltaY = 0;
        float V_Y = deltaY / DURATION_SEC;
        if (V_Y < MIN_V_Y) V_Y = MIN_V_Y;
        if (V_Y > MAX_V_Y) V_Y = MAX_V_Y;

        float V_X = targetVX;
        if (Math.abs(V_X) > 400) V_X = (V_X > 0 ? 400 : -400);

        float endX = startX + V_X * DURATION_SEC;
        float endY = startY - V_Y * DURATION_SEC;

        if (endX < 0) endX = 0;
        if (endX > dm.widthPixels) endX = dm.widthPixels;
        if (endY < 0) endY = 0;
        if (endY > yHead) endY = yHead;

        long durationMs = (long)(DURATION_SEC * 1000);
        Path path = new Path();
        path.moveTo(startX, startY);
        path.lineTo(endX, endY);
        GestureDescription.Builder builder = new GestureDescription.Builder();
        builder.addStroke(new GestureDescription.StrokeDescription(path, 0, durationMs));
        dispatchGesture(builder.build(), null, null);

        mainHandler.postDelayed(new Runnable() {
				@Override
				public void run() {
					startTracking();
				}
			}, durationMs + 50);
    }

    private void startTracking() {
        if (trackingActive) return;
        trackingActive = true;
        mainHandler.removeCallbacks(trackingRunnable);
        mainHandler.post(trackingRunnable);
    }

    private void stopTracking() {
        trackingActive = false;
        mainHandler.removeCallbacks(trackingRunnable);
    }

    private void performTracking() {
        if (!enhancelensservice.hasLiveTarget()) return;
        float targetX = enhancelensservice.getLastTargetScreenX();
        float targetY = enhancelensservice.getLastTargetScreenY();
        if (targetX < 0 || targetY < 0) return;

        DisplayMetrics dm = getResources().getDisplayMetrics();
        float currentX = dm.widthPixels / 2f;
        float dx = targetX - currentX;
        if (Math.abs(dx) < TRACKING_DX_THRESHOLD) return;

        if (dx > MAX_TRACKING_MOVE) dx = MAX_TRACKING_MOVE;
        if (dx < -MAX_TRACKING_MOVE) dx = -MAX_TRACKING_MOVE;

        float gain = 1.0f;
        if (gainBinder != null) { try { gain = gainBinder.getGain(); } catch (Throwable ignore) {} }
        dx = dx * gain;

        apiMoveBy(dx, 0);
    }

    private void apiMoveBy(float dx, float dy) {
        float gain = 1.0f;
        if (gainBinder != null) { try { gain = gainBinder.getGain(); } catch (Throwable ignore) {} }
        float totalDx = dx * gain;
        float totalDy = dy * gain;
        dispatchLineGestureSwipe(totalDx, totalDy);
    }

    private void dispatchLineGestureSwipe(float dx, float dy) {
        DisplayMetrics dm = getResources().getDisplayMetrics();
        float fromX = dm.widthPixels / 2f;
        float fromY = dm.heightPixels / 2f;
        float toX = fromX + dx;
        float toY = fromY + dy;
        if (toX < 0) toX = 0;
        if (toX > dm.widthPixels) toX = dm.widthPixels;
        if (toY < 0) toY = 0;
        if (toY > dm.heightPixels) toY = dm.heightPixels;
        long duration = (long)(Math.hypot(dx, dy) / 4000f * 1000f);
        if (duration < 6L) duration = 6L;
        if (duration > 200L) duration = 200L;
        dispatchLineGesture(fromX, fromY, toX, toY, duration);
    }

    public void dispatchLineGesture(float fx, float fy, float tx, float ty, long durationMs) {
        Path path = new Path();
        path.moveTo(fx, fy);
        path.lineTo(tx, ty);
        GestureDescription.StrokeDescription stroke =
			new GestureDescription.StrokeDescription(path, 0, durationMs);
        GestureDescription gesture = new GestureDescription.Builder()
			.addStroke(stroke)
			.build();
        dispatchGesture(gesture, null, null);
    }

    public void dispatchTapGesture(float x, float y, long durationMs) {
        Path path = new Path();
        path.moveTo(x, y);
        path.lineTo(x, y);
        GestureDescription.StrokeDescription stroke =
			new GestureDescription.StrokeDescription(path, 0, durationMs);
        GestureDescription gesture = new GestureDescription.Builder()
			.addStroke(stroke)
			.build();
        dispatchGesture(gesture, null, null);
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) { }

    @Override
    public void onInterrupt() {
        stopTracking();
    }

    @Override
    public void onDestroy() {
        stopTracking();
        try { unregisterReceiver(aimReceiver); } catch (Throwable ignore) {}
        try { unbindService(conn); } catch (Throwable ignore) {}
        if (wm != null && overlay != null) {
            try { wm.removeView(overlay); } catch (Throwable ignore) {}
        }
        super.onDestroy();
    }

    private interface ServiceConnection extends android.content.ServiceConnection {}
}
