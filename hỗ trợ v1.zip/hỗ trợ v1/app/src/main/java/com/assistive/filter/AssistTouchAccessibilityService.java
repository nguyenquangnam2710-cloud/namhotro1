// File: AssistTouchAccessibilityService.java (đã bổ sung ACTION_AIM_TRIGGER và dispatchLineGesture)
package com.assistive.filter;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.accessibilityservice.GestureDescription;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;

public class AssistTouchAccessibilityService extends AccessibilityService {

    // ==================== API CONSTANTS ====================
    public static final String ACTION_MOVE_BY = "com.assistive.filter.API_POINTER_MOVE_BY";
    public static final String ACTION_TAP = "com.assistive.filter.API_POINTER_TAP";
    public static final String ACTION_MOVE_TO_TARGET = "com.assistive.filter.API_POINTER_MOVE_TO_TARGET";
    public static final String ACTION_AIM_TRIGGER = "com.assistive.filter.AIM_TRIGGER";  // <-- ĐÃ THÊM
    public static final String EXTRA_DX = "dx";
    public static final String EXTRA_DY = "dy";
    public static final String EXTRA_X = "x";
    public static final String EXTRA_Y = "y";
    public static final String EXTRA_DURATION_MS = "duration_ms";
    public static final String EXTRA_BASE = "base";
    public static final String EXTRA_CURRENT = "current";
    public static final String EXTRA_DIRECTION = "direction";
    public static final String EXTRA_BASE_Y_OFFSET = "base_y_offset";
    public static final String EXTRA_BASE_X_PREDICTION = "base_x_prediction";

    // ==================== MACRO CONSTANTS ====================
    private static final float DURATION_SEC = 0.2f;
    private static final float BASE_Y = 540f;
    private static final float HEAD_OFFSET_STAND = 25f;
    private static final float HEAD_OFFSET_RUN = 24f;
    private static final float V_WALK = 180f;
    private static final float V_RUN = 260f;
    private static final long TRACKING_INTERVAL_MS = 50L;
    private static final float MAX_TRACKING_MOVE = 25f;

    private Handler mainHandler = new Handler(Looper.getMainLooper());
    private Runnable trackingRunnable;
    private boolean trackingActive = false;
    private WindowManager wm;
    private TouchOverlayView overlay;

    // ==================== BROADCAST RECEIVER ====================
    private final BroadcastReceiver aimReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (ACTION_AIM_TRIGGER.equals(intent.getAction())) {
                performAimedSwipeAndTrack();
            }
        }
    };

    @Override
    public void onServiceConnected() {
        super.onServiceConnected();
        AccessibilityServiceInfo info = getServiceInfo();
        info.flags |= AccessibilityServiceInfo.FLAG_REQUEST_TOUCH_EXPLORATION_MODE;
        info.flags |= AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS;
        info.flags |= AccessibilityServiceInfo.FLAG_REQUEST_FILTER_KEY_EVENTS;
        setServiceInfo(info);

        // Đăng ký receiver cho ACTION_AIM_TRIGGER
        IntentFilter filter = new IntentFilter(ACTION_AIM_TRIGGER);
        registerReceiver(aimReceiver, filter);

        // Tạo overlay trong suốt để bắt touch vùng bắn
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
			? WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
			: WindowManager.LayoutParams.TYPE_PHONE;
        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
			WindowManager.LayoutParams.MATCH_PARENT,
			WindowManager.LayoutParams.MATCH_PARENT,
			type,
			WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
			| WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
			PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.START;
        overlay = new TouchOverlayView(this, this);
        wm.addView(overlay, params);

        trackingRunnable = new Runnable() {
            @Override
            public void run() {
                if (!trackingActive) return;
                performTracking();
                mainHandler.postDelayed(trackingRunnable, TRACKING_INTERVAL_MS);
            }
        };
    }

    public void triggerAim() {
        performAimedSwipeAndTrack();
    }

    private void performAimedSwipeAndTrack() {
        float yHead = enhancelensservice.getLastTargetScreenY();
        if (yHead <= 0) return;

        float targetVX = enhancelensservice.getLastTargetVelocityX();
        DisplayMetrics dm = getResources().getDisplayMetrics();
        float startX = dm.widthPixels / 2f;
        float startY = BASE_Y;

        float absVX = Math.abs(targetVX);
        float deltaY = (absVX < 50f) ? HEAD_OFFSET_STAND : HEAD_OFFSET_RUN;
        if (deltaY < 0) deltaY = 0;

        float V_Y = deltaY / DURATION_SEC;
        if (V_Y < 200f) V_Y = 200f;
        if (V_Y > 1000f) V_Y = 1000f;

        float V_X;
        if (absVX < 50f) {
            V_X = 0f;
        } else if (absVX < 100f) {
            V_X = V_WALK * (targetVX > 0 ? 1 : -1);
        } else {
            V_X = V_RUN * (targetVX > 0 ? 1 : -1);
        }

        float endX = startX + V_X * DURATION_SEC;
        float endY = startY - V_Y * DURATION_SEC;

        if (endX < 0) endX = 0;
        if (endX > dm.widthPixels) endX = dm.widthPixels;
        if (endY < 0) endY = 0;
        if (endY > yHead) endY = yHead;

        long durationMs = (long)(DURATION_SEC * 1000);
        Path path = new Path();
        path.moveTo(startX, startY);
        path.lineTo(endX, endY);
        GestureDescription.Builder builder = new GestureDescription.Builder();
        builder.addStroke(new GestureDescription.StrokeDescription(path, 0, durationMs));
        dispatchGesture(builder.build(), null, null);

        mainHandler.postDelayed(new Runnable() {
				@Override
				public void run() {
					startTracking();
				}
			}, durationMs + 50);
    }

    private void startTracking() {
        if (trackingActive) return;
        trackingActive = true;
        mainHandler.removeCallbacks(trackingRunnable);
        mainHandler.post(trackingRunnable);
    }

    private void stopTracking() {
        trackingActive = false;
        mainHandler.removeCallbacks(trackingRunnable);
    }

    private void performTracking() {
        if (!enhancelensservice.hasLiveTarget()) return;
        float targetX = enhancelensservice.getLastTargetScreenX();
        if (targetX < 0) return;

        DisplayMetrics dm = getResources().getDisplayMetrics();
        float currentX = dm.widthPixels / 2f;
        float dx = targetX - currentX;
        if (Math.abs(dx) < 8f) return;

        if (dx > MAX_TRACKING_MOVE) dx = MAX_TRACKING_MOVE;
        if (dx < -MAX_TRACKING_MOVE) dx = -MAX_TRACKING_MOVE;

        dispatchHorizontalSwipe(dx);
    }

    private void dispatchHorizontalSwipe(float dx) {
        DisplayMetrics dm = getResources().getDisplayMetrics();
        float fromX = dm.widthPixels / 2f;
        float fromY = dm.heightPixels / 2f;
        float toX = fromX + dx;
        if (toX < 0) toX = 0;
        if (toX > dm.widthPixels) toX = dm.widthPixels;
        long duration = Math.abs((long)(dx / 4000f * 1000f));
        if (duration < 6L) duration = 6L;
        if (duration > 80L) duration = 80L;

        Path path = new Path();
        path.moveTo(fromX, fromY);
        path.lineTo(toX, fromY);
        GestureDescription.Builder builder = new GestureDescription.Builder();
        builder.addStroke(new GestureDescription.StrokeDescription(path, 0, duration));
        dispatchGesture(builder.build(), null, null);
    }

    // ==================== PUBLIC METHODS FOR API ====================
    public void dispatchLineGesture(float fx, float fy, float tx, float ty, long durationMs) {
        Path path = new Path();
        path.moveTo(fx, fy);
        path.lineTo(tx, ty);
        GestureDescription.StrokeDescription stroke = new GestureDescription.StrokeDescription(path, 0, durationMs);
        GestureDescription gesture = new GestureDescription.Builder().addStroke(stroke).build();
        dispatchGesture(gesture, null, null);
    }

    public void dispatchTapGesture(float x, float y, long durationMs) {
        Path path = new Path();
        path.moveTo(x, y);
        path.lineTo(x, y);
        GestureDescription.StrokeDescription stroke = new GestureDescription.StrokeDescription(path, 0, durationMs);
        GestureDescription gesture = new GestureDescription.Builder().addStroke(stroke).build();
        dispatchGesture(gesture, null, null);
    }

    @Override
    public boolean onKeyEvent(KeyEvent event) {
        if (event.getAction() == KeyEvent.ACTION_DOWN && event.getKeyCode() == KeyEvent.KEYCODE_VOLUME_UP) {
            performAimedSwipeAndTrack();
            return true;
        }
        return super.onKeyEvent(event);
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {}

    @Override
    public void onInterrupt() {
        stopTracking();
    }

    @Override
    public void onDestroy() {
        stopTracking();
        try { unregisterReceiver(aimReceiver); } catch (Throwable ignore) {}
        if (wm != null && overlay != null) {
            wm.removeView(overlay);
        }
        super.onDestroy();
    }
}
