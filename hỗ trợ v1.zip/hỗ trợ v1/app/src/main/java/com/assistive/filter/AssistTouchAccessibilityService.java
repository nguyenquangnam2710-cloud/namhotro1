package com.assistive.filter;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;

public final class AssistTouchAccessibilityService extends AccessibilityService {

    public static final String ACTION_MOVE_BY = "com.assistive.filter.API_POINTER_MOVE_BY";
    public static final String ACTION_TAP = "com.assistive.filter.API_POINTER_TAP";
    public static final String ACTION_MOVE_TO_TARGET = "com.assistive.filter.API_POINTER_MOVE_TO_TARGET";

    public static final String EXTRA_DX = "dx";
    public static final String EXTRA_DY = "dy";
    public static final String EXTRA_X = "x";
    public static final String EXTRA_Y = "y";
    public static final String EXTRA_BASE = "base";
    public static final String EXTRA_CURRENT = "current";
    public static final String EXTRA_DIRECTION = "direction";
    public static final String EXTRA_BASE_Y_OFFSET = "base_y_offset";
    public static final String EXTRA_BASE_X_PREDICTION = "base_x_prediction";
    public static final String EXTRA_DURATION_MS = "duration_ms";

    private static final float Y_AXIS_BOOST = 1.5f;
    private static final float DURATION_SEC = 0.2f;
    private static final float TRACKING_INTERVAL_MS = 33f;
    private static final float TRACKING_DX_THRESHOLD = 5f;

    private final Handler main = new Handler(Looper.getMainLooper());
    private WindowManager wm;
    private TouchOverlayView overlay;

    private volatile GainBridgeService.GainBinder gainBinder;
    private final ServiceConnection conn = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            gainBinder = (GainBridgeService.GainBinder) service;
        }
        @Override
        public void onServiceDisconnected(ComponentName name) {
            gainBinder = null;
        }
    };

    private boolean trackingActive = false;
    private float lastTargetScreenX = -1;
    private float lastTargetScreenY = -1;
    private Runnable trackingRunnable;

    private final BroadcastReceiver apiReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (!ApiConfig.validate(AssistTouchAccessibilityService.this, intent)) return;
            final String a = intent.getAction();
            if (a == null) return;

            if (ACTION_MOVE_BY.equals(a)) {
                final float dx = intent.getFloatExtra(EXTRA_DX, 0f);
                final float dy = intent.getFloatExtra(EXTRA_DY, 0f);
                main.post(new Runnable() {
						public void run() { apiMoveBy(dx, dy); }
					});
                return;
            }
            if (ACTION_TAP.equals(a)) {
                final float x = intent.getFloatExtra(EXTRA_X, -1f);
                final float y = intent.getFloatExtra(EXTRA_Y, -1f);
                final long dur = clampDur(intent.getLongExtra(EXTRA_DURATION_MS, 60L));
                main.post(new Runnable() {
						public void run() { apiTap(x, y, dur); }
					});
                return;
            }
            if (ACTION_MOVE_TO_TARGET.equals(a)) {
                final double base = intent.getDoubleExtra(EXTRA_BASE, 0.0);
                final double current = intent.getDoubleExtra(EXTRA_CURRENT, 0.0);
                final int direction = intent.getIntExtra(EXTRA_DIRECTION, 1);
                final double baseYOffset = intent.getDoubleExtra(EXTRA_BASE_Y_OFFSET, 187.32);
                final double baseXPred = intent.getDoubleExtra(EXTRA_BASE_X_PREDICTION, 469.31);
                final long dur = clampDur(intent.getLongExtra(EXTRA_DURATION_MS, 18L));
                main.post(new Runnable() {
						public void run() { apiMoveToComputedTarget(base, current, direction, baseYOffset, baseXPred, dur); }
					});
                return;
            }
        }
    };

    @Override
    protected void onServiceConnected() {
        Intent i = new Intent(this, GainBridgeService.class);
        try { bindService(i, conn, Context.BIND_AUTO_CREATE); } catch (Throwable ignore) {}

        IntentFilter f = new IntentFilter();
        f.addAction(ACTION_MOVE_BY);
        f.addAction(ACTION_TAP);
        f.addAction(ACTION_MOVE_TO_TARGET);
        try { registerReceiver(apiReceiver, f); } catch (Throwable ignore) {}

        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
			? WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
			: WindowManager.LayoutParams.TYPE_PHONE;
        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
			WindowManager.LayoutParams.MATCH_PARENT,
			WindowManager.LayoutParams.MATCH_PARENT,
			type,
			WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
			| WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
			| WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
			PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.START;
        overlay = new TouchOverlayView(this);
        overlay.listener = new TouchOverlayView.Listener() {
            @Override public void onDown(float x, float y) {}
            @Override public void onMove(float dx, float dy) {}
            @Override public void onUp() {
                stopTracking();
            }
            @Override public void onLongPress(float x, float y) {
                DisplayMetrics dm = getResources().getDisplayMetrics();
                if (x > dm.widthPixels / 2) {
                    float yHead = enhancelensservice.getLastTargetScreenY();
                    if (yHead > 0) {
                        snapToHeadAndTrack(x, y, yHead);
                    }
                }
            }
        };
        try { wm.addView(overlay, params); } catch (Throwable ignore) {}
    }

    public void snapToHeadAndTrack(float startX, float startY, float yHead) {
        float deltaY = startY - yHead;
        if (deltaY < 0) deltaY = 0;
        float V_Y = deltaY / DURATION_SEC;
        if (V_Y < 500f) V_Y = 500f;
        if (V_Y > 12000f) V_Y = 12000f;

        float targetVX = enhancelensservice.getLastTargetVelocityX();
        float V_X = targetVX;
        if (Math.abs(V_X) > 400f) V_X = (V_X > 0 ? 400f : -400f);

        float endX = startX + V_X * DURATION_SEC;
        float endY = startY - V_Y * DURATION_SEC;

        DisplayMetrics dm = getResources().getDisplayMetrics();
        if (endX < 0) endX = 0;
        if (endX > dm.widthPixels) endX = dm.widthPixels;
        if (endY < 0) endY = 0;
        if (endY < yHead) endY = yHead;

        long durationMs = (long)(DURATION_SEC * 1000f);
        dispatchLineGesture(startX, startY, endX, endY, durationMs);

        main.postDelayed(new Runnable() {
				@Override
				public void run() {
					startTracking();
				}
			}, durationMs + 50);
    }

    private void startTracking() {
        if (trackingActive) return;
        trackingActive = true;
        lastTargetScreenX = -1;
        lastTargetScreenY = -1;
        if (trackingRunnable == null) {
            trackingRunnable = new Runnable() {
                @Override
                public void run() {
                    if (!trackingActive) return;
                    performTracking();
                    main.postDelayed(trackingRunnable, (long) TRACKING_INTERVAL_MS);
                }
            };
        }
        main.post(trackingRunnable);
    }

    public void stopTracking() {
        trackingActive = false;
        main.removeCallbacks(trackingRunnable);
    }

    private void performTracking() {
        if (!enhancelensservice.hasLiveTarget()) return;
        float targetX = enhancelensservice.getLastTargetScreenX();
        float targetY = enhancelensservice.getLastTargetScreenY();
        if (targetX < 0 || targetY < 0) return;

        DisplayMetrics dm = getResources().getDisplayMetrics();
        float currentX = dm.widthPixels / 2f;
        float currentY = targetY;

        float dx = targetX - currentX;
        if (Math.abs(dx) < TRACKING_DX_THRESHOLD) return;

        float maxMove = 30f;
        if (dx > maxMove) dx = maxMove;
        if (dx < -maxMove) dx = -maxMove;

        float gain = 1.0f;
        GainBridgeService.GainBinder b = gainBinder;
        if (b != null) { try { gain = b.getGain(); } catch (Throwable ignore) {} }
        dx = dx * gain;

        apiMoveBy(dx, 0);
    }

    private void apiMoveBy(float dx, float dy) {
        float g = 1f;
        GainBridgeService.GainBinder b = gainBinder;
        if (b != null) { try { g = b.getGain(); } catch (Throwable ignore) {} }
        float totalDx = dx * g;
        float totalDy = dy * g * Y_AXIS_BOOST;
        dispatchLineGestureSwipe(totalDx, totalDy);
    }

    private void apiMoveToComputedTarget(double base, double current, int direction, double baseYOffset, double baseXPred, long durationMs) {
        DisplayMetrics dm = getResources().getDisplayMetrics();
        float tx = AssistiveTargetMath.computeXTargetPx(dm, base, current, direction, baseXPred);
        float ty = AssistiveTargetMath.computeYTargetPx(dm, base, current, baseYOffset);
        if (tx < 0f || ty < 0f) return;
        float fromX = dm.widthPixels / 2f;
        float fromY = dm.heightPixels / 2f;
        dispatchLineGesture(fromX, fromY, tx, ty, durationMs);
    }

    private void apiTap(float x, float y, long durationMs) {
        if (x < 0f || y < 0f) return;
        dispatchTapGesture(x, y, durationMs);
    }

    private void dispatchLineGestureSwipe(float dx, float dy) {
        DisplayMetrics dm = getResources().getDisplayMetrics();
        float fromX = dm.widthPixels / 2f;
        float fromY = dm.heightPixels / 2f;
        float toX = fromX + dx;
        float toY = fromY + dy;
        if (toX < 0) toX = 0;
        if (toX > dm.widthPixels) toX = dm.widthPixels;
        if (toY < 0) toY = 0;
        if (toY > dm.heightPixels) toY = dm.heightPixels;
        long duration = (long)(Math.hypot(dx, dy) / 4000f * 1000f);
        if (duration < 6L) duration = 6L;
        if (duration > 200L) duration = 200L;
        dispatchLineGesture(fromX, fromY, toX, toY, duration);
    }

    public void dispatchLineGesture(float fx, float fy, float tx, float ty, long durationMs) {
        Path path = new Path();
        path.moveTo(fx, fy);
        path.lineTo(tx, ty);
        GestureDescription.StrokeDescription stroke =
			new GestureDescription.StrokeDescription(path, 0L, clampDur(durationMs));
        GestureDescription gesture = new GestureDescription.Builder()
			.addStroke(stroke)
			.build();
        dispatchGesture(gesture, null, null);
    }

    public void dispatchTapGesture(float x, float y, long durationMs) {
        Path path = new Path();
        path.moveTo(x, y);
        path.lineTo(x, y);
        GestureDescription.StrokeDescription stroke =
			new GestureDescription.StrokeDescription(path, 0L, clampDur(durationMs));
        GestureDescription gesture = new GestureDescription.Builder()
			.addStroke(stroke)
			.build();
        dispatchGesture(gesture, null, null);
    }

    private static long clampDur(long v) {
        if (v < 6L) return 6L;
        if (v > 900L) return 900L;
        return v;
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {}
    @Override
    public void onInterrupt() {
        stopTracking();
    }
    @Override
    public void onDestroy() {
        stopTracking();
        try { unregisterReceiver(apiReceiver); } catch (Throwable ignore) {}
        try { unbindService(conn); } catch (Throwable ignore) {}
        if (wm != null && overlay != null) {
            try { wm.removeView(overlay); } catch (Throwable ignore) {}
        }
        super.onDestroy();
    }
}
