package com.assistive.filter;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.util.DisplayMetrics;
import android.view.KeyEvent;
import android.view.accessibility.AccessibilityEvent;

public class AssistTouchAccessibilityService extends AccessibilityService {

    // Constants for API
    public static final String ACTION_MOVE_BY = "com.assistive.filter.API_POINTER_MOVE_BY";
    public static final String ACTION_TAP = "com.assistive.filter.API_POINTER_TAP";
    public static final String ACTION_MOVE_TO_TARGET = "com.assistive.filter.API_POINTER_MOVE_TO_TARGET";
    public static final String EXTRA_DX = "dx";
    public static final String EXTRA_DY = "dy";
    public static final String EXTRA_X = "x";
    public static final String EXTRA_Y = "y";
    public static final String EXTRA_BASE = "base";
    public static final String EXTRA_CURRENT = "current";
    public static final String EXTRA_DIRECTION = "direction";
    public static final String EXTRA_BASE_Y_OFFSET = "base_y_offset";
    public static final String EXTRA_BASE_X_PREDICTION = "base_x_prediction";
    public static final String EXTRA_DURATION_MS = "duration_ms";

    @Override
    public void onServiceConnected() {
        super.onServiceConnected();
        AccessibilityServiceInfo info = getServiceInfo();
        info.flags |= AccessibilityServiceInfo.FLAG_REQUEST_TOUCH_EXPLORATION_MODE;
        info.flags |= AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS;
        info.flags |= AccessibilityServiceInfo.FLAG_REQUEST_FILTER_KEY_EVENTS;
        setServiceInfo(info);
    }

    @Override
    public boolean onGesture(int gestureId) {
        // GESTURE_SWIPE_RIGHT_EDGE = 0x00000010
        if (gestureId == 0x00000010) {
            performAimedSwipe();
            return true;
        }
        return super.onGesture(gestureId);
    }

    @Override
    public boolean onKeyEvent(KeyEvent event) {
        if (event.getAction() == KeyEvent.ACTION_DOWN && event.getKeyCode() == KeyEvent.KEYCODE_VOLUME_UP) {
            performAimedSwipe();
            return true;
        }
        return super.onKeyEvent(event);
    }

    private void performAimedSwipe() {
        float yHead = enhancelensservice.getLastTargetScreenY();
        if (yHead <= 0) return;

        float targetVX = enhancelensservice.getLastTargetVelocityX();
        DisplayMetrics dm = getResources().getDisplayMetrics();
        float startX = dm.widthPixels / 2f;
        float startY = dm.heightPixels / 2f;

        float deltaY = startY - yHead;
        if (deltaY < 0) deltaY = 0;
        float durationSec = 0.2f;
        float V_Y = deltaY / durationSec;
        if (V_Y < 500) V_Y = 500;
        if (V_Y > 12000) V_Y = 12000;

        float leadX = targetVX * durationSec;
        if (leadX > 400) leadX = 400;
        if (leadX < -400) leadX = -400;
        float endX = startX + leadX;
        if (endX < 0) endX = 0;
        if (endX > dm.widthPixels) endX = dm.widthPixels;

        float endY = startY - V_Y * durationSec;
        if (endY < 0) endY = 0;
        if (endY > yHead) endY = yHead;

        long durationMs = (long)(durationSec * 1000);
        Path path = new Path();
        path.moveTo(startX, startY);
        path.lineTo(endX, endY);
        GestureDescription.Builder builder = new GestureDescription.Builder();
        builder.addStroke(new GestureDescription.StrokeDescription(path, 0, durationMs));
        dispatchGesture(builder.build(), null, null);
    }

    // Public methods for API
    public void dispatchLineGesture(float fx, float fy, float tx, float ty, long durationMs) {
        Path path = new Path();
        path.moveTo(fx, fy);
        path.lineTo(tx, ty);
        GestureDescription.StrokeDescription stroke =
			new GestureDescription.StrokeDescription(path, 0, durationMs);
        GestureDescription gesture = new GestureDescription.Builder()
			.addStroke(stroke)
			.build();
        dispatchGesture(gesture, null, null);
    }

    public void dispatchTapGesture(float x, float y, long durationMs) {
        Path path = new Path();
        path.moveTo(x, y);
        path.lineTo(x, y);
        GestureDescription.StrokeDescription stroke =
			new GestureDescription.StrokeDescription(path, 0, durationMs);
        GestureDescription gesture = new GestureDescription.Builder()
			.addStroke(stroke)
			.build();
        dispatchGesture(gesture, null, null);
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) { }

    @Override
    public void onInterrupt() { }
}
