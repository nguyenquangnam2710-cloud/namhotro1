package com.assistive.filter;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;
import android.util.DisplayMetrics;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;

public final class AssistTouchAccessibilityService extends AccessibilityService {

    public static final String ACTION_MOVE_BY = "com.assistive.filter.API_POINTER_MOVE_BY";
    public static final String ACTION_TAP = "com.assistive.filter.API_POINTER_TAP";
    public static final String ACTION_MOVE_TO_TARGET = "com.assistive.filter.API_POINTER_MOVE_TO_TARGET";

    public static final String EXTRA_DX = "dx";
    public static final String EXTRA_DY = "dy";
    public static final String EXTRA_X = "x";
    public static final String EXTRA_Y = "y";
    public static final String EXTRA_BASE = "base";
    public static final String EXTRA_CURRENT = "current";
    public static final String EXTRA_DIRECTION = "direction";
    public static final String EXTRA_BASE_Y_OFFSET = "base_y_offset";
    public static final String EXTRA_BASE_X_PREDICTION = "base_x_prediction";
    public static final String EXTRA_DURATION_MS = "duration_ms";

    private static final float BREAK_FORCE_DISTANCE_PX = 775f;
    private static final float BREAK_FORCE_TIME_SEC = 0.1f;
    private static final float BREAK_FORCE_MULTIPLIER = 1.20f;
    private static final float BREAK_FORCE_SPEED_PX_PER_SEC = BREAK_FORCE_DISTANCE_PX / BREAK_FORCE_TIME_SEC;
    private static final float BREAK_FORCE_BOOSTED_SPEED_PX_PER_SEC = BREAK_FORCE_SPEED_PX_PER_SEC * BREAK_FORCE_MULTIPLIER;

    private static final float Y_AXIS_BOOST = 2.0f;
    private static final float STOP_MARGIN_PX = 5f;

    private static final float AIM_ASSIST_RANGE_PX = 540f;
    private static final float AIM_ASSIST_STRENGTH = 2.0f;

    private static final long LONG_PRESS_NS = 150_000_000L; // 0.15 seconds

    // Constants for crosshair assist algorithm
    private static final float V_Y_BASE = 7550f;          // Velocity to break recoil
    private static final float V_X_RUN = 260f;            // Enemy running horizontally
    private static final float V_X_WALK = 180f;           // Enemy walking horizontally
    private static final float V_X_STILL = 0f;            // Enemy still
    private static final float V_X_THRESHOLD_WALK = 50f;  // Threshold to consider walking
    private static final float V_X_THRESHOLD_RUN = 200f;  // Threshold to consider running
    private static final float DURATION_SEC = 0.2f;       // Swipe duration

    private final Handler main = new Handler(Looper.getMainLooper());

    private WindowManager wm;
    private WindowManager.LayoutParams params;
    private TouchOverlayView overlay;

    private volatile GainBridgeService.GainBinder gainBinder;

    private boolean hasPointer;
    private float pointerX;
    private float pointerY;

    private boolean dispatching;
    private boolean hasPending;
    private float pendingFromX, pendingFromY, pendingToX, pendingToY;

    private long downTimeNs;
    private boolean strongAimTriggered = false;
    private boolean longPressEligible = false;

    private volatile boolean recoilRunning;
    private volatile double recoilD;
    private volatile int recoilDirX = 1;
    private volatile float recoilVp;
    private long recoilStartNs, recoilLastTickNs;

    private volatile boolean dragAssistEnabled;
    private volatile float dragAssistDistanceM = 10f;
    private volatile float dragAssistLookSensitivity = 100f;
    private boolean dragAutoSweepTriggered;

    private volatile boolean headLockEnabled;
    private volatile float headLockManualY = Float.NaN;
    private boolean headLockTriggered;

    private long manualMoveLastNs;

    private final Runnable recoilTick = new Runnable() {
        @Override
        public void run() {
            if (!recoilRunning) return;
            long now = SystemClock.elapsedRealtimeNanos();
            double dt = 1.0 / 120.0;
            if (recoilLastTickNs != 0L) {
                long dn = now - recoilLastTickNs;
                if (dn < 1L) dn = 1L;
                if (dn > 50000000L) dn = 50000000L;
                dt = dn / 1e9;
            }
            recoilLastTickNs = now;
            double t = 0.0;
            if (recoilStartNs != 0L) {
                long dn = now - recoilStartNs;
                if (dn < 0L) dn = 0L;
                t = dn / 1e9;
            }
            double d = recoilD;
            float vp = recoilVp;
            if (d <= 0.0 || vp <= 0f) {
                main.postDelayed(this, 8L);
                return;
            }
            float[] v = AssistiveRecoil.velocityMmPerSec(d, (double) vp, t);
            if (v == null) {
                main.postDelayed(this, 8L);
                return;
            }
            float vx = v[0], vy = v[1];
            float dxMm = (float)(vx * dt);
            float dyMm = (float)(vy * dt);
            float dxPx = mmToPxX(dxMm) * (float) recoilDirX;
            float dyPx = -mmToPxY(dyMm);
            apiMoveByRaw(dxPx, dyPx);
            main.postDelayed(this, 8L);
        }
    };

    private final BroadcastReceiver apiReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (!ApiConfig.validate(AssistTouchAccessibilityService.this, intent)) return;
            if (intent == null) return;
            final String a = intent.getAction();
            if (a == null) return;

            if (ACTION_MOVE_BY.equals(a)) {
                final float dx = intent.getFloatExtra(EXTRA_DX, 0f);
                final float dy = intent.getFloatExtra(EXTRA_DY, 0f);
                main.post(new Runnable() {
                        public void run() {
                            apiMoveBy(dx, dy);
                        }
                    });
                return;
            }
            if (ACTION_TAP.equals(a)) {
                final float x = intent.getFloatExtra(EXTRA_X, -1f);
                final float y = intent.getFloatExtra(EXTRA_Y, -1f);
                final long dur = clampDur(intent.getLongExtra(EXTRA_DURATION_MS, 60L));
                main.post(new Runnable() {
                        public void run() {
                            apiTap(x, y, dur);
                        }
                    });
                return;
            }
            if (ACTION_MOVE_TO_TARGET.equals(a)) {
                final double base = intent.getDoubleExtra(EXTRA_BASE, 0.0);
                final double current = intent.getDoubleExtra(EXTRA_CURRENT, 0.0);
                final int direction = intent.getIntExtra(EXTRA_DIRECTION, 1);
                final double baseYOffset = intent.getDoubleExtra(EXTRA_BASE_Y_OFFSET, 187.32);
                final double baseXPred = intent.getDoubleExtra(EXTRA_BASE_X_PREDICTION, 469.31);
                final long dur = clampDur(intent.getLongExtra(EXTRA_DURATION_MS, 18L));
                main.post(new Runnable() {
                        public void run() {
                            apiMoveToComputedTarget(base, current, direction, baseYOffset, baseXPred, dur);
                        }
                    });
                return;
            }

            if (ActionApiReceiver.ACTION_HEADLOCK_ENABLE.equals(a)) {
                final float yHead = intent.getFloatExtra(ActionApiReceiver.EXTRA_Y_HEAD, Float.NaN);
                main.post(new Runnable() {
                        public void run() {
                            headLockEnabled = true;
                            headLockManualY = yHead;
                            headLockTriggered = false;
                        }
                    });
                return;
            }
            if (ActionApiReceiver.ACTION_HEADLOCK_DISABLE.equals(a)) {
                main.post(new Runnable() {
                        public void run() {
                            headLockEnabled = false;
                            headLockManualY = Float.NaN;
                            headLockTriggered = false;
                        }
                    });
                return;
            }
            if (ActionApiReceiver.ACTION_HEADLOCK_TRIGGER.equals(a)) {
                final float yHead = intent.getFloatExtra(ActionApiReceiver.EXTRA_Y_HEAD, Float.NaN);
                main.post(new Runnable() {
                        public void run() {
                            float resolvedY = Float.isNaN(yHead) ? resolveHeadY() : yHead;
                            if (resolvedY >= 0f) runHeadLockGesture(resolvedY);
                        }
                    });
                return;
            }

            if (ActionApiReceiver.ACTION_RECOIL_START.equals(a)) {
                final double d = intent.getDoubleExtra(ActionApiReceiver.EXTRA_D_M, Double.NaN);
                final int dirX0 = intent.getIntExtra(ActionApiReceiver.EXTRA_DIR_X, 1);
                main.post(new Runnable() {
                        public void run() {
                            if (Double.isNaN(d) || d <= 0.0) return;
                            int dirX = dirX0 >= 0 ? 1 : -1;
                            recoilD = d;
                            recoilDirX = dirX;
                            recoilVp = AssistiveRecoil.vpFromDistanceM((float) d);
                            recoilStartNs = SystemClock.elapsedRealtimeNanos();
                            recoilLastTickNs = 0L;
                            recoilRunning = true;
                            main.removeCallbacks(recoilTick);
                            main.post(recoilTick);
                        }
                    });
                return;
            }
            if (ActionApiReceiver.ACTION_RECOIL_UPDATE_DISTANCE.equals(a)) {
                final double d = intent.getDoubleExtra(ActionApiReceiver.EXTRA_D_M, Double.NaN);
                main.post(new Runnable() {
                        public void run() {
                            if (!recoilRunning) return;
                            if (Double.isNaN(d) || d <= 0.0) return;
                            recoilD = d;
                            recoilVp = AssistiveRecoil.vpFromDistanceM((float) d);
                        }
                    });
                return;
            }
            if (ActionApiReceiver.ACTION_RECOIL_STOP.equals(a)) {
                main.post(new Runnable() {
                        public void run() {
                            recoilRunning = false;
                            main.removeCallbacks(recoilTick);
                        }
                    });
                return;
            }

            if (ActionApiReceiver.ACTION_DRAG_ASSIST_START.equals(a)) {
                final double d = intent.getDoubleExtra(ActionApiReceiver.EXTRA_D_M, Double.NaN);
                final float lookSens = intent.getFloatExtra(ActionApiReceiver.EXTRA_LOOK_SENS, 100f);
                main.post(new Runnable() {
                        public void run() {
                            if (Double.isNaN(d) || d <= 0.0) return;
                            dragAssistDistanceM = (float) d;
                            dragAssistLookSensitivity = lookSens > 0f ? lookSens : 100f;
                            dragAssistEnabled = true;
                        }
                    });
                return;
            }
            if (ActionApiReceiver.ACTION_DRAG_ASSIST_UPDATE_DISTANCE.equals(a)) {
                final double d = intent.getDoubleExtra(ActionApiReceiver.EXTRA_D_M, Double.NaN);
                final float lookSens = intent.getFloatExtra(ActionApiReceiver.EXTRA_LOOK_SENS, dragAssistLookSensitivity);
                main.post(new Runnable() {
                        public void run() {
                            if (!dragAssistEnabled) return;
                            if (Double.isNaN(d) || d <= 0.0) return;
                            dragAssistDistanceM = (float) d;
                            if (lookSens > 0f) dragAssistLookSensitivity = lookSens;
                        }
                    });
                return;
            }
            if (ActionApiReceiver.ACTION_DRAG_ASSIST_STOP.equals(a)) {
                main.post(new Runnable() {
                        public void run() {
                            dragAssistEnabled = false;
                        }
                    });
            }
        }
    };

    private final ServiceConnection conn = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            gainBinder = (GainBridgeService.GainBinder) service;
        }
        @Override
        public void onServiceDisconnected(ComponentName name) {
            gainBinder = null;
        }
    };

    @Override
    protected void onServiceConnected() {
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        Intent i = new Intent(this, GainBridgeService.class);
        try { bindService(i, conn, Context.BIND_AUTO_CREATE); } catch (Throwable ignore) {}

        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
            ? WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
            : WindowManager.LayoutParams.TYPE_PHONE;
        params = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
            | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
            | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT);

        overlay = new TouchOverlayView(this);
        overlay.listener = new TouchOverlayView.Listener() {
            @Override
            public void onDown(float x, float y) {
                pointerX = x;
                pointerY = y;
                hasPointer = true;
                dragAutoSweepTriggered = false;
                headLockTriggered = false;
                resetManualBreakForceClock();

                downTimeNs = SystemClock.elapsedRealtimeNanos();
                strongAimTriggered = false;
                float halfW = getResources().getDisplayMetrics().widthPixels / 2f;
                longPressEligible = x > halfW;
            }

            @Override
            public void onMove(float dx, float dy) {
                if (!hasPointer) return;

                // Strong magnet only activates when holding 0.15s on right half
                if (!headLockEnabled && !dragAssistEnabled && !strongAimTriggered && longPressEligible) {
                    long elapsed = SystemClock.elapsedRealtimeNanos() - downTimeNs;
                    if (elapsed >= LONG_PRESS_NS) {
                        strongAimTriggered = true;
                        float yHead = resolveHeadY();
                        if (yHead >= 0f) {
                            triggerStrongAimAssist(yHead);
                            return;
                        }
                    }
                }

                if (headLockEnabled) {
                    if (headLockTriggered) return;
                    if (dy < 0f) {
                        float yHead = resolveHeadY();
                        if (yHead >= 0f) {
                            headLockTriggered = true;
                            runHeadLockGesture(yHead);
                            return;
                        }
                    }
                }

                if (dragAssistEnabled) {
                    if (dragAutoSweepTriggered) return;
                    if (dy < 0f) {
                        dragAutoSweepTriggered = true;
                        runDipRiseAssistGesture();
                        return;
                    }
                }

                float g = 0f;
                GainBridgeService.GainBinder b = gainBinder;
                if (b != null) {
                    try { g = b.getGain(); } catch (Throwable ignore) {}
                }
                float k = scaleFactorFromGain(g);

                float fromX = pointerX;
                float fromY = pointerY;

                float manualDx = dx * k;
                float manualDy = dy * k * Y_AXIS_BOOST;
                float breakDy = breakHoldCompensationY(dy) * Y_AXIS_BOOST;
                float totalDy = manualDy + breakDy;

                if (!headLockEnabled && !dragAssistEnabled && enhancelensservice.hasLiveTarget()) {
                    float yHead = enhancelensservice.getLastTargetScreenY();
                    float dyToHead = yHead - pointerY;
                    float dist = Math.abs(dyToHead);
                    if (dist <= AIM_ASSIST_RANGE_PX && dyToHead < 0) {
                        float assistFactor = 1.0f - (dist / AIM_ASSIST_RANGE_PX);
                        totalDy += dyToHead * assistFactor * AIM_ASSIST_STRENGTH;
                    }
                }

                totalDy = clampUpwardToLiveTarget(totalDy);

                pointerX = clampX(pointerX + manualDx);
                pointerY = clampY(pointerY + totalDy);
                enqueueSegment(fromX, fromY, pointerX, pointerY);
            }

            @Override
            public void onUp() {
                hasPointer = false;
                dragAutoSweepTriggered = false;
                headLockTriggered = false;
                strongAimTriggered = false;
                longPressEligible = false;
                resetManualBreakForceClock();
            }
        };

        try { wm.addView(overlay, params); } catch (Throwable ignore) {}

        IntentFilter f = new IntentFilter();
        f.addAction(ACTION_MOVE_BY);
        f.addAction(ACTION_TAP);
        f.addAction(ACTION_MOVE_TO_TARGET);
        f.addAction(ActionApiReceiver.ACTION_RECOIL_START);
        f.addAction(ActionApiReceiver.ACTION_RECOIL_STOP);
        f.addAction(ActionApiReceiver.ACTION_RECOIL_UPDATE_DISTANCE);
        f.addAction(ActionApiReceiver.ACTION_DRAG_ASSIST_START);
        f.addAction(ActionApiReceiver.ACTION_DRAG_ASSIST_STOP);
        f.addAction(ActionApiReceiver.ACTION_DRAG_ASSIST_UPDATE_DISTANCE);
        f.addAction(ActionApiReceiver.ACTION_HEADLOCK_ENABLE);
        f.addAction(ActionApiReceiver.ACTION_HEADLOCK_DISABLE);
        f.addAction(ActionApiReceiver.ACTION_HEADLOCK_TRIGGER);
        try { registerReceiver(apiReceiver, f); } catch (Throwable ignore) {}
    }

    // ========== ENHANCED CROSSHAIR ASSIST (BASED ON REAL LENS DATA) ==========
    private void triggerStrongAimAssist(float yHead) {
        if (!hasPointer) {
            DisplayMetrics dm = getResources().getDisplayMetrics();
            pointerX = dm.widthPixels * 0.5f;
            pointerY = dm.heightPixels * 0.5f;
            hasPointer = true;
        }

        float startX = clampX(pointerX);
        float startY = clampY(pointerY);

        // 1. Get actual horizontal velocity of target from lens
        float targetVX = enhancelensservice.getLastTargetVelocityX(); // pixels/second
        float absVX = Math.abs(targetVX);

        // 2. Determine V_X based on velocity thresholds
        float V_X;
        if (absVX < V_X_THRESHOLD_WALK) {
            V_X = V_X_STILL;      // still
        } else if (absVX < V_X_THRESHOLD_RUN) {
            V_X = V_X_WALK;       // walking
        } else {
            V_X = V_X_RUN;        // running
        }
        // Keep enemy movement direction
        if (targetVX < 0) {
            V_X = -V_X;
        }

        // 3. Calculate Delta_Y and V_Y based on actual head position
        float deltaY = 540f - yHead;
        if (deltaY < 0) deltaY = 0;
        float V_Y = V_Y_BASE + 10f * deltaY;

        // 4. Distance to move in 0.2 seconds
        float dx = V_X * DURATION_SEC;
        float dy = V_Y * DURATION_SEC; // dy positive = upward

        // 5. End point
        float endX = clampX(startX + dx);
        float endY = clampY(startY - dy); // Y axis points down

        // 6. Ensure not exceeding head (margin 5px)
        float finalEndY = clampY(AssistiveHeadLockFormula.finalY(startY, yHead));
        if (endY < finalEndY) {
            endY = finalEndY;
        }

        long dur = (long)(DURATION_SEC * 1000f); // 200ms
        pointerX = endX;
        pointerY = endY;
        dispatchLineGesture(startX, startY, endX, endY, dur);
    }

    // ========== REMAINING METHODS (unchanged except visibility) ==========
    private void resetManualBreakForceClock() { manualMoveLastNs = 0L; }

    private float breakHoldCompensationY(float rawDy) {
        long now = SystemClock.elapsedRealtimeNanos();
        float dt = 1.0f / 120.0f;
        if (manualMoveLastNs != 0L) {
            long dn = now - manualMoveLastNs;
            if (dn < 1L) dn = 1L;
            if (dn > 50000000L) dn = 50000000L;
            dt = dn / 1e9f;
        }
        manualMoveLastNs = now;
        if (rawDy >= 0f) return 0f;
        return -BREAK_FORCE_BOOSTED_SPEED_PX_PER_SEC * dt;
    }

    private float clampUpwardToLiveTarget(float totalDy) {
        if (totalDy >= 0f) return totalDy;
        if (!enhancelensservice.hasLiveTarget()) return totalDy;
        float yHead = enhancelensservice.getLastTargetScreenY();
        if (yHead < 0f) return totalDy;
        float stopY = yHead - STOP_MARGIN_PX;
        float remainUpPx = pointerY - stopY;
        if (remainUpPx <= 0f) return 0f;
        if (-totalDy > remainUpPx) return -remainUpPx;
        return totalDy;
    }

    private float resolveHeadY() {
        if (!Float.isNaN(headLockManualY)) return headLockManualY;
        if (enhancelensservice.hasLiveTarget()) return enhancelensservice.getLastTargetScreenY();
        return -1f;
    }

    private void runHeadLockGesture(float yHead) {
        if (!hasPointer) {
            DisplayMetrics dm = getResources().getDisplayMetrics();
            pointerX = dm.widthPixels * 0.5f;
            pointerY = dm.heightPixels * 0.5f;
            hasPointer = true;
        }
        float startX = clampX(pointerX);
        float startY = clampY(pointerY);
        long baseDur = AssistiveHeadLockFormula.swipeDurationMs(yHead);
        long dur = Math.max(6L, Math.round((float) baseDur / Y_AXIS_BOOST));
        float endY = clampY(AssistiveHeadLockFormula.finalY(startY, yHead));
        if (endY < yHead) endY = yHead;
        pointerX = startX;
        pointerY = endY;
        dispatchLineGesture(startX, startY, startX, endY, dur);
    }

    private void runDipRiseAssistGesture() {
        if (!hasPointer) {
            DisplayMetrics dm = getResources().getDisplayMetrics();
            pointerX = dm.widthPixels * 0.5f;
            pointerY = dm.heightPixels * 0.5f;
            hasPointer = true;
        }
        int ps = filteroverlayservice.SensitivityController.getPointerSpeed(this, 0);
        float t = AssistiveDragFormula.pointerFactorFromAndroidSpeed(ps);
        float swipeUpPx = AssistiveDragFormula.computeSwipeDistancePx(
            dragAssistDistanceM, dragAssistLookSensitivity, t) * Y_AXIS_BOOST;
        if (Float.isNaN(swipeUpPx) || swipeUpPx <= 0f) return;
        float startX = clampX(pointerX);
        float startY = clampY(pointerY);
        float bottomX = startX;
        float bottomY = clampY(startY + 200f * Y_AXIS_BOOST);
        enqueueSegment(startX, startY, bottomX, bottomY);
        float prevX = bottomX;
        float prevY = bottomY;
        int upSteps = 16;
        for (int i = 1; i <= upSteps; i++) {
            float p = (float) i / (float) upSteps;
            float y = clampY(bottomY - swipeUpPx * p);
            float x;
            if (i == upSteps) {
                x = startX;
            } else {
                float wobble = AssistiveDragFormula.wobbleOffsetPx(0.2f * p);
                x = clampX(startX + wobble);
            }
            enqueueSegment(prevX, prevY, x, y);
            prevX = x;
            prevY = y;
        }
        pointerX = prevX;
        pointerY = prevY;
    }

    private void apiMoveBy(float dx, float dy) {
        if (!hasPointer) {
            DisplayMetrics dm = getResources().getDisplayMetrics();
            pointerX = dm.widthPixels * 0.5f;
            pointerY = dm.heightPixels * 0.5f;
            hasPointer = true;
        }
        float g = 0f;
        GainBridgeService.GainBinder b = gainBinder;
        if (b != null) {
            try { g = b.getGain(); } catch (Throwable ignore) {}
        }
        float k = scaleFactorFromGain(g);
        float fromX = pointerX;
        float fromY = pointerY;
        pointerX = clampX(pointerX + dx * k);
        pointerY = clampY(pointerY + dy * k * Y_AXIS_BOOST);
        enqueueSegment(fromX, fromY, pointerX, pointerY);
    }

    private void apiMoveByRaw(float dx, float dy) {
        if (!hasPointer) {
            DisplayMetrics dm = getResources().getDisplayMetrics();
            pointerX = dm.widthPixels * 0.5f;
            pointerY = dm.heightPixels * 0.5f;
            hasPointer = true;
        }
        float fromX = pointerX;
        float fromY = pointerY;
        pointerX = clampX(pointerX + dx);
        pointerY = clampY(pointerY + dy * Y_AXIS_BOOST);
        enqueueSegment(fromX, fromY, pointerX, pointerY);
    }

    private void apiTap(float x, float y, long durationMs) {
        if (x < 0f || y < 0f) return;
        dispatchTapGesture(x, y, durationMs);
    }

    private void apiMoveToComputedTarget(double base, double current, int direction, double baseYOffset, double baseXPred, long durationMs) {
        DisplayMetrics dm = getResources().getDisplayMetrics();
        float tx = AssistiveTargetMath.computeXTargetPx(dm, base, current, direction, baseXPred);
        float ty = AssistiveTargetMath.computeYTargetPx(dm, base, current, baseYOffset);
        if (tx < 0f || ty < 0f) return;
        if (!hasPointer) {
            pointerX = dm.widthPixels * 0.5f;
            pointerY = dm.heightPixels * 0.5f;
            hasPointer = true;
        }
        float fromX = pointerX;
        float fromY = pointerY;
        pointerX = clampX(tx);
        pointerY = clampY(ty);
        dispatchLineGesture(fromX, fromY, pointerX, pointerY, durationMs);
    }

    private float scaleFactorFromGain(float gain) {
        float g = gain;
        if (g < 0.38f) g = 0.38f;
        if (g > 3.05f) g = 3.05f;
        return g;
    }

    private float mmToPxX(float mm) {
        DisplayMetrics dm = getResources().getDisplayMetrics();
        float xdpi = dm.xdpi > 0f ? dm.xdpi : dm.densityDpi;
        return mm * xdpi / 25.4f;
    }

    private float mmToPxY(float mm) {
        DisplayMetrics dm = getResources().getDisplayMetrics();
        float ydpi = dm.ydpi > 0f ? dm.ydpi : dm.densityDpi;
        return mm * ydpi / 25.4f;
    }

    private float clampX(float x) {
        DisplayMetrics dm = getResources().getDisplayMetrics();
        float max = Math.max(0f, (float) dm.widthPixels - 1f);
        if (x < 0f) return 0f;
        if (x > max) return max;
        return x;
    }

    private float clampY(float y) {
        DisplayMetrics dm = getResources().getDisplayMetrics();
        float max = Math.max(0f, (float) dm.heightPixels - 1f);
        if (y < 0f) return 0f;
        if (y > max) return max;
        return y;
    }

    private void enqueueSegment(float fx, float fy, float tx, float ty) {
        pendingFromX = fx;
        pendingFromY = fy;
        pendingToX = tx;
        pendingToY = ty;
        hasPending = true;
        tryDispatchNext();
    }

    private void tryDispatchNext() {
        if (dispatching) return;
        if (!hasPending) return;
        dispatching = true;
        final float fx = pendingFromX;
        final float fy = pendingFromY;
        final float tx = pendingToX;
        final float ty = pendingToY;
        hasPending = false;
        dispatchLineGestureInternal(fx, fy, tx, ty, 12L, true);
    }

    // ========== PUBLIC METHODS (CHANGED from private to public) ==========
    public void dispatchLineGesture(float fx, float fy, float tx, float ty, long durationMs) {
        dispatchLineGestureInternal(fx, fy, tx, ty, durationMs, false);
    }

    public void dispatchTapGesture(float x, float y, long durationMs) {
        Path path = new Path();
        path.moveTo(x, y);
        path.lineTo(x, y);
        GestureDescription.StrokeDescription stroke =
            new GestureDescription.StrokeDescription(path, 0L, clampDur(durationMs));
        GestureDescription gesture = new GestureDescription.Builder()
            .addStroke(stroke)
            .build();
        dispatchGesture(gesture, null, null);
    }
    // ========== END PUBLIC METHODS ==========

    private void dispatchLineGestureInternal(float fx, float fy, float tx, float ty, long durationMs, final boolean chain) {
        Path path = new Path();
        path.moveTo(fx, fy);
        path.lineTo(tx, ty);
        GestureDescription.StrokeDescription stroke =
            new GestureDescription.StrokeDescription(path, 0L, clampDur(durationMs));
        GestureDescription gesture = new GestureDescription.Builder()
            .addStroke(stroke)
            .build();
        boolean ok = dispatchGesture(gesture, new GestureResultCallback() {
                @Override
                public void onCompleted(GestureDescription gestureDescription) {
                    dispatching = false;
                    if (chain) {
                        main.post(new Runnable() {
                                public void run() {
                                    tryDispatchNext();
                                }
                            });
                    }
                }
                @Override
                public void onCancelled(GestureDescription gestureDescription) {
                    dispatching = false;
                    if (chain) {
                        main.post(new Runnable() {
                                public void run() {
                                    tryDispatchNext();
                                }
                            });
                    }
                }
            }, null);
        if (!ok) dispatching = false;
    }

    private static long clampDur(long v) {
        if (v < 6L) return 6L;
        if (v > 900L) return 900L;
        return v;
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {}

    @Override
    public void onInterrupt() {}

    @Override
    public void onDestroy() {
        recoilRunning = false;
        dragAssistEnabled = false;
        dragAutoSweepTriggered = false;
        headLockEnabled = false;
        headLockManualY = Float.NaN;
        headLockTriggered = false;
        resetManualBreakForceClock();
        main.removeCallbacks(recoilTick);
        try { unregisterReceiver(apiReceiver); } catch (Throwable ignore) {}
        try {
            if (wm != null && overlay != null && overlay.getParent() != null) wm.removeView(overlay);
        } catch (Throwable ignore) {}
        try { unbindService(conn); } catch (Throwable ignore) {}
        super.onDestroy();
    }

    private interface ServiceConnection extends android.content.ServiceConnection {}
}
