package com.assistive.filter;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.util.DisplayMetrics;
import android.view.KeyEvent;
import android.view.accessibility.AccessibilityEvent;

public class AssistTouchAccessibilityService extends AccessibilityService {

    @Override
    public void onServiceConnected() {
        super.onServiceConnected();
        AccessibilityServiceInfo info = getServiceInfo();
        info.flags |= AccessibilityServiceInfo.FLAG_REQUEST_TOUCH_EXPLORATION_MODE;
        info.flags |= AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS;
        info.flags |= AccessibilityServiceInfo.FLAG_REQUEST_FILTER_KEY_EVENTS;
        info.gestureDetectionEnabled = true;
        setServiceInfo(info);
    }

    @Override
    public void onGesture(int gestureId) {
        if (gestureId == GESTURE_SWIPE_RIGHT_EDGE) {
            performAimedSwipe();
        }
        super.onGesture(gestureId);
    }

    @Override
    public boolean onKeyEvent(KeyEvent event) {
        if (event.getAction() == KeyEvent.ACTION_DOWN && event.getKeyCode() == KeyEvent.KEYCODE_VOLUME_UP) {
            performAimedSwipe();
            return true;
        }
        return super.onKeyEvent(event);
    }

    private void performAimedSwipe() {
        float yHead = enhancelensservice.getLastTargetScreenY();
        if (yHead <= 0) return;

        float targetVX = enhancelensservice.getLastTargetVelocityX();
        DisplayMetrics dm = getResources().getDisplayMetrics();
        float startX = dm.widthPixels / 2f;
        float startY = dm.heightPixels / 2f;

        float deltaY = startY - yHead;
        if (deltaY < 0) deltaY = 0;
        float durationSec = 0.2f;
        float V_Y = deltaY / durationSec;
        if (V_Y < 500) V_Y = 500;
        if (V_Y > 12000) V_Y = 12000;

        float leadX = targetVX * durationSec;
        if (leadX > 400) leadX = 400;
        if (leadX < -400) leadX = -400;
        float endX = startX + leadX;
        if (endX < 0) endX = 0;
        if (endX > dm.widthPixels) endX = dm.widthPixels;

        float endY = startY - V_Y * durationSec;
        if (endY < 0) endY = 0;
        if (endY > yHead) endY = yHead;

        long durationMs = (long)(durationSec * 1000);
        Path path = new Path();
        path.moveTo(startX, startY);
        path.lineTo(endX, endY);
        GestureDescription.Builder builder = new GestureDescription.Builder();
        builder.addStroke(new GestureDescription.StrokeDescription(path, 0, durationMs));
        dispatchGesture(builder.build(), null, null);
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) { }

    @Override
    public void onInterrupt() { }
}
