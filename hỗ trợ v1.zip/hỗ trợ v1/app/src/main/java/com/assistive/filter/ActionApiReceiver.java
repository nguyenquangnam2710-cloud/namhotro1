package com.assistive.filter;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.util.Base64;

public final class ActionApiReceiver extends BroadcastReceiver {

    public static final String ACTION_FILTER_START_LOCKED = "com.assistive.filter.API_FILTER_START_LOCKED";
    public static final String ACTION_FILTER_START_EDIT = "com.assistive.filter.API_FILTER_START_EDIT";
    public static final String ACTION_FILTER_STOP = "com.assistive.filter.API_FILTER_STOP";

    public static final String ACTION_LENS_RING_START = "com.assistive.filter.API_LENS_RING_START";
    public static final String ACTION_LENS_RING_STOP = "com.assistive.filter.API_LENS_RING_STOP";

    public static final String ACTION_LENS_ENHANCE_STOP = "com.assistive.filter.API_LENS_ENHANCE_STOP";

    public static final String ACTION_SET_GAIN = "com.assistive.filter.API_SET_GAIN";
    public static final String EXTRA_GAIN = "gain";

    public static final String ACTION_FORMULA_XOR_B64 = "com.assistive.filter.API_FORMULA_XOR_B64";
    public static final String ACTION_FORMULA_PROJECT_POINT = "com.assistive.filter.API_FORMULA_PROJECT_POINT";

    public static final String EXTRA_P_B64 = "p_b64";
    public static final String EXTRA_K_B64 = "k_b64";

    public static final String EXTRA_M_PROJ = "m_projection";
    public static final String EXTRA_M_VIEW = "m_view";
    public static final String EXTRA_M_WORLD = "m_world";
    public static final String EXTRA_P_WORLD = "p_world";

    public static final String EXTRA_RESULT_B64 = "result_b64";
    public static final String EXTRA_RESULT_VEC4 = "result_vec4";

    @Override
    public void onReceive(Context context, Intent intent) {
        if (context == null || intent == null) return;

        if (!ApiConfig.validate(context, intent)) {
            setResultCode(0);
            return;
        }

        String a = intent.getAction();
        if (a == null) {
            setResultCode(0);
            return;
        }

        if (ACTION_FILTER_START_LOCKED.equals(a)) {
            startServiceSafe(context, new Intent(context, filteroverlayservice.class).setAction(filteroverlayservice.ACTION_START_LOCKED));
            setResultCode(1);
            return;
        }

        if (ACTION_FILTER_START_EDIT.equals(a)) {
            startServiceSafe(context, new Intent(context, filteroverlayservice.class).setAction(filteroverlayservice.ACTION_START_EDIT));
            setResultCode(1);
            return;
        }

        if (ACTION_FILTER_STOP.equals(a)) {
            startServiceSafe(context, new Intent(context, filteroverlayservice.class).setAction(filteroverlayservice.ACTION_STOP));
            setResultCode(1);
            return;
        }

        if (ACTION_LENS_RING_START.equals(a)) {
            startServiceSafe(context, new Intent(context, LensOverlayService.class).setAction(LensOverlayService.ACTION_START));
            setResultCode(1);
            return;
        }

        if (ACTION_LENS_RING_STOP.equals(a)) {
            startServiceSafe(context, new Intent(context, LensOverlayService.class).setAction(LensOverlayService.ACTION_STOP));
            setResultCode(1);
            return;
        }

        if (ACTION_LENS_ENHANCE_STOP.equals(a)) {
            startServiceSafe(context, new Intent(context, enhancelensservice.class).setAction(enhancelensservice.ACTION_STOP));
            setResultCode(1);
            return;
        }

        if (ACTION_SET_GAIN.equals(a)) {
            float g = intent.getFloatExtra(EXTRA_GAIN, 0f);
            Intent s = new Intent(context, GainBridgeService.class);
            s.setAction(GainBridgeService.ACTION_SET_GAIN);
            s.putExtra(GainBridgeService.EXTRA_GAIN, g);
            startServiceSafe(context, s);
            setResultCode(1);
            return;
        }

        if (AssistTouchAccessibilityService.ACTION_MOVE_BY.equals(a)
            || AssistTouchAccessibilityService.ACTION_TAP.equals(a)
            || AssistTouchAccessibilityService.ACTION_MOVE_TO_TARGET.equals(a)) {
            context.sendBroadcast(intent);
            setResultCode(1);
            return;
        }

        if (ACTION_FORMULA_XOR_B64.equals(a)) {
            String p64 = intent.getStringExtra(EXTRA_P_B64);
            String k64 = intent.getStringExtra(EXTRA_K_B64);

            byte[] p = decodeB64(p64);
            byte[] k = decodeB64(k64);
            byte[] out = AssistiveFormula.xor(p, k);

            String out64 = out == null ? null : Base64.encodeToString(out, Base64.NO_WRAP);

            Bundle b = getResultExtras(true);
            b.putString(EXTRA_RESULT_B64, out64);
            setResultExtras(b);
            setResultCode(out64 != null ? 1 : 0);
            return;
        }

        if (ACTION_FORMULA_PROJECT_POINT.equals(a)) {
            float[] mp = intent.getFloatArrayExtra(EXTRA_M_PROJ);
            float[] mv = intent.getFloatArrayExtra(EXTRA_M_VIEW);
            float[] mw = intent.getFloatArrayExtra(EXTRA_M_WORLD);
            float[] pw = intent.getFloatArrayExtra(EXTRA_P_WORLD);

            float[] out = AssistiveFormula.projectPoint(mp, mv, mw, pw);

            Bundle b = getResultExtras(true);
            b.putFloatArray(EXTRA_RESULT_VEC4, out);
            setResultExtras(b);
            setResultCode(out != null ? 1 : 0);
            return;
        }

        setResultCode(0);
    }

    private static byte[] decodeB64(String s) {
        if (s == null) return null;
        try {
            return Base64.decode(s, Base64.DEFAULT);
        } catch (Throwable t) {
            return null;
        }
    }

    private static void startServiceSafe(Context context, Intent i) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(i);
            else context.startService(i);
        } catch (Throwable ignore) {}
    }
}

