package com.assistive.filter;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.util.Base64;

public final class ActionApiReceiver extends BroadcastReceiver {

    public static final String ACTION_FILTER_START_LOCKED = "com.assistive.filter.API_FILTER_START_LOCKED";
    public static final String ACTION_FILTER_START_EDIT = "com.assistive.filter.API_FILTER_START_EDIT";
    public static final String ACTION_FILTER_STOP = "com.assistive.filter.API_FILTER_STOP";

    public static final String ACTION_LENS_RING_START = "com.assistive.filter.API_LENS_RING_START";
    public static final String ACTION_LENS_RING_STOP = "com.assistive.filter.API_LENS_RING_STOP";

    public static final String ACTION_LENS_ENHANCE_STOP = "com.assistive.filter.API_LENS_ENHANCE_STOP";

    public static final String ACTION_SET_GAIN = "com.assistive.filter.API_SET_GAIN";
    public static final String EXTRA_GAIN = "gain";

    public static final String ACTION_FORMULA_XOR_B64 = "com.assistive.filter.API_FORMULA_XOR_B64";
    public static final String ACTION_FORMULA_PROJECT_POINT = "com.assistive.filter.API_FORMULA_PROJECT_POINT";

    public static final String EXTRA_P_B64 = "p_b64";
    public static final String EXTRA_K_B64 = "k_b64";

    public static final String EXTRA_M_PROJ = "m_projection";
    public static final String EXTRA_M_VIEW = "m_view";
    public static final String EXTRA_M_WORLD = "m_world";
    public static final String EXTRA_P_WORLD = "p_world";

    public static final String EXTRA_RESULT_B64 = "result_b64";
    public static final String EXTRA_RESULT_VEC4 = "result_vec4";

    public static final String ACTION_FORMULA_OFFSETS = "com.assistive.filter.API_FORMULA_OFFSETS";
    public static final String EXTRA_D_M = "d_m";
    public static final String EXTRA_X_PIXEL = "x_pixel";
    public static final String EXTRA_Y_PIXEL = "y_pixel";
    public static final String EXTRA_X_MM = "x_mm";
    public static final String EXTRA_Y_MM = "y_mm";
    public static final String EXTRA_DX = "dx";
    public static final String EXTRA_DY = "dy";

    public static final String ACTION_POINTER_MOVE_BY_DISTANCE = "com.assistive.filter.API_POINTER_MOVE_BY_DISTANCE";

    public static final String ACTION_GET_TARGET = "com.assistive.filter.API_GET_TARGET";
    public static final String EXTRA_T_MILLIS = "tMillis";
    public static final String EXTRA_X = "x";
    public static final String EXTRA_Y = "y";
    public static final String EXTRA_VX = "vx";
    public static final String EXTRA_VY = "vy";
    public static final String EXTRA_CONF = "confidence";

    public static final String ACTION_REQUEST_CAPTURE_UI = "com.assistive.filter.API_REQUEST_CAPTURE_UI";
    public static final String EXTRA_CAPTURE_TARGET = "capture_target";
    public static final String CAPTURE_TARGET_VISION = "vision";
    public static final String CAPTURE_TARGET_ENHANCE = "enhance";

    @Override
    public void onReceive(Context context, Intent intent) {
        if (context == null || intent == null) return;

        if (!ApiConfig.validate(context, intent)) {
            setResultCode(0);
            return;
        }

        String a = intent.getAction();
        if (a == null) {
            setResultCode(0);
            return;
        }

        if (ACTION_FILTER_START_LOCKED.equals(a)) {
            startServiceSafe(context, new Intent(context, filteroverlayservice.class).setAction(filteroverlayservice.ACTION_START_LOCKED));
            setResultCode(1);
            return;
        }

        if (ACTION_FILTER_START_EDIT.equals(a)) {
            startServiceSafe(context, new Intent(context, filteroverlayservice.class).setAction(filteroverlayservice.ACTION_START_EDIT));
            setResultCode(1);
            return;
        }

        if (ACTION_FILTER_STOP.equals(a)) {
            startServiceSafe(context, new Intent(context, filteroverlayservice.class).setAction(filteroverlayservice.ACTION_STOP));
            setResultCode(1);
            return;
        }

        if (ACTION_LENS_RING_START.equals(a)) {
            startServiceSafe(context, new Intent(context, LensOverlayService.class).setAction(LensOverlayService.ACTION_START));
            setResultCode(1);
            return;
        }

        if (ACTION_LENS_RING_STOP.equals(a)) {
            startServiceSafe(context, new Intent(context, LensOverlayService.class).setAction(LensOverlayService.ACTION_STOP));
            setResultCode(1);
            return;
        }

        if (ACTION_LENS_ENHANCE_STOP.equals(a)) {
            startServiceSafe(context, new Intent(context, enhancelensservice.class).setAction(enhancelensservice.ACTION_STOP));
            setResultCode(1);
            return;
        }

        if (ACTION_SET_GAIN.equals(a)) {
            float g = intent.getFloatExtra(EXTRA_GAIN, 0f);
            Intent s = new Intent(context, GainBridgeService.class);
            s.setAction(GainBridgeService.ACTION_SET_GAIN);
            s.putExtra(GainBridgeService.EXTRA_GAIN, g);
            startServiceSafe(context, s);
            setResultCode(1);
            return;
        }

        if (AssistTouchAccessibilityService.ACTION_MOVE_BY.equals(a)
            || AssistTouchAccessibilityService.ACTION_TAP.equals(a)
            || AssistTouchAccessibilityService.ACTION_MOVE_TO_TARGET.equals(a)) {
            context.sendBroadcast(intent);
            setResultCode(1);
            return;
        }

        if (ACTION_POINTER_MOVE_BY_DISTANCE.equals(a)) {
            double d = intent.getDoubleExtra(EXTRA_D_M, Double.NaN);
            if (Double.isNaN(d)) {
                setResultCode(0);
                return;
            }

            double denom = d + 3.5;
            if (denom <= 0.0) {
                setResultCode(0);
                return;
            }

            float dx = (float) (6144.0 / denom);
            float dy = (float) (701.0 / denom);

            Intent out = new Intent(AssistTouchAccessibilityService.ACTION_MOVE_BY);
            out.putExtra(ApiConfig.EXTRA_API_KEY, intent.getStringExtra(ApiConfig.EXTRA_API_KEY));
            out.putExtra(AssistTouchAccessibilityService.EXTRA_DX, dx);
            out.putExtra(AssistTouchAccessibilityService.EXTRA_DY, dy);
            context.sendBroadcast(out);

            Bundle b = getResultExtras(true);
            b.putFloat(EXTRA_DX, dx);
            b.putFloat(EXTRA_DY, dy);
            setResultExtras(b);
            setResultCode(1);
            return;
        }

        if (ACTION_FORMULA_OFFSETS.equals(a)) {
            double d = intent.getDoubleExtra(EXTRA_D_M, Double.NaN);
            if (Double.isNaN(d)) {
                setResultCode(0);
                return;
            }

            double denom = d + 3.5;
            if (denom <= 0.0) {
                setResultCode(0);
                return;
            }

            float xPixel = (float) (6144.0 / denom);
            float yPixel = (float) (701.0 / denom);

            float xMm = (float) (409.0 / denom);
            float yMm = (float) (48.0 / denom);

            float dx = xPixel;
            float dy = yPixel;

            Bundle b = getResultExtras(true);
            b.putFloat(EXTRA_X_PIXEL, xPixel);
            b.putFloat(EXTRA_Y_PIXEL, yPixel);
            b.putFloat(EXTRA_X_MM, xMm);
            b.putFloat(EXTRA_Y_MM, yMm);
            b.putFloat(EXTRA_DX, dx);
            b.putFloat(EXTRA_DY, dy);
            setResultExtras(b);
            setResultCode(1);
            return;
        }

        if (ACTION_GET_TARGET.equals(a)) {
            TargetSample s = VisionService.peekLatest();
            if (s == null) {
                setResultCode(0);
                return;
            }

            Bundle b = getResultExtras(true);
            b.putLong(EXTRA_T_MILLIS, s.tMillis);
            b.putFloat(EXTRA_X, s.x);
            b.putFloat(EXTRA_Y, s.y);
            b.putFloat(EXTRA_VX, s.vx);
            b.putFloat(EXTRA_VY, s.vy);
            b.putFloat(EXTRA_CONF, s.confidence);
            setResultExtras(b);
            setResultCode(1);
            return;
        }

        if (ACTION_REQUEST_CAPTURE_UI.equals(a)) {
            String t = intent.getStringExtra(EXTRA_CAPTURE_TARGET);
            if (t == null) t = CAPTURE_TARGET_ENHANCE;

            Intent ui = new Intent(context, MainActivity.class);
            ui.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            ui.putExtra(EXTRA_CAPTURE_TARGET, t);
            context.startActivity(ui);

            setResultCode(1);
            return;
        }

        if (ACTION_FORMULA_XOR_B64.equals(a)) {
            String p64 = intent.getStringExtra(EXTRA_P_B64);
            String k64 = intent.getStringExtra(EXTRA_K_B64);

            byte[] p = decodeB64(p64);
            byte[] k = decodeB64(k64);
            byte[] out = AssistiveFormula.xor(p, k);

            String out64 = out == null ? null : Base64.encodeToString(out, Base64.NO_WRAP);

            Bundle b = getResultExtras(true);
            b.putString(EXTRA_RESULT_B64, out64);
            setResultExtras(b);
            setResultCode(out64 != null ? 1 : 0);
            return;
        }

        if (ACTION_FORMULA_PROJECT_POINT.equals(a)) {
            float[] mp = intent.getFloatArrayExtra(EXTRA_M_PROJ);
            float[] mv = intent.getFloatArrayExtra(EXTRA_M_VIEW);
            float[] mw = intent.getFloatArrayExtra(EXTRA_M_WORLD);
            float[] pw = intent.getFloatArrayExtra(EXTRA_P_WORLD);

            float[] out = AssistiveFormula.projectPoint(mp, mv, mw, pw);

            Bundle b = getResultExtras(true);
            b.putFloatArray(EXTRA_RESULT_VEC4, out);
            setResultExtras(b);
            setResultCode(out != null ? 1 : 0);
            return;
        }

        setResultCode(0);
    }

    private static byte[] decodeB64(String s) {
        if (s == null) return null;
        try {
            return Base64.decode(s, Base64.DEFAULT);
        } catch (Throwable t) {
            return null;
        }
    }

    private static void startServiceSafe(Context context, Intent i) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(i);
            else context.startService(i);
        } catch (Throwable ignore) {}
    }
}

