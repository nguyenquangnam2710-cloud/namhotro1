package com.assistive.filter;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.util.Base64;
import android.util.DisplayMetrics;

public final class ActionApiReceiver extends BroadcastReceiver {

    public static final String ACTION_FILTER_START_LOCKED = "com.assistive.filter.API_FILTER_START_LOCKED";
    public static final String ACTION_FILTER_START_EDIT = "com.assistive.filter.API_FILTER_START_EDIT";
    public static final String ACTION_FILTER_STOP = "com.assistive.filter.API_FILTER_STOP";

    public static final String ACTION_LENS_RING_START = "com.assistive.filter.API_LENS_RING_START";
    public static final String ACTION_LENS_RING_STOP = "com.assistive.filter.API_LENS_RING_STOP";

    public static final String ACTION_LENS_ENHANCE_STOP = "com.assistive.filter.API_LENS_ENHANCE_STOP";

    public static final String ACTION_SET_GAIN = "com.assistive.filter.API_SET_GAIN";
    public static final String EXTRA_GAIN = "gain";

    public static final String ACTION_FORMULA_XOR_B64 = "com.assistive.filter.API_FORMULA_XOR_B64";
    public static final String ACTION_FORMULA_PROJECT_POINT = "com.assistive.filter.API_FORMULA_PROJECT_POINT";

    public static final String EXTRA_P_B64 = "p_b64";
    public static final String EXTRA_K_B64 = "k_b64";

    public static final String EXTRA_M_PROJ = "m_projection";
    public static final String EXTRA_M_VIEW = "m_view";
    public static final String EXTRA_M_WORLD = "m_world";
    public static final String EXTRA_P_WORLD = "p_world";

    public static final String EXTRA_RESULT_B64 = "result_b64";
    public static final String EXTRA_RESULT_VEC4 = "result_vec4";

    public static final String ACTION_FORMULA_OFFSETS = "com.assistive.filter.API_FORMULA_OFFSETS";
    public static final String EXTRA_D_M = "d_m";
    public static final String EXTRA_DIR_X = "dir_x";
    public static final String EXTRA_DIR_Y = "dir_y";

    public static final String EXTRA_X_PIXEL = "x_pixel";
    public static final String EXTRA_Y_PIXEL = "y_pixel";
    public static final String EXTRA_X_MM = "x_mm";
    public static final String EXTRA_Y_MM = "y_mm";

    public static final String EXTRA_SPEED = "speed";
    public static final String EXTRA_DX = "dx";
    public static final String EXTRA_DY = "dy";

    public static final String ACTION_POINTER_TUNE_AND_SWIPE_BY_DISTANCE =
	"com.assistive.filter.API_POINTER_TUNE_AND_SWIPE_BY_DISTANCE";

    public static final String ACTION_RECOIL_START = "com.assistive.filter.API_RECOIL_START";
    public static final String ACTION_RECOIL_STOP = "com.assistive.filter.API_RECOIL_STOP";
    public static final String ACTION_RECOIL_UPDATE_DISTANCE = "com.assistive.filter.API_RECOIL_UPDATE_DISTANCE";

    public static final String ACTION_DRAG_ASSIST_START = "com.assistive.filter.API_DRAG_ASSIST_START";
    public static final String ACTION_DRAG_ASSIST_STOP = "com.assistive.filter.API_DRAG_ASSIST_STOP";
    public static final String ACTION_DRAG_ASSIST_UPDATE_DISTANCE = "com.assistive.filter.API_DRAG_ASSIST_UPDATE_DISTANCE";
    public static final String EXTRA_LOOK_SENS = "look_sens";

    public static final String ACTION_HEADLOCK_ENABLE = "com.assistive.filter.API_HEADLOCK_ENABLE";
    public static final String ACTION_HEADLOCK_DISABLE = "com.assistive.filter.API_HEADLOCK_DISABLE";
    public static final String ACTION_HEADLOCK_TRIGGER = "com.assistive.filter.API_HEADLOCK_TRIGGER";
    public static final String EXTRA_Y_HEAD = "y_head";

    @Override
    public void onReceive(Context context, Intent intent) {
        if (context == null || intent == null) return;

        if (!ApiConfig.validate(context, intent)) {
            setResultCode(0);
            return;
        }

        String a = intent.getAction();
        if (a == null) {
            setResultCode(0);
            return;
        }

        if (ACTION_FILTER_START_LOCKED.equals(a)) {
            startServiceSafe(context, new Intent(context, filteroverlayservice.class).setAction(filteroverlayservice.ACTION_START_LOCKED));
            setResultCode(1);
            return;
        }

        if (ACTION_FILTER_START_EDIT.equals(a)) {
            startServiceSafe(context, new Intent(context, filteroverlayservice.class).setAction(filteroverlayservice.ACTION_START_EDIT));
            setResultCode(1);
            return;
        }

        if (ACTION_FILTER_STOP.equals(a)) {
            startServiceSafe(context, new Intent(context, filteroverlayservice.class).setAction(filteroverlayservice.ACTION_STOP));
            setResultCode(1);
            return;
        }

        if (ACTION_LENS_RING_START.equals(a)) {
            startServiceSafe(context, new Intent(context, LensOverlayService.class).setAction(LensOverlayService.ACTION_START));
            setResultCode(1);
            return;
        }

        if (ACTION_LENS_RING_STOP.equals(a)) {
            startServiceSafe(context, new Intent(context, LensOverlayService.class).setAction(LensOverlayService.ACTION_STOP));
            setResultCode(1);
            return;
        }

        if (ACTION_LENS_ENHANCE_STOP.equals(a)) {
            startServiceSafe(context, new Intent(context, enhancelensservice.class).setAction(enhancelensservice.ACTION_STOP));
            setResultCode(1);
            return;
        }

        if (ACTION_SET_GAIN.equals(a)) {
            float g = intent.getFloatExtra(EXTRA_GAIN, 0f);
            Intent s = new Intent(context, GainBridgeService.class);
            s.setAction(GainBridgeService.ACTION_SET_GAIN);
            s.putExtra(GainBridgeService.EXTRA_GAIN, g);
            startServiceSafe(context, s);
            setResultCode(1);
            return;
        }

        if (AssistTouchAccessibilityService.ACTION_MOVE_BY.equals(a)
            || AssistTouchAccessibilityService.ACTION_TAP.equals(a)
            || AssistTouchAccessibilityService.ACTION_MOVE_TO_TARGET.equals(a)
            || ACTION_RECOIL_START.equals(a)
            || ACTION_RECOIL_STOP.equals(a)
            || ACTION_RECOIL_UPDATE_DISTANCE.equals(a)
            || ACTION_DRAG_ASSIST_START.equals(a)
            || ACTION_DRAG_ASSIST_STOP.equals(a)
            || ACTION_DRAG_ASSIST_UPDATE_DISTANCE.equals(a)
            || ACTION_HEADLOCK_ENABLE.equals(a)
            || ACTION_HEADLOCK_DISABLE.equals(a)
            || ACTION_HEADLOCK_TRIGGER.equals(a)) {
            context.sendBroadcast(intent);
            setResultCode(1);
            return;
        }

        if (ACTION_POINTER_TUNE_AND_SWIPE_BY_DISTANCE.equals(a)) {
            double d = intent.getDoubleExtra(EXTRA_D_M, Double.NaN);
            if (Double.isNaN(d) || d <= 0.0) {
                setResultCode(0);
                return;
            }

            int dirX = intent.getIntExtra(EXTRA_DIR_X, 1);
            int dirY = intent.getIntExtra(EXTRA_DIR_Y, -1);
            if (dirX >= 0) dirX = 1; else dirX = -1;
            if (dirY >= 0) dirY = 1; else dirY = -1;

            float speed = speedFromDistance((float) d);

            Intent gs = new Intent(context, GainBridgeService.class);
            gs.setAction(GainBridgeService.ACTION_SET_GAIN);
            gs.putExtra(GainBridgeService.EXTRA_GAIN, speed);
            startServiceSafe(context, gs);

            double denom = d + 3.5;
            if (denom <= 0.0) {
                setResultCode(0);
                return;
            }

            float xMm = (float) (409.0 / denom) * (float) dirX;
            float yMm = (float) (48.0 / denom) * (float) dirY;

            float xPixel = (float) (6144.0 / denom) * (float) dirX;
            float yPixel = (float) (701.0 / denom) * (float) dirY;

            float dxPx = mmVecToPxX(context, xMm, yMm, 7.0f);
            float dyPx = mmVecToPxY(context, xMm, yMm, 7.0f);

            Intent out = new Intent(AssistTouchAccessibilityService.ACTION_MOVE_BY);
            out.putExtra(ApiConfig.EXTRA_API_KEY, intent.getStringExtra(ApiConfig.EXTRA_API_KEY));
            out.putExtra(AssistTouchAccessibilityService.EXTRA_DX, dxPx);
            out.putExtra(AssistTouchAccessibilityService.EXTRA_DY, dyPx);
            context.sendBroadcast(out);

            Bundle b = getResultExtras(true);
            b.putFloat(EXTRA_SPEED, speed);
            b.putFloat(EXTRA_X_PIXEL, xPixel);
            b.putFloat(EXTRA_Y_PIXEL, yPixel);
            b.putFloat(EXTRA_X_MM, xMm);
            b.putFloat(EXTRA_Y_MM, yMm);
            b.putFloat(EXTRA_DX, dxPx);
            b.putFloat(EXTRA_DY, dyPx);
            setResultExtras(b);
            setResultCode(1);
            return;
        }

        if (ACTION_FORMULA_OFFSETS.equals(a)) {
            double d = intent.getDoubleExtra(EXTRA_D_M, Double.NaN);
            if (Double.isNaN(d) || d <= 0.0) {
                setResultCode(0);
                return;
            }

            int dirX = intent.getIntExtra(EXTRA_DIR_X, 1);
            int dirY = intent.getIntExtra(EXTRA_DIR_Y, -1);
            if (dirX >= 0) dirX = 1; else dirX = -1;
            if (dirY >= 0) dirY = 1; else dirY = -1;

            double denom = d + 3.5;
            if (denom <= 0.0) {
                setResultCode(0);
                return;
            }

            float xPixel = (float) (6144.0 / denom) * (float) dirX;
            float yPixel = (float) (701.0 / denom) * (float) dirY;

            float xMm = (float) (409.0 / denom) * (float) dirX;
            float yMm = (float) (48.0 / denom) * (float) dirY;

            Bundle b = getResultExtras(true);
            b.putFloat(EXTRA_X_PIXEL, xPixel);
            b.putFloat(EXTRA_Y_PIXEL, yPixel);
            b.putFloat(EXTRA_X_MM, xMm);
            b.putFloat(EXTRA_Y_MM, yMm);
            setResultExtras(b);
            setResultCode(1);
            return;
        }

        if (ACTION_FORMULA_XOR_B64.equals(a)) {
            String p64 = intent.getStringExtra(EXTRA_P_B64);
            String k64 = intent.getStringExtra(EXTRA_K_B64);

            byte[] p = decodeB64(p64);
            byte[] k = decodeB64(k64);
            byte[] out = AssistiveFormula.xor(p, k);

            String out64 = out == null ? null : Base64.encodeToString(out, Base64.NO_WRAP);

            Bundle b = getResultExtras(true);
            b.putString(EXTRA_RESULT_B64, out64);
            setResultExtras(b);
            setResultCode(out64 != null ? 1 : 0);
            return;
        }

        if (ACTION_FORMULA_PROJECT_POINT.equals(a)) {
            float[] mp = intent.getFloatArrayExtra(EXTRA_M_PROJ);
            float[] mv = intent.getFloatArrayExtra(EXTRA_M_VIEW);
            float[] mw = intent.getFloatArrayExtra(EXTRA_M_WORLD);
            float[] pw = intent.getFloatArrayExtra(EXTRA_P_WORLD);

            float[] out = AssistiveFormula.projectPoint(mp, mv, mw, pw);

            Bundle b = getResultExtras(true);
            b.putFloatArray(EXTRA_RESULT_VEC4, out);
            setResultExtras(b);
            setResultCode(out != null ? 1 : 0);
            return;
        }

        setResultCode(0);
    }

    private static float speedFromDistance(float d) {
        if (d <= 1.0f) return 3.05f;

        if (d < 5.0f) {
            double p = 0.71;
            double s = 3.05 / Math.pow(d, p);
            if (s > 3.05) s = 3.05;
            if (s < 0.97) s = 0.97;
            return (float) s;
        }

        if (d >= 20.0f) return 0.38f;

        float t = (d - 5.0f) / 15.0f;
        float s = 0.97f + t * (0.38f - 0.97f);
        if (s < 0.38f) s = 0.38f;
        if (s > 0.97f) s = 0.97f;
        return s;
    }

    private static float mmVecToPxX(Context context, float xMm, float yMm, float targetLenMm) {
        float len = (float) Math.sqrt((double) xMm * (double) xMm + (double) yMm * (double) yMm);
        if (len <= 1e-6f) return 0f;

        float nx = xMm / len;
        float mm = nx * clampMm(targetLenMm);

        DisplayMetrics dm = context.getResources().getDisplayMetrics();
        float xdpi = dm.xdpi > 0f ? dm.xdpi : dm.densityDpi;
        return mm * xdpi / 25.4f;
    }

    private static float mmVecToPxY(Context context, float xMm, float yMm, float targetLenMm) {
        float len = (float) Math.sqrt((double) xMm * (double) xMm + (double) yMm * (double) yMm);
        if (len <= 1e-6f) return 0f;

        float ny = yMm / len;
        float mm = ny * clampMm(targetLenMm);

        DisplayMetrics dm = context.getResources().getDisplayMetrics();
        float ydpi = dm.ydpi > 0f ? dm.ydpi : dm.densityDpi;
        return mm * ydpi / 25.4f;
    }

    private static float clampMm(float v) {
        if (v < 6f) return 6f;
        if (v > 8f) return 8f;
        return v;
    }

    private static byte[] decodeB64(String s) {
        if (s == null) return null;
        try {
            return Base64.decode(s, Base64.DEFAULT);
        } catch (Throwable t) {
            return null;
        }
    }

    private static void startServiceSafe(Context context, Intent i) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(i);
            else context.startService(i);
        } catch (Throwable ignore) {}
    }
}
